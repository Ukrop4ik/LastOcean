<?php

include_once "lib/api.php";

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Load a Leaderboard
    case "load":
        wsLoad();
        break;

    // List Leaderboard Highscore
    case "highscore":
        wsHighscore();
        break;
    
    // Highscore for a player
    case "highscore_account":
        wsHighscoreForAccount();
        break;

    // Insert score into Leaderboard
    case "score":
        wsScore();
        break;

    }
}
exit();

function wsLoad() {
    // Get data from REQUEST
    $id = (isset($_REQUEST["IdLeaderboard"]) ? intval($_REQUEST["IdLeaderboard"]) : 0);
    $success = FALSE;
    $message = "";
    // Does the leaderboard exist?
    $leaderboard = new CB_LeaderBoard($id);
    if ($leaderboard->Id > 0) {
        $success = TRUE;
        $message = $leaderboard->ToJson();
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Retrieve a page of scores
 * @global CB_Account $LoggedAccount
 */
function wsHighscore() {
    global $LoggedAccount;
    $highscore = array();
    $count = 0;
    $pageCount = 0;
    // Get data from REQUEST
    $id = (isset($_REQUEST["IdLeaderboard"]) ? intval($_REQUEST["IdLeaderboard"]) : 0);
    // Does the leaderboard exist?
    $leaderboard = new CB_LeaderBoard($id);
    $extraParams = NULL;
    if ($leaderboard->Id > 0) {
        // Return total scores by default
        $timeInterval = CB_LEADERBOARD_HIGHSCORE_WEEK;
        if (isset($_REQUEST["Interval"])) {
            $timeInterval = intval($_REQUEST["Interval"]);
            // Verify the value of interval, switch back to default if needed
            if ($timeInterval < CB_LEADERBOARD_HIGHSCORE_TOTAL || $timeInterval > CB_LEADERBOARD_HIGHSCORE_TODAY)
                $timeInterval = CB_LEADERBOARD_HIGHSCORE_WEEK;
        }
        // Set the limit, offset and page for the results
        $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
        $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
        $groupPlayer = (isset($_REQUEST["GroupPlayer"]) && $_REQUEST["GroupPlayer"] === "1");
        $sumPlayer = (isset($_REQUEST["SumPlayer"]) && $_REQUEST["SumPlayer"] === "1");
        // Load the results
        $highscore = $leaderboard->LoadHighscore($timeInterval, $groupPlayer, $sumPlayer, $limit, Utils::GetPageOffset($page, $limit), $count);
        // Calculate the pages count
        $pageCount = Utils::GetPagesCount($count, $limit);
        // Get the local player score
        if ($LoggedAccount->IsLogged()) {
            $localScore = $leaderboard->LoadHighscoreForAccount($timeInterval, $groupPlayer, $sumPlayer, $LoggedAccount->Id);
            $extraParams = array("localScore" => $localScore);
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($highscore, $count, $pageCount, $extraParams) );
}

function wsHighscoreForAccount () {
    global $LoggedAccount;
    $result = array("Score", "Rank", "Page");
    $account = new CB_Account(!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
    $leaderboard = new CB_LeaderBoard(!isset($_REQUEST["IdLeaderboard"]) ? 0 : intval($_REQUEST["IdLeaderboard"]));
    $timeInterval = CB_LEADERBOARD_HIGHSCORE_WEEK;
    if (isset($_REQUEST["Interval"])) {
        $timeInterval = intval($_REQUEST["Interval"]);
        // Verify the value of interval, switch back to default if needed
        if ($timeInterval < CB_LEADERBOARD_HIGHSCORE_TOTAL || $timeInterval > CB_LEADERBOARD_HIGHSCORE_TODAY)
            $timeInterval = CB_LEADERBOARD_HIGHSCORE_WEEK;
    }
    $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
    $groupPlayer = (isset($_REQUEST["GroupPlayer"]) && $_REQUEST["GroupPlayer"] === "1");
    $sumPlayer = (isset($_REQUEST["SumPlayer"]) && $_REQUEST["SumPlayer"] === "1");
    if ($account->Id > 0 && $leaderboard->Id > 0) {
        $result = $leaderboard->LoadHighscoreForAccount($timeInterval, $groupPlayer, $sumPlayer, $account->Id);
        $result["Page"] = ceil($result["Rank"] / $limit);
        $result["User"] = $account->ToJson();
    }
    Utils::EchoJson( json_encode($result) );
}

function wsScore() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    $id = (isset($_REQUEST["IdLeaderboard"]) ? intval($_REQUEST["IdLeaderboard"]) : 0);
    $username = (isset($_REQUEST["Username"]) ? stripslashes($_REQUEST["Username"]) : "");
    // Does the leaderboard exist?
    $leaderboard = new CB_LeaderBoard($id);
    if ($leaderboard->Id > 0) {
        $account = NULL;
        if ($LoggedAccount->IsLogged()) {
            // Set the scoring player by logged user
            $account = $LoggedAccount;
        } else if ($leaderboard->AllowAnonymous && $username) {
            // Set the scoring player by REQUEST
            $account = new CB_Account();
            $account->Username = $username;
        }
        if ($account) {
            // Get data from REQUEST
            $score = (isset($_REQUEST["Score"]) ? stripslashes($_REQUEST["Score"]) : "");
            $success = $leaderboard->PostScore($account, $score);
            if (!$success)
                $message = "An error occurred";
        } else {
            $message = "User is not logged in";
        }
    } else {
        $message = "Leaderboard is invalid";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
