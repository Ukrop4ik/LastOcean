<?php

include_once './lib/api.php';

checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {
        
        case "tournament_list":
            wsTournamentList();
            break;
        
        case "tournament_load":
            wsTournamentLoad();
            break;
        
        case "tournament_save":
            wsTournamentSave();
            break;
        
        case "tournament_delete":
            wsTournamentDelete();
            break;
        
        case "tournament_leave":
            wsTournamentLeave();
            break;

        case "match_list":
            wsMatchList();
            break;
        
        case "match_load":
            wsMatchLoad();
            break;
        
        case "match_score":
            wsMatchScore();
            break;
        
        case "match_save":
            wsMatchSave();
            break;
        
        case "match_quick":
            wsMatchQuick();
            break;
        
        case "match_delete":
            wsMatchDelete();
            break;
        
    }
}
exit();

/**
 * Load the Tournaments list for the logged account
 * @global CB_Account $LoggedAccount
 */
function wsTournamentList() {
    global $LoggedAccount;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        $finished = (!isset($_REQUEST["Finished"]) ? NULL : intval($_REQUEST["Finished"]));
    
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($_REQUEST["CustomData"]))
            $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        $records = CB_Tournament::Load($finished, NULL, $searchCustomData);
        foreach ($records as $r) {
            $rows[] = $r->ToArray();
        }
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($rows, count($rows)));
}

/**
 * Load a Tournament
 * @global CB_Account $LoggedAccount
 */
function wsTournamentLoad() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $record = new CB_Tournament( isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0 );
        if ($record->Id > 0) {
            $success = TRUE;
            $message = $record->ToJson();
        } else {
            $message = "Invalid Tournament";
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Save a Tournament
 * @global CB_Account $LoggedAccount
 */
function wsTournamentSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {

        $isNew = FALSE;
        $record = new CB_Tournament($_REQUEST, TRUE);
        if ($record->Id < 1) {
            $isNew = TRUE;
            $record->IdOwner = $LoggedAccount->Id;
        }
        if ($record->Save()) {

            // Save the Tournament Custom Data
            $customData = "{}";
            if (isset($_REQUEST["CustomData"]))
                $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
            $customData = json_decode($customData, TRUE);
            foreach ($customData as $key => $value) {
                $noData = FALSE;
                $newData = new CB_Tournament_CustomData();
                $newData->IdTournament = $record->Id;
                $newData->DataKey = $key;
                $newData->DataValue = $value;
                $newData->Save();
            }
            
            if ($isNew) {
                // Save the Matches
                $matches = 0;
                $matches_request = "[]";
                if (isset($_REQUEST["Matches"]))
                    $matches_request = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["Matches"]) : $_REQUEST["Matches"]);
                $matches_request = json_decode($matches_request);
                foreach ($matches_request as $m) {
                    
                    $m = Utils::ObjectToArray($m);
                    $match = new CB_Match($m);
                    $match->IdTournament = $record->Id;
                    if ($match->Save()) {
                        $matches++;
                        // Save the Match Custom Data
                        $matchData = array();
                        if (isset($m["CustomData"]))
                            $matchData = json_decode($m["CustomData"], TRUE);
                        foreach ($customData as $key => $value) {
                            $noData = FALSE;
                            $newData = new CB_Match_CustomData();
                            $newData->IdMatch = $match->Id;
                            $newData->DataKey = $key;
                            $newData->DataValue = $value;
                            $newData->Save();
                        }
                        // Save the Accounts
                        $usersData = array();
                        if (isset($m["Users"]))
                            $usersData = $m["Users"];
                        foreach ($usersData as $userData) {
                            $user = new CB_Account($userData);
                            if ($user->Id > 0) {
                                $matchAccount = new CB_Match_Account();
                                $matchAccount->IdMatch = $match->Id;
                                $matchAccount->IdAccount = $user->Id;
                                if ($matchAccount->Save()) {
                                    $matchRound = new CB_Match_Round();
                                    $matchRound->IdMatchAccount = $matchAccount->Id;
                                    $matchRound->Save();
                                }
                            }
                        }
                    }
                }
            }

            $success = TRUE;
            $message = $record->ToJson();
            
        } else {
            $message = "Unknown error";
        }
    }
    
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Delete a Tournament
 * @global CB_Account $LoggedAccount
 */
function wsTournamentDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $record = new CB_Tournament( !isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]) );
        if ($record->Id < 1 || $record->IdOwner != $LoggedAccount->Id) {
            $message = "Tournament not valid";
        } else if ($record->Delete()) {
            $success = TRUE;
        } else {
            $message = "Unknown error";
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Removes a user from Tournament
 * @global CB_Account $LoggedAccount
 */
function wsTournamentLeave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $id = ( isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0 );
        $tournament = new CB_Tournament($id);
        if ($tournament->Id < 1) {
            $message = "Invalid Tournament";
        } else {
            $idUser = ( isset($_REQUEST["User"]) ? intval($_REQUEST["User"]) : $LoggedAccount );
            $username = ( isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "" );
            $user = new CB_Account( $idUser > 0 ? $idUser : $username );
            if ($user->Id > 0) {
                $matchAccounts = CB_Match_Account::Load($tournament->Id, $user->Id);
                if (count($matchAccounts) > 0) {
                    foreach ($matchAccount as $matchAccount) {
                        // Delete the record Match-Account
                        $match = new CB_Match($matchAccount->IdMatch);
                        $matchAccount->Delete();
                        // Delete the Match if it contains only one user
                        if (DataClass::CountRecords(CB_Match_Account::TABLE_NAME, sprintf("(IdMatch = %d)", $match->Id)) < 2) {
                            $match->Delete();
                        }
                    }
                    $success = TRUE;
                    $message = $tournament->ToJson();
                }
            }
            if (!$success) {
                $message = "Invalid User";
            }
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Load the Matches list for the logged account
 * @global CB_Account $LoggedAccount
 */
function wsMatchList() {
    global $LoggedAccount;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        
        $idTournament = (isset($_REQUEST["IdTournament"]) ? intval($_REQUEST["IdTournament"]) : 0);
        $activeOnly = (isset($_REQUEST["Active"]) ? ($_REQUEST["Active"] === "1") : TRUE);
        $title = (isset($_REQUEST["Title"]) ? trim(stripslashes($_REQUEST["Title"])) : NULL);
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($_REQUEST["CustomData"]))
            $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        $records = CB_Match::Load($idTournament > 0 ? $idTournament : -1, $LoggedAccount->Id, $activeOnly, $title, $searchCustomData);
        foreach ($records as $r) {
            $rows[] = $r->ToArray();
        }
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($rows, count($rows)));
}

/**
 * Get a Match
 * @global CB_Account $LoggedAccount
 */
function wsMatchLoad() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $match = new CB_Match( isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0 );
        if ($match->Id > 0) {
            // Verify that the logged user is a player of the match
            if (DataClass::CountRecords(CB_Match_Account::TABLE_NAME, sprintf("IdMatch = %d AND IdAccount = %d", $match->Id, $LoggedAccount->Id)) > 0) {
                $success = TRUE;
                $message = $match->ToJson();
            }
        }
        if (!$success)
            $message = "Invalid Match";
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Send a score for a match
 * @global CB_Account $LoggedAccount
 */
function wsMatchScore() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $matchRound = new CB_Match_Round( isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0 );
        $matchAccount = new CB_Match_Account($matchRound->Id);
        if ($matchRound->Id > 0 && $matchAccount->Id > 0) {
            
            if ($matchRound->DateScore) {
                $message = "Score already registered";
            } else {
                $matchRound->DateScore = date("Y-m-d H:i:s");
                $matchRound->Score = ( isset($_REQUEST["Score"]) ? floatval($_REQUEST["Score"]) : 0 );
                if ($matchRound->Save()) {
                    $customData = "{}";
                    if (isset($_REQUEST["CustomData"]))
                        $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);

                    $matchAccount->CustomData = $customData;
                    $matchAccount->Save();
                    
                    $success = TRUE;
                    $message = $matchAccount->ToJson();
                    
                    // Check if it's the latest score of the round
                    $match = new CB_Match($matchAccount->IdMatch);
                    $match->CheckFinished();
                } else {
                    $message = "Unknown error";
                }
            }
            
        } else {
            $message = "Invalid Match";
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Save a Match
 * @global CB_Account $LoggedAccount
 */
function wsMatchSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $match = new CB_Match($_REQUEST, TRUE);
        if ($match->Id < 1 && isset($_REQUEST["Id"]) && intval($_REQUEST["Id"]) > 0) {
            $message = "Invalid Match";
        } else {
            if ($match->Save()) {
                $success = TRUE;
                
                // Save the Match Custom Data
                $customData = "{}";
                if (isset($_REQUEST["CustomData"]))
                    $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
                $customData = json_decode($customData, TRUE);
                foreach ($customData as $key => $value) {
                    $noData = FALSE;
                    $newData = new CB_Match_CustomData();
                    $newData->IdMatch = $match->Id;
                    $newData->DataKey = $key;
                    $newData->DataValue = $value;
                    $newData->Save();
                }
                
                // Save the new users
                $users_request = "[]";
                if (isset($_REQUEST["Users"]))
                    $users_request = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["Users"]) : $_REQUEST["Users"]);
                $users_request = json_decode($users_request);
                foreach ($users_request as $userId) {
                    $account = new CB_Account(intval($userId));
                    if ($account->Id > 0) {
                        $matchAccount = new CB_Match_Account();
                        $matchAccount->IdMatch = $match->Id;
                        $matchAccount->IdAccount = $account->Id;
                        if ($matchAccount->Save()) {
                            $matchRound = new CB_Match_Round();
                            $matchRound->IdMatchAccount = $matchAccount->Id;
                            $matchRound->Save();
                        }
                    }
                }
                
                // Remove the deleted users
                $users_request = "[]";
                if (isset($_REQUEST["DeleteUsers"]))
                    $users_request = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["DeleteUsers"]) : $_REQUEST["DeleteUsers"]);
                $users_request = json_decode($users_request);
                foreach ($users_request as $matchAccountId) {
                    $matchAccount = new CB_Match_Account(intval($matchAccountId));
                    $matchAccount->Delete();
                }
                
                $message = $match->ToJson();
            } else {
                $message = "Unknown error";
            }
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Creates a Quick Match between logged account and a random user
 * @global CB_Account $LoggedAccount
 */
function wsMatchQuick() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $friendsOnly = (isset($_REQUEST["Friends"]) ? ($_REQUEST["Friends"] === "1") : FALSE);
        $rounds = (isset($_REQUEST["Rounds"]) ? intval($_REQUEST["Rounds"]) : 1);
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($_REQUEST["CustomData"]))
            $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        if ($rounds < 1)
            $rounds = 1;
        if ($friendsOnly)
            $recs = CB_Account::LoadRandomFriends($LoggedAccount->Id, array(), $searchCustomData, 1);
        else
            $recs = CB_Account::LoadRandom($LoggedAccount->Id, $searchCustomData, 1);
        if (count($recs) > 0) {
            $other = $recs[0];
            $match = new CB_Match();
            $match->Rounds = $rounds;
            if ($match->Save()) {
                
                // Save the users
                $userIds = array( $LoggedAccount->Id, $other->Id );
                $dir = 1;
                for ($i = 1; $i <= $rounds; ++$i) {
                    foreach ($userIds as $idUser) {
                        $matchAccount = new CB_Match_Account();
                        $matchAccount->IdMatch = $match->Id;
                        $matchAccount->IdAccount = $idUser;
                        if ($matchAccount->Save()) {
                            $matchRound = new CB_Match_Round();
                            $matchRound->IdMatchAccount = $matchAccount->Id;
                            $matchRound->Save();
                        }
                    }
                    $user1 = $userIds[0];
                    $user2 = $userIds[1];
                    $userIds[0] = $user2;
                    $userIds[1] = $user1;
                }
                
                if (DataClass::CountRecords(CB_Match_Account::TABLE_NAME, "IdMatch = " . $match->Id) > 1) {
                    $success = TRUE;
                    $message = $match->ToJson();
                } else {
                    $message = "Unknown error";
                    $match->Delete();
                }
                
            } else {
                $message = "Unknown error";
            }
        } else {
            $message = "No users available for match at this moment";
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Delete a Match
 * @global CB_Account $LoggedAccount
 */
function wsMatchDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = "Not logged in";
    } else {
        $record = new CB_Match( !isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]) );
        if ($record->Id > 0)
            $matchAccount = CB_Match_Account::Load($record->Id, $LoggedAccount->Id);
        else
            $matchAccount = array();
        if (count($matchAccount) == 0) {
            $message = "Tournament not valid";
        } else if ($record->Delete()) {
            $success = TRUE;
        } else {
            $message = "Unknown error";
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}