<?

include_once 'lib/api.php';

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List user's friends
        case "list":
            wsList();
            break;

        // Add a new friend to a user list
        case "save":
            wsSave();
            break;

        // Delete a friend from a user list
        case "delete":
            wsDelete();
            break;
        
        // Join a group
        case "join":
            wsJoin();
            break;
        
        // Leave a group
        case "leave":
            wsLeave();
            break;

    }
}
exit();


function wsList() {
    global $LoggedAccount;
    $count = 0;
    $pageCount = 0;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner from REQUEST
        $name = (isset($_REQUEST["Name"]) ? trim(stripslashes($_REQUEST["Name"])) : "");
        $idOwner = (!isset($_REQUEST["IdOwner"]) ? 0 : intval($_REQUEST["IdOwner"]));
        $usernameOwner = (isset($_REQUEST["UsernameOwner"]) ? trim(stripslashes($_REQUEST["UsernameOwner"])) : "");
        $idMember = (!isset($_REQUEST["IdMember"]) ? 0 : intval($_REQUEST["IdMember"]));
        $usernameMember = (isset($_REQUEST["UsernameMember"]) ? trim(stripslashes($_REQUEST["UsernameMember"])) : "");
        $ownerOrMember = ($idOwner > 0 || $usernameOwner) && ($idMember > 0 || $usernameMember);
        $limit = (isset($_REQUEST["Limit"]) && ($ownerOrMember || intval($_REQUEST["Limit"]) > 0) ? intval($_REQUEST["Limit"]) : NULL);
        $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
        $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
        // If it's not me, then verify that the user exists
        $owner = new CB_Account( $idOwner > 0 ? $idOwner : $usernameOwner );
        $member = new CB_Account( $idMember > 0 ? $idMember : $usernameMember );
        // Load the groups list
        $groups = CB_UserGroup::Load($name, $owner->Id, $member->Id, $limit, $offset, $count);
        foreach ($groups as $group) {
            $list[] = $group->ToArray();
        }
        // Calculate the pages count
        $pageCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount));
}

function wsSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        $name = (isset($_REQUEST["Name"]) ? stripslashes($_REQUEST["Name"]) : "");
        $customData = "{}";
        if (isset($_REQUEST["CustomData"]))
            $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
        $rec = new CB_UserGroup($id);
        $rec->Name = $name;
        $rec->CustomData = $customData;
        // Get the members list
        $members = array();
        if (isset($_REQUEST["IdUser"]))
            $userIds = explode(",", stripslashes($_REQUEST["IdUser"]));
        else
            $userIds = explode(",", stripslashes($_REQUEST["Username"]));
        foreach ($userIds as $idUser) {
            $user = new CB_Account($idUser);
            if ($user->Id > 0)
                $members[] = $user;
        }
        // Set the ownership of the group
        if ($rec->Id < 1) {
            $rec->IdOwner = $LoggedAccount->Id;
            $rec->Public = 1;
        }
        // Validate data
        if ($id != $rec->Id) {
            $message = "Invalid group";
        } else if (!$rec->Name) {
            $message = "Invalid group name";
        } else if ($rec->Exists()) {
            $message = "This name is already used";
        } else {
            // Save the new group
            $success = $rec->Save();
            if ($success) {
                foreach ($members as $user) {
                    $membership = new CB_UserGroupAccount();
                    $membership->IdGroup = $rec->Id;
                    $membership->IdAccount = $user->Id;
                    $membership->Save();
                }
                $message = $rec->ToJson();
            } else {
                $message = "An error occurred";
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new CB_UserGroup(!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        if ($rec->IdOwner != $LoggedAccount->Id)
            $message = "Invalid group";
        else {
            $success = $rec->Delete();
            if (!$success)
                $message = "An error occurred";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsJoin() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new CB_UserGroup(isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        // Validate data
        if ($rec->Id == 0) {
            $message = "Invalid group";
        } else {
            $userIds = array();
            if (isset($_REQUEST["IdUser"]))
                $userIds = explode(",", stripslashes($_REQUEST["IdUser"]));
            else if (isset($_REQUEST["Username"]))
                $userIds = explode(",", stripslashes($_REQUEST["Username"]));
            // Fill the list of members to add
            $members = array();
            foreach ($userIds as $id) {
                $user = new CB_Account($id);
                if ($user->Id > 0)
                    $members[] = $user;
            }
            // Verify the members count
            if (count($members) == 0) {
                $message = "No users to add";
            } else {
                // Create the memberships
                foreach ($members as $user) {
                    // Add only if the user is not already a member of this group
                    if (CB_UserGroupAccount::Exists($rec->Id, $user->Id)) {
                        $success = TRUE;
                    } else {
                        $membership = new CB_UserGroupAccount();
                        $membership->IdGroup = $rec->Id;
                        $membership->IdAccount = $user->Id;
                        if ($membership->Save())
                            $success = TRUE;
                    }
                }
                if ($success)
                    $message = $rec->ToJson();
                else
                    $message = "An error occurred";
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsLeave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new CB_UserGroup(isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        // Validate data
        if ($rec->Id == 0) {
            $message = "Invalid group";
        } else {
            //$idUser = explode(",", !isset($_REQUEST["IdUser"]) ? $LoggedAccount->Id : stripslashes($_REQUEST["IdUser"]));
            $userIds = array();
            if (isset($_REQUEST["IdUser"]))
                $userIds = explode(",", stripslashes($_REQUEST["IdUser"]));
            else if (isset($_REQUEST["Username"]))
                $userIds = explode(",", stripslashes($_REQUEST["Username"]));
            // Fill the list of members to add
            $idUser = array();
            foreach ($userIds as $id) {
                $user = new CB_Account($id);
                if ($user->Id > 0)
                    $idUser[] = $user->Id;
            }
            if (count($idUser) == 0) {
                $message = "Missing users to delete";
            } else {
                if (in_array($LoggedAccount->Id, $idUser))
                    $success = TRUE;
                $members = $rec->GetMembers();
                for ($i = count($members) - 1; $i >= 0; --$i) {
                    if (in_array($members[$i]->IdAccount, $idUser)) {
                        // Delete the membership
                        if ($members[$i]->Delete()) {
                            $success = TRUE;
                            // Remove the index from the list
                            array_slice($members, $i, 1);
                        }
                    }
                }
                if ($success) {
                    if (count($members) < 2 && !$rec->Public) {
                        // If remaining members are lesser than 2 and it's not an owned group then delete it
                        $rec->Delete();
                    } else {
                        if (in_array($rec->IdOwner, $idUser)) {
                            // Change ownership to another random member
                            $rnd = rand(0, count($members) - 1);
                            $rec->IdOwner = $members[$rnd]->IdAccount;
                            $rec->Save();
                        }
                    }
                } else {
                    $message = "An error occurred";
                }
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
