<?

include_once 'lib/api.php';

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List user's friends
        case "list":
            wsList();
            break;

        // Add a new friend to a user list
        case "save":
            wsSave();
            break;

        // Delete a friend from a user list
        case "delete":
            wsDelete();
            break;

    }
}
exit();


function wsList() {
    global $LoggedAccount;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of friendship from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $state = (!isset($_REQUEST["State"]) ? -1 : intval($_REQUEST["State"]));
        if ($state < FRIEND_STATE_ACCEPTED || $state > FRIEND_STATE_IGNORE)
            $state = FRIEND_STATE_ACCEPTED;
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new CB_Account($id);
            // Reset the request if the user doesn't exist
            if ($user->Id < 1)
                $id = 0;
        } else {
            // If no ID was specified, then load my friends
            $id = $LoggedAccount->Id;
        }
        // Load the friends results
        $friends = CB_Friend::Load($id, $state);
        foreach ($friends as $friend) {
            $user = new CB_Account($friend->IdFriend);
            if ($user->Id > 0) {
                $list[] = $user->ToArray();
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($list, count($list)) );
}

function wsSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the user Id from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        // If the user is not valid, then get Username from REQUEST
        if ($id < 1) {
            $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
            $user = new CB_Account($username);
            if ($user->Id > 0)
                $id = $user->Id;
        }
        if ($id == $LoggedAccount->Id)
            $message = "You cannot add yourself as contact";
        else if ($id < 1)
            $message = "This user does not exist";
        else {
            $rec = NULL;
            if (FRIENDS_REQUIRE_ACCEPT) {
                // Game is setup to require acceptance of friendship requests
                if (isset($_REQUEST["State"]) && $_REQUEST["State"] != FRIEND_STATE_REQUEST) {
                    // We are setting state on own list
                    $state = intval($_REQUEST["State"]);
                    // Data integrity check for new state
                    if (!in_array($state, array(FRIEND_STATE_ACCEPTED, FRIEND_STATE_IGNORE)))
                        $state = -1;
                    if ($state != -1) {
                        // Apply the new state to the contact
                        $found = FALSE;
                        $recs = CB_Friend::Load($LoggedAccount->Id);
                        foreach ($recs as $r) {
                            if ($r->IdFriend == $id) {
                                $found = TRUE;
                                if ($r->State == $state) {
                                    // State did not change
                                    $success = TRUE;
                                } else {
                                    // Change the state
                                    $r->State = $state;
                                    if ($r->Save()) {
                                        $success = TRUE;
                                        if ($state == FRIEND_STATE_ACCEPTED) {
                                            // Accepted: add ourself to the other's list
                                            $other = new CB_Friend();
                                            $other->IdAccount = $id;
                                            $other->IdFriend = $LoggedAccount->Id;
                                            $other->State = FRIEND_STATE_ACCEPTED;
                                            $other->Save();
                                        } else {
                                            // Ignored: remove ourself from the other's list
                                            $other = CB_Friend::Load($id);
                                            foreach ($other as $i) {
                                                if ($i->IdFriend == $LoggedAccount->Id) {
                                                    $i->Delete();
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                break;
                            }
                        }
                        // If added to ignore then verify that a record exists
                        if ($state == FRIEND_STATE_IGNORE && !$found) {
                            $other = new CB_Friend();
                            $other->IdAccount = $id;
                            $other->IdFriend = $LoggedAccount->Id;
                            $other->State = FRIEND_STATE_IGNORE;
                            $success = $other->Save();
                        }
                    }
                } else {
                    // Verify that it's not already sent or accepted/ignored
                    $recs = CB_Friend::Load($id);
                    $found = FALSE;
                    foreach ($recs as $r) {
                        if ($r->IdFriend == $LoggedAccount->Id) {
                            $found = TRUE;
                            switch ($r->State) {
                                case FRIEND_STATE_ACCEPTED:
                                    $message = "Your request has been accepted";
                                    break;
                                case FRIEND_STATE_REQUEST:
                                    $message = "Your request is pending";
                                    break;
                                default:
                                    $message = "Your request has been declined";
                                    break;
                            }
                            break;
                        }
                    }
                    if (!$found) {
                        // Not found, create a new request to the other's list
                        $rec = new CB_Friend();
                        $rec->IdAccount = $id;
                        $rec->IdFriend = $LoggedAccount->Id;
                        $rec->State = FRIEND_STATE_REQUEST;
                    }
                }
            } else {
                // Friendship acceptance is not required,
                // so just add the other to my list
                $rec = new CB_Friend();
                $rec->IdAccount = $LoggedAccount->Id;
                $rec->IdFriend = $id;
                $rec->State = (isset($_REQUEST["State"]) && $_REQUEST["State"] == FRIEND_STATE_IGNORE ? FRIEND_STATE_IGNORE : FRIEND_STATE_ACCEPTED);
            }
            
            if ($rec)
                $success = $rec->Save();
            if (!$success)
                $message = "An error occurred";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        if ($id < 1) {
            $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
            $user = new CB_Account($username);
            if ($user->Id > 0)
                $id = $user->Id;
        }
        if ($id == $LoggedAccount->Id)
            $message = "You cannot be friend of yourself";
        else if ($id < 1)
            $message = "This user does not exist";
        else {
            $rec = new CB_Friend();
            $rec->IdAccount = $LoggedAccount->Id;
            $rec->IdFriend = $id;
            $success = $rec->Delete();
            if (!$success)
                $message = "An error occurred";
            else /*if (FRIENDS_REQUIRE_ACCEPT)*/ {
                // Delete me from the other's list
                $recOther = new CB_Friend();
                $recOther->IdAccount = $id;
                $recOther->IdFriend = $LoggedAccount->Id;
                $recOther->Delete();
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
