<?php

include_once "lib/api.php";

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Load all Achievements
        case "load":
            wsLoad();
            break;

    // Insert progress into Achievement
    case "progress":
        wsProgress();
        break;

    }
}
exit();

function wsLoad() {
    global $LoggedAccount;
    $records = array();
    if ($LoggedAccount->IsLogged()) {
        $records = CB_Achievement::LoadUserAchievements($LoggedAccount->Id);
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($records, count($records)) );
}

function wsProgress() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get data from REQUEST
        $id = (isset($_REQUEST["IdAchievement"]) ? intval($_REQUEST["IdAchievement"]) : 0);
        $progress = (isset($_REQUEST["Progress"]) ? intval($_REQUEST["Progress"]) : 0);
        if ($progress < 0)
            $progress = 0;
        else if ($progress > 100)
            $progress = 100;
        // Does the achievement exist?
        $achievement = new CB_Achievement($id);
        if ($achievement->Id > 0) {
            $newProgress = 0;
            $cannotRepeat = FALSE;
            $success = $achievement->PostProgress($LoggedAccount, $progress, $newProgress, $cannotRepeat);
            if ($success) {
                // If it was successfully registered, return info to notify the new progress and
                // if the user can continue to progress with this achievement or not
                $message = json_encode(array("Progress" => $newProgress, "Repeat" => $cannotRepeat));
            } else {
                $message = "An error occurred";
            }
        } else {
            $message = "Achievement is invalid";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
