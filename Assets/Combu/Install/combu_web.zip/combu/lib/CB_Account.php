<?

include_once "Database.php";
include_once "IDataClass.php";

class CB_Account extends DataClass {

    const TABLE_NAME = "CB_Account";

    public $Id = 0;
    public $Username = "";
    public $Password = "";
    public $GUID = "";
    public $LastLoginDate = "";
    public $LastLoginIp = "";
    public $Email = "";
    public $ActivationCode = "";
    public $ChangePwdCode = "";
    public $Enabled = 0;
    
    private $Session = NULL;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if (!$src)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src)) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, sprintf("Id = %d", $src));
        } else {
            // Load by Username
            $this->_loadFilter(self::TABLE_NAME, "Username = '" . $Database->Escape($src) . "'");
            if ($this->Id < 1) {
                // Load by Email
                $this->_loadFilter(self::TABLE_NAME, "Email = '" . $Database->Escape($src) . "'");
            }
        }
    }

    /**
     * Check if the current Username already exists
     *
     * @return boolean Returns TRUE if Username exists
     */
    public function ExistsUsername() {
        global $Database;
        $sql = "SELECT Id FROM " . self::TABLE_NAME . " WHERE Username = '" . $Database->Escape($this->Username) . "'";
        if ($this->Id > 0)
            $sql .= " AND Id <> " . $this->Id;
        $res = $Database->Query($sql);
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row)
                return TRUE;
        }
        return FALSE;
    }

    /**
     * Check if the current Email already exists
     *
     * @return boolean Returns TRUE if Username exists
     */
    public function ExistsEmail() {
        global $Database;
        $sql = "SELECT Id FROM " . self::TABLE_NAME . " WHERE Email = '" . $Database->Escape($this->Email) . "'";
        if ($this->Id > 0)
            $sql .= " AND Id <> " . $this->Id;
        $res = $Database->Query($sql);
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row)
                return TRUE;
        }
        return FALSE;
    }

    /**
     * Verify if this account is logged
     *
     * @return bool Returns TRUE if the account is logged
     */
    public function IsLogged() {
        global $LoggedAccount;
        return ($this->Id > 0 && $this->Id == $LoggedAccount->Id && !$this->ActivationCode);
    }
    
    public function IsOnline() {
        $lastAction = $this->GetLastActionDate();
        if ($lastAction) {
            if (time() - Utils::GetTimestamp($lastAction) <= ONLINE_SECONDS)
                return TRUE;
        }
        return FALSE;
    }
    
    public function GetLastActionDate() {
        $sessions = CB_Session::Load($this->Id, $this->GUID);
        if (count($sessions) > 0) {
            return $sessions[0]->LastActionDate;
        }
        return NULL;
    }
    
    /**
     * Get the current session (only for $LoggedAccount)
     * @return CB_Session
     */
    public function GetSession() {
        return $this->Session;
    }

    /**
     * Get the registered accounts
     *
     * @param string $username Filter Username initial
     * @param string $email Filter Email initial
     * @param string[] $customData Filter CustomData (must be an array of associative array: array(array("key"=>"myKey","op"=>"=","value"=>"myValue"))
     * @param boolean $isOnline Filter Online state
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @global Database $Database
     * @return CB_Account[] Returns the array of records
     */
    public static function Load($username = "", $email = "", $customData = NULL, $isOnline = FALSE, $limit = NULL, $offset = NULL, &$count = NULL, $returnArray = FALSE) {
        global $Database;
        $where = "";
        if ($isOnline) {
            $usersOnlineTicks = time() - ONLINE_SECONDS;
            $where .= ($where == "" ? "" : " AND ") . sprintf("(Id IN (SELECT IdAccount FROM %s WHERE LastActionDate >= '%s'))", CB_Session::TABLE_NAME, date("Y-m-d H:i:s", $usersOnlineTicks));
        }
        if ($username != "")
            $where .= ($where == "" ? "" : " AND ") . sprintf("(Username LIKE '%s')", $Database->Escape($username . "%"));
        if ($email != "")
            $where .= ($where == "" ? "" : " AND ") . sprintf("(Email LIKE '%s')", $Database->Escape("%" . $email . "%"));
        if ($customData && is_array($customData) && count($customData) > 0) {
            foreach ($customData as $search_row) {
                if (!is_array($search_row))
                    continue;
                $key = $search_row["key"];
                $op = $search_row["op"];
                $value = $search_row["value"];
                
                if (!is_numeric($value))
                    $value = "'" . $Database->Escape($value) . "'";
                
                $whereCustom = sprintf("(DataKey = '%s' AND DataValue %s %s)", $Database->Escape($key), $op, $value);
                $where .= ($where == "" ? "" : " AND ") . sprintf("(ID IN (SELECT IdAccount FROM %s WHERE %s))", CB_CustomData::TABLE_NAME, $whereCustom);
            }
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Account"), $where, "Username", $limit, $offset, $count);
    }
    
    /**
     * Load users by Id
     * @param int[] $ids Filter Id
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Account[]
     */
    public static function LoadIds($ids, $returnArray = FALSE) {
        if (!$ids || !is_array($ids)) {
            return array();
        }
        $where = sprintf("(Id IN (%s))", implode(",", $ids));
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Account"), $where, "Username");
    }
    
    /**
     * Load users by Id
     * @param int[] $usernames Filter Username
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @global Database $Database
     * @return CB_Account[]
     */
    public static function LoadUsernames($usernames, $returnArray = FALSE) {
        global $Database;
        if (!$usernames || !is_array($usernames)) {
            return array();
        }
        $array_usernames = array();
        foreach ($usernames as $username) {
            $array_usernames[] = "'" . $Database->Escape($username) . "'";
        }
        $where = sprintf("(Username IN (%s))", implode(",", $array_usernames));
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Account"), $where, "Username");
    }

    /**
     * Loads an user object retrieving info from the REQUEST (or a new user object)
     * 
     * @return \self Returns the user object found or a new user object
     */
    public static function LoadRequest() {
        $account = new self();
        $id = intval(filter_input(INPUT_POST, "UID"));
        $guid = filter_input(INPUT_POST, "UGUID");
        if ($id < 1) {
            $id = intval(filter_input(INPUT_GET, "UID"));
        }
        if (!$guid) {
            $guid = filter_input(INPUT_GET, "UGUID");
        }
        if ($id > 0 && $guid) {
            // Load the session
            $session = CB_Session::Load($id, $guid);
            if (count($session) > 0 && !$session[0]->IsExpired()) {
                $account = new self($session[0]->IdAccount);
            }
        }
        if ($account->Id > 0) {
            $account->Session = $session[0];
            $account->GUID = $account->Session->GUID;
            $account->LastLoginDate = $account->Session->LastActionDate;
            $account->LastLoginIp = $account->Session->LastActionIP;
        }
        return $account;
    }

    /**
     * Check if specified login data are correct and the account is active
     *
     * @param string $username Username
     * @param string $password Password
     * @param CB_Account $account Is set to the account found
     * @return boolean Returns TRUE if login is valid
     */
    public static function CheckLogin($username, $password, &$account = null) {
        global $Database;
        $account = null;
        $query = sprintf("SELECT * FROM " . self::TABLE_NAME . " WHERE (Username = '%s' OR Email = '%s') AND Password = '%s'", $Database->Escape($username), $Database->Escape($username), $Database->Escape($password));
        $res = $Database->Query($query);
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row) {
                $account = new self($row);
                return TRUE;
            }
        }
        return FALSE;
    }

    /**
     * Set the specified account as currently logged
     *
     * @param Account $acct Account to be set as current logged
     */
    public static function SetSession(&$account) {
        global $LoggedAccount;
        if ($account && is_a($account, "CB_Account") && $account->Id > 0) {
            if (define("CLEAR_PLAYER_SESSIONS") && CLEAR_PLAYER_SESSIONS === TRUE) {
                CB_Session::ClearSessions($account->Id);
            }
            $account->GUID = uniqid(null, true);
            $LoggedAccount = $account;
            CB_Session::SetSession($account);
        }
    }

    /**
     * Set the specified account as not currently logged
     * @global CB_Account $LoggedAccount
     * @global Database $Database
     */
    public static function UnsetSession() {
        global $LoggedAccount;
        if ($LoggedAccount != NULL && $LoggedAccount->IsLogged()) {
            CB_Session::UnsetSession($LoggedAccount->Id, $LoggedAccount->GUID);
            $LoggedAccount->GUID = "";
        }
        $LoggedAccount = new self();
    }

    /**
     * Log off this account
     * @global CB_Account $LoggedAccount
     */
    public static function Logout() {
        self::UnsetSession();
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (Username, Password, Email, ActivationCode, Enabled) VALUES ('%s', '%s', '%s', '%s', %d)",
                    self::TABLE_NAME,
                    $Database->Escape($this->Username),
                    $Database->Escape($this->Password),
                    $Database->Escape($this->Email),
                    $Database->Escape($this->ActivationCode),
                    $this->Enabled);
        } else {
            $query = sprintf("UPDATE %s SET Username = '%s', Email = '%s', ActivationCode = '%s', ChangePwdCode = '%s', Enabled = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Username),
                    $Database->Escape($this->Email),
                    $Database->Escape($this->ActivationCode),
                    $Database->Escape($this->ChangePwdCode),
                    $this->Enabled,
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
            // Delete all the associated resources
            $this->_Delete(CB_Account_Platform::TABLE_NAME, sprintf("IdAccount = %d", $this->Id));
            $this->_Delete(CB_Friend::TABLE_NAME, sprintf("IdAccount = %d OR IdFriend = %d", $this->Id, $this->Id));
            $this->_Delete(CB_CustomData::TABLE_NAME, "IdAccount = " . $this->Id);
            $this->_Delete(CB_Inventory::TABLE_NAME, "IdAccount = " . $this->Id);
            $this->_Delete(CB_UserFiles::TABLE_NAME, "IdAccount = " . $this->Id);
            $this->_Delete(CB_LeaderBoard_User::TABLE_NAME, "IdAccount = " . $this->Id);
            $this->_Delete(CB_Achievement_User::TABLE_NAME, "IdAccount = " . $this->Id);
            $this->_Delete(CB_Mail::TABLE_NAME, "IdAccount = " . $this->Id);
            return TRUE;
        }
        return FALSE;
    }
    
    /**
     * Updates the signature timestamp
     * 
     * @global Database $Database
     * @param int $timestamp The new signature timestamp
     * @return boolean Returns TRUE on success
     */
    public function UpdateSignature ($timestamp, $newSession = FALSE) {
        if ($this->Id > 0 && $this->GUID) {
            $this->Session = NULL;
            if ($newSession) {
                $session = new CB_Session();
                $session->IdAccount = $this->Id;
                $session->GUID = $this->GUID;
                if ($session->Save())
                    $this->Session = $session;
            } else {
                $session = CB_Session::Load($this->Id, $this->GUID);
                if (count($session) > 0)
                    $this->Session = $session[0];
            }
            if ($this->Session) {
                return $this->Session->UpdateSignature($timestamp);
            }
        }
        return FALSE;
    }
    
    /**
     * Change the password of this account
     * 
     * @global Database $Database
     * @param string $newPassword The new password
     * @return boolean
     */
    public function ChangePassword($newPassword) {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Password = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($newPassword),
                    $this->Id);
            if ($Database->Query($query)) {
                $this->Password = $newPassword;
                return TRUE;
            }
        }
        return FALSE;
    }

    /**
     * Get the registered accounts
     *
     * @param string $excludeIds Filter array of Id to exclude
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If it is TRUE then the function returns an associative array, else it returns an array of Account objects
     * @return CB_Account[] Returns the array of records found as associative array or array of Account objects
     */
    public static function LoadRandom($excludeIds = array(), $customData = NULL, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        global $Database;
        $where = "";
        if (!is_array($excludeIds))
            $excludeIds = array($excludeIds);
        if (count($excludeIds) > 0) {
            $ids = array();
            foreach ($excludeIds as $id) {
                if ($id > 0)
                    $ids[] = intval($id);
            }
            $where .= ($where == "" ? "" : " AND ") . "Id NOT IN (" . implode(",", $excludeIds) . ")";
        }
        if ($customData && is_array($customData) && count($customData) > 0) {
            foreach ($customData as $search_row) {
                if (!is_array($search_row))
                    continue;
                $key = $search_row["key"];
                $op = $search_row["op"];
                $value = $search_row["value"];
                
                if (!is_numeric($value))
                    $value = "'" . $Database->Escape($value) . "'";
                
                $whereCustom = sprintf("(DataKey = '%s' AND DataValue %s %s)", $Database->Escape($key), $op, $value);
                $where .= ($where == "" ? "" : " AND ") . sprintf("(ID IN (SELECT IdAccount FROM %s WHERE %s))", CB_CustomData::TABLE_NAME, $whereCustom);
            }
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Account"), $where, "RAND()", $limit, $offset, $count);
    }

    /**
     * Get the registered accounts who are friends of a user
     *
     * @param int $excludeIds Filter Id of user
     * @param int[] $excludeIds Filter array of Id to exclude
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If it is TRUE then the function returns an associative array, else it returns an array of Account objects
     * @return CB_Account[] Returns the array of records found as associative array or array of Account objects
     */
    public static function LoadRandomFriends($idUser, $excludeIds = array(), $customData = NULL, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        global $Database;
        $where = sprintf("(Id IN (SELECT IdFriend FROM %s WHERE IdAccount = %d AND State = %d))", CB_Friend::TABLE_NAME, $idUser, FRIEND_STATE_ACCEPTED);
        if (!is_array($excludeIds))
            $excludeIds = array($excludeIds);
        if (count($excludeIds) > 0) {
            $ids = array();
            foreach ($excludeIds as $id) {
                if ($id > 0)
                    $ids[] = intval($id);
            }
            if (count($ids) > 0)
                $where .= ($where == "" ? "" : " AND ") . "(Id NOT IN (" . implode(",", $ids) . "))";
        }
        if ($customData && is_array($customData) && count($customData) > 0) {
            foreach ($customData as $search_row) {
                if (!is_array($search_row))
                    continue;
                $key = $search_row["key"];
                $op = $search_row["op"];
                $value = $search_row["value"];
                
                if (!is_numeric($value))
                    $value = "'" . $Database->Escape($value) . "'";
                
                $whereCustom = sprintf("(DataKey = '%s' AND DataValue %s %s)", $Database->Escape($key), $op, $value);
                $where .= ($where == "" ? "" : " AND ") . sprintf("(ID IN (SELECT IdAccount FROM %s WHERE %s))", CB_CustomData::TABLE_NAME, $whereCustom);
            }
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Account"), $where, "RAND()", $limit, $offset, $count);
    }
    
    /**
     * Create a user with a random Username
     * @param string $prefix String to prepend to the Username
     * @return boolean Returns TRUE on success
     */
    public static function CreateRandom($prefix, &$account = NULL) {
        $account = NULL;
        $new = new self();
        $new->Username = "__TEMP__" . session_id() . "_" . time();
        if ($new->Save()) {
            $new->Username = $prefix . $new->Id;
            $new->Save();
            $account = $new;
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Returns the JSON representation of this object
     * 
     * @return string JSON string
     */
    public function ToJson () {
        $array = $this->ToArray();
        return json_encode($array);
    }
    
    /**
     * Returns the array representation of this object
     * 
     * @global CB_Account $LoggedAccount
     * @return array Array of properties/values
     */
    public function ToArray () {
        global $LoggedAccount;
        $array = array();
        if ($this->Id > 0 || $this->Username) {
            $array = Utils::ObjectToArray($this);
            // Remove Password from any response
            unset($array["Password"]);
            // Remove GUID token and other personal info from response if it's not me
            if ($this->Id > 0 && $this->Id == $LoggedAccount->Id) {
                $array["GUID"] = $LoggedAccount->GUID;
            } else {
                unset($array["GUID"]);
                unset($array["Email"]);
            }
            // Rename signature timestamp in something more user-friendly :P
            $lastAction = $this->GetLastActionDate();
            if ($lastAction)
                $array["LastSeen"] = $lastAction;
            unset($array["SignatureTimestamp"]);
            // Add Custom data
            $array["CustomData"] = array();
            $customData = CB_CustomData::Load($this->Id);
            foreach ($customData as $data) {
                $array["CustomData"][$data->DataKey] = $data->DataValue;
            }
            // Add Platforms
            $array["Platforms"] = array();
            $platforms = CB_Account_Platform::Load($this->Id);
            foreach ($platforms as $platform) {
                $array["Platforms"][] = $platform->ToArray();
            }
        }
        return $array;
    }
    
    public function ToArrayFiltered() {
        $array = $this->ToArray();
        unset($array["LastLoginDate"]);
        unset($array["LastLoginIp"]);
        unset($array["ActivationCode"]);
        unset($array["ChangePwdCode"]);
        unset($array["Enabled"]);
        $customData = $array["CustomData"];
        AddonModule::ProcessOutputUserCustomData($this, $customData);
        if (!$customData)
            $customData = array();
        else if (!is_array($customData))
            $customData = array($customData);
        $array["CustomData"] = $customData;
        return $array;
    }
    
    public function ToJsonFiltered() {
        $array = $this->ToArrayFiltered();
        return json_encode($array);
    }
}
