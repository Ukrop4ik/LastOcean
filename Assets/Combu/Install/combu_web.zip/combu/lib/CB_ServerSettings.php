<?php

include_once "Database.php";
include_once "IDataClass.php";

/**
 * Class to handle User Custom Data
 *
 * @author Skared Creations
 */
class CB_ServerSettings extends DataClass {

    const TABLE_NAME = "CB_ServerSettings";

    public $DataKey = "";
    public $DataValue = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }
    
    /**
     * Get the current server settings as associative array
     * 
     * @return array Current server settings
     */
    public static function GetCurrentSettings() {
        $settings = array();
        $recs = self::Load();
        foreach ($recs as $rec) {
            $settings[$rec->DataKey] = $rec->DataValue;
        }
        return $settings;
    }

    /**
     * Get the registered server settings
     *
     * @return CB_ServerSettings[] Returns the array of records
     */
    public static function Load () {
        return self::_load(self::TABLE_NAME, "CB_ServerSettings");
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $query = sprintf("REPLACE INTO %s (DataKey, DataValue) VALUES ('%s', '%s')",
                self::TABLE_NAME,
                $Database->Escape($this->DataKey),
                $Database->Escape($this->DataValue));
        return $Database->Query($query);
    }
    
    /**
     * Delete the record from the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        global $Database;
        if ($this->DataKey) {
            return $this->_Delete(self::TABLE_NAME, sprintf("DataKey = '%s'", $Database->Escape($this->DataKey)));
        }
        return FALSE;
    }
}
