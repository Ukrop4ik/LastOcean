<?php

/**
 * Class to handle Tournaments
 *
 * @author Skared Creations
 */
class CB_Tournament extends DataClass {
    
    const TABLE_NAME = "CB_Tournament";

    public $Id = 0;
    public $IdOwner = 0;
    public $Title = "";
    public $DateCreation = NULL;
    public $DateFinished = NULL;
    public $CustomData = "";
    public $Finished = 0;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }
    
    /**
     * Load matches corresponding to the filters
     * @global Database $Database
     * @param boolean $finished Filter Finished
     * @param string $title Filter Title as REGEXP
     * @param array $customData Filter CustomData (must be an array of associative arrays: [{"key1":"value"},{"key2":"value"}])
     * @param string $order
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param bool $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Tournament[]
     */
    public static function Load($finished = FALSE, $title = NULL, $customData = array(), $order = NULL, $limit = NULL, $offset = NULL, $count = NULL, $returnArray = FALSE) {
        global $Database;
        $where = "";
        if (!$finished) {
            $where .= ($where ? " AND " : "") . "(DateFinished IS NULL)";
        }
        if ($title) {
            $where .= sprintf(" AND (Title REGEXP '%s')", $Database->Escape($title));
        }
        if ($customData && is_array($customData)) {
            $whereCustom = "";
            foreach ($customData as $search_row) {
                if (!is_array($search_row)) {
                    continue;
                }
                $key = $search_row["key"];
                $op = $search_row["op"];
                $value = $search_row["value"];
                $whereCustom .= ($whereCustom == "" ? "" : " AND ") . sprintf("(DataKey = '%s' AND DataValue %s '%s')", $Database->Escape($key), $op, $Database->Escape($value));
            }
            if ($whereCustom) {
                $where .= ($where == "" ? "" : " AND ") . sprintf("(Id IN (SELECT IdTournament FROM %s WHERE %s))", CB_Tournament_CustomData::TABLE_NAME, $whereCustom);
            }
        }
        if (!$order) {
            $order = "Id DESC";
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Tournament"), $where, $order, $limit, $offset, $count);
    }
    
    /**
     * Save the record in the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Title = '%s', DateFinished = %s, Finished = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $Database->EscapeDate($this->DateFinished),
                    $this->Finished,
                    $this->Id);
        } else {
            $this->DateCreation = date("Y-m-d H:i:s");
            $this->DateFinished = NULL;
            $query = sprintf("INSERT INTO %s (IdOwner, Title, DateCreation, DateFinished, Finished) VALUES (%d, '%s', %s, NULL, 0)",
                    self::TABLE_NAME,
                    $this->IdOwner,
                    $Database->Escape($this->Title),
                    $Database->EscapeDate($this->DateCreation));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1) {
                $this->Id = $Database->InsertedId();
            }
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id > 0) {
            if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
                // Delete Tournament Custom Data and all Matches
                $this->_Delete(CB_Tournament_CustomData::TABLE_NAME, "IdTournament = " . $this->Id);
                $matches = CB_Match::Load($this->Id);
                foreach ($matches as $match) {
                    $match->Delete();
                }
                return TRUE;
            }
        }
        return FALSE;
    }
    
    /**
     * Check if all the matches are finished
     */
    public function CheckFinished() {
        $allMatches = TRUE;
        $matches = CB_Match::Load($this->Id);
        foreach ($matches as $m) {
            if ($m->Finished != 1) {
                $allMatches = FALSE;
                break;
            }
        }
        if ($allMatches) {
            $this->Finished = 1;
            $this->Save();
        }
    }
    
    public function ToArray() {
        $array = Utils::ObjectToArray($this);
        // Add the Tournament Custom Data
        $array["CustomData"] = array();
        $customData = CB_Tournament_CustomData::Load($this->Id);
        foreach ($customData as $data) {
            $array["CustomData"][$data->DataKey] = $data->DataValue;
        }
        // Add the Owner
        $owner = new CB_Account($this->IdOwner);
        if ($owner->Id > 0) {
            $array["Owner"] = $owner->ToJson();
        }
        // Add the Matches
        $array["Matches"] = array();
        $matches = CB_Match::Load($this->Id);
        foreach ($matches as $i) {
            $array["Matches"][] = $i->ToArray();
        }
        // Return the full array
        return $array;
    }
    
    public function ToJson() {
        $array = $this->ToArray();
        return json_encode($array);
    }
}

/**
 * Class to handle Match Custom Data
 * 
 * @author Skared Creations
 */
class CB_Tournament_CustomData extends DataClass {

    const TABLE_NAME = "CB_Tournament_CustomData";

    public $IdTournament = 0;
    public $DataKey = "";
    public $DataValue = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }

    /**
     * Get the registered custom data
     *
     * @param string $idTournament Filter IdTournament
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Tournament_CustomData[]
     */
    public static function Load ($idTournament, $returnArray = false) {
        $where = sprintf("IdTournament = %d", $idTournament);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Tournament_CustomData"), $where);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $query = sprintf("REPLACE INTO %s (IdTournament, DataKey, DataValue) VALUES (%d, '%s', '%s')",
                self::TABLE_NAME,
                $this->IdTournament,
                $Database->Escape($this->DataKey),
                $Database->Escape($this->DataValue));
        return $Database->Query($query);
    }
    
    /**
     * Delete the record from the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        global $Database;
        if ($this->IdTournament > 0 && $this->DataKey) {
            return $this->_Delete(self::TABLE_NAME, sprintf("IdTournament = %d AND DataKey = '%s'", $this->IdTournament, $Database->Escape($this->DataKey)));
        }
        return FALSE;
    }
}
