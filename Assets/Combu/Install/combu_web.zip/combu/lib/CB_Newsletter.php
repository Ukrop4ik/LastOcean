<?php

define ("NEWSLETTER_STATUS_READY", 0);
define ("NEWSLETTER_STATUS_SENT", 1);

include_once 'CB_NewsletterLog.php';

/**
 * Class to handle Newsletter
 *
 * @author Skared Creations
 */
class CB_Newsletter extends DataClass {

    const TABLE_NAME = "CB_Newsletter";

    public $Id = 0;
    public $IdAccount = 0;
    public $Subject = "";
    public $Body = "";
    public $IsHtml = 1;
    public $DateCreation = "";
    public $DateSent = "";
    public $Status = NEWSLETTER_STATUS_READY;
    public $LogMessage = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered inventory items
     *
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($limit = null, $offset = null, &$count = null, $returnArray = false) {
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Newsletter"), NULL, NULL, $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Subject = '%s', Body = '%s', Status = %d, DateSent = %s, LogMessage = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Body),
                    $this->Status,
                    $Database->EscapeDate($this->DateSent),
                    $Database->Escape($this->LogMessage),
                    $this->Id);
        } else {
            $this->DateCreation = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (IdAccount, Subject, Body, IsHtml, DateCreation, Status, LogMessage) VALUES (%d, '%s', '%s', %d, %s, %d, '{}')",
                    self::TABLE_NAME,
                    $this->IdAccount,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Body),
                    $this->IsHtml,
                    $Database->EscapeDate($this->DateCreation),
                    $this->Status);
        }
        //echo "<pre>".  htmlentities($query, ENT_QUOTES)."</pre>";
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
    
    /**
     * Send this Newsletter to all players
     * 
     * @return boolean Returns TRUE on success
     */
    public function Send() {
        if ($this->Id > 0 && $this->Status != NEWSLETTER_STATUS_SENT) {
            $this->DateSent = date("Y-m-d H:i:s");
            $this->Status = NEWSLETTER_STATUS_SENT;
            $sent = 0;
            $skipped = 0;
            $errors = 0;
            $accounts = CB_Account::Load();
            foreach ($accounts as $account) {
                if (!$account->Email) {
                    $skipped++;
                } else {
                    $recordLog = new CB_NewsletterLog();
                    $recordLog->IdNewsletter = $this->Id;
                    $recordLog->IdAccount = $account->Id;
                    $mail = new Mail();
                    $mail->prepare($this->Subject, $this->Body, $account->Email, NEWSLETTER_SENDER_ADDRESS, NEWSLETTER_SENDER_NAME);
                    if ($mail->Send()) {
                        $sent++;
                        $recordLog->Sent = TRUE;
                    } else {
                        $errors++;
                        $recordLog->Sent = FALSE;
                        $recordLog->Message = $mail->ErrorInfo;
                    }
                    $recordLog->Save();
                }
            }
            $this->LogMessage = json_encode(array( "sent" => $sent, "skipped" => $skipped, "errors" => $errors ));
            $this->Save();
            return TRUE;
        }
        return FALSE;
    }
}
