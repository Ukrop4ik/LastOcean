<?php

/**
 * Class to handle User Files
 *
 * @author Skared Creations
 */
class CB_UserFiles extends DataClass {

    const TABLE_NAME = "CB_UserFile";

    public $Id = 0;
    public $IdAccount = 0;
    public $Name = "";
    public $Url = "";
    public $ShareType = SHARETYPE_EVERYBODY;
    public $Likes = 0;
    public $Views = 0;
    public $CustomData = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered files
     *
     * @param int $idAccount Filter IdAccount
     * @param boolean $includeShared If TRUE then it will include also the files shared by other users with the account
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @return array Returns the array of records
     */
    public static function Load ($idAccount, $includeShared = false, $returnArray = false, $limit = NULL, $offset = NULL, &$count = NULL) {
        // Load the files from account's storage, files shared by others and files shared by friends
        $where = "IdAccount = " . $idAccount;
        if ($includeShared) {
            $where .= " OR ShareType = " . SHARETYPE_EVERYBODY .
                " OR (ShareType = " . SHARETYPE_FRIENDS . " AND IdAccount IN (SELECT IdAccount FROM " . CB_Friend::TABLE_NAME . " WHERE IdFriend = " . $idAccount . " AND State = " . FRIEND_STATE_ACCEPTED . "))";
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_UserFiles"), $where, "Id", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Name = '%s', Url = '%s', ShareType = %d, CustomData = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Name),
                    $Database->Escape($this->Url),
                    $this->ShareType,
                    $Database->Escape($this->CustomData),
                    $this->Id);
        } else {
            $query = sprintf("INSERT INTO %s (IdAccount, Name, Url, ShareType, Likes, Views, CustomData) VALUES (%d, '%s', '%s', %d, 0, 0, '%s')",
                    self::TABLE_NAME,
                    $this->IdAccount,
                    $Database->Escape($this->Name),
                    $Database->Escape($this->Url),
                    $this->ShareType,
                    $Database->Escape($this->CustomData));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
    
    /**
     * Increments the Likes count
     * 
     * @global type $LoggedAccount
     * @return boolean Returns TRUE on success
     */
    public function AddLike () {
        global $LoggedAccount, $Database;
        if ($this->Id > 0) {
            // Try to save the new count
            $this->Likes++;
            $query = sprintf("UPDATE %s SET Likes = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Likes,
                    $this->Id);
            if ($Database->Query($query)) {
                // Add an activity log of the logged user
                if ($LoggedAccount->IsLogged()) {
                    $activity = new CB_UserFilesActivity();
                    $activity->IdFile = $this->Id;
                    $activity->IdAccount = $LoggedAccount->Id;
                    $activity->Likes = 1;
                    $activity->Save();
                }
                return TRUE;
            }
            // If the SQL statement failed then bring back the old count
            $this->Likes--;
        }
        return FALSE;
    }
    
    /**
     * Increments the Views count
     * 
     * @global type $LoggedAccount
     * @return boolean Returns TRUE on success
     */
    public function AddView () {
        global $LoggedAccount, $Database;
        if ($this->Id > 0) {
            // Try to save the new count
            $this->Views++;
            $query = sprintf("UPDATE %s SET Views = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Views,
                    $this->Id);
            if ($Database->Query($query)) {
                // Add an activity log of the logged user
                if ($LoggedAccount->IsLogged()) {
                    $activities = CB_UserFilesActivity::Load($this->Id, $LoggedAccount->Id);
                    if (count($activities) == 0) {
                        $activity = new CB_UserFilesActivity();
                        $activity->IdFile = $this->Id;
                        $activity->IdAccount = $LoggedAccount->Id;
                    } else {
                        $activity = $activities[0];
                    }
                    $activity->Views++;
                    $activity->Save();
                }
                return TRUE;
            }
            // If the SQL statement failed then bring back the old count
            $this->Views--;
        }
        return FALSE;
    }
}
