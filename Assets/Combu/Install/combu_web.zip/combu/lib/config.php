<?

// Define the relative URL of the website, including the last path separator (e.g.: "/your_path/")
// This will be used when need to return full URL path to files
define ("URL_ROOT", "/combu/");

// Shared secret key used to secure the webservices request
// (i.e.: you can use http://www.random.org/passwords/ to generate a random string with 24 characters)
define ("SECRET_KEY", "changeme");

/**
 * Database connection settings
 **/
// Server hostname
define ("GAME_DB_SERVER", "localhost");
// Database name
define ("GAME_DB_NAME", "combu");
// User
define ("GAME_DB_USER", "root");
// Password
define ("GAME_DB_PASS", "");

// Security option to skip the timestamp check of user on database
// (disabled by default, enable it only if you are sure that you haven't multiple webservice calls running)
//define("SKIP_USER_TIMESTAMP", FALSE);

// User registration settings
define ("REGISTER_EMAIL_REQUIRED", FALSE); // Is Email required for new users?
define ("REGISTER_EMAIL_MULTIPLE", FALSE); // Allow multiple accounts with the same email?
define ("REGISTER_EMAIL_ACTIVATION", FALSE); // Should verify email registration with activation code?
define ("REGISTER_EMAIL_SUBJECT", "Confirm account registration"); // The regitration mail subject (if activation code is required)
define ("REGISTER_EMAIL_MESSAGE", LIBROOT . "/email_register.html"); // Path to the HTML/text file containing the mail message
define ("REGISTER_EMAIL_HTML", TRUE); // Is the email content HTML or plain text?
define ("RESETPWD_EMAIL_SUBJECT", "Reset your password"); // The regitration mail subject (if activation code is required)
define ("RESETPWD_EMAIL_MESSAGE", LIBROOT . "/email_resetpwd.html"); // Path to the HTML/text file containing the mail message

// Friendship settings
define ("FRIENDS_REQUIRE_ACCEPT", FALSE); // Is required acceptance for friendship?

// Time interval in seconds to consider a user online
define ("ONLINE_SECONDS", 120);

// Should delete older players login sessions?
define ("CLEAR_PLAYER_SESSIONS", FALSE);

// Email settings
define ("EMAIL_SENDER_ADDRESS", "admin@myserver.ext");
define ("EMAIL_SENDER_NAME", "Combu Admin");

// Newsletter settings
define ("NEWSLETTER_SENDER_ADDRESS", "noreply@myserver.ext");
define ("NEWSLETTER_SENDER_NAME", "Combu Newsletter");

// This is the default size of a list when limit is not specified in the REQUEST
define ("DEFAULT_LIST_LIMIT", 20);

// Path to the log file
define ("LOG_FILEPATH", dirname(dirname(__FILE__)) . "/_logs/applog.log");
// Max size in bytes of the log file (if it reaches this size the system will backup the current)
define ("LOG_MAXFILESIZE", 2048);

// Upload stuff
define ("URL_UPLOAD", "upload/");
define ("UPLOAD", dirname(dirname(__FILE__)) . "/upload/");

// Prefix to id for Username of guest accounts
define ("GUEST_PREFIX", "Guest-");

// Expire sessions (must be a valid parameter for DateInterval constructor) http://php.net/manual/en/class.dateinterval.php
define ("EXPIRE_CLIENT_SESSION", "PT1H"); // comment this line to disable account session expiration
