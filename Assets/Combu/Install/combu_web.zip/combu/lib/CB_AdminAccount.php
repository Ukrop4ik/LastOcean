<?

include_once "Database.php";
include_once "IDataClass.php";

class CB_AdminAccount extends DataClass {

    const TABLE_NAME = "CB_AdminAccount";

    public $Id = 0;
    public $Username = "";
    public $Password = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        } else {
            // Load by Username
            $this->_loadFilter(self::TABLE_NAME, "Username = '" . $Database->Escape($src) . "'");
        }
    }

    /**
     * Check if the current Username already exists
     *
     * @return boolean Returns TRUE if Username exists
     */
    public function ExistsUsername() {
        global $Database;
        $sql = "SELECT Id FROM " . self::TABLE_NAME . " WHERE Username = '" . $Database->Escape($this->Username) . "'";
        if ($this->Id > 0)
            $sql .= " AND Id <> " . $this->Id;
        $res = $Database->Query($sql);
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row)
                return TRUE;
        }
        return FALSE;
    }

    /**
     * Verify if this account is logged
     *
     * @return bool Returns TRUE if the account is logged
     */
    public function IsLogged() {
        global $AdminLogged;
        return ($this->Id > 0 && $this->Id == $AdminLogged->Id);
    }

    /**
     * Get the registered accounts
     *
     * @param string $username Filter Username initial
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If it is TRUE then the function returns an associative array, else it returns an array of Account objects
     * @return array Returns the array of records found as associative array or array of Account objects
     */
    public static function Load($username = "", $limit = null, $offset = null, &$count = null, $returnArray = false) {
        global $Database;
        $where = "";
        if ($username != "")
            $where .= ($where == "" ? "" : " AND ") . "Username LIKE '" . $Database->Escape($username) . "%'";
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_AdminAccount"), $where, "Username", $limit, $offset, $count);
    }

    /**
     * Check if specified login data are correct and the account is active
     *
     * @param string $username Username
     * @param string $password Password
     * @param int &$id Is set to the Id of the found account
     * @return bool Returns TRUE if login is valid
     */
    public static function CheckLogin($username, $password, &$account = null) {
        global $Database;
        $account = null;
        $query = sprintf("SELECT * FROM " . self::TABLE_NAME . " WHERE Username = '%s' AND Password = '%s'", $Database->Escape($username), $Database->Escape(md5($password)));
        $res = $Database->Query($query);
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row) {
                $account = new self($row);
                return TRUE;
            }
        }
        return FALSE;
    }

    /**
     * Returns the account that is currently logged
     *
     * @return Account Account that is current logged
     */
    public static function GetSession() {
        $id = (!isset($_SESSION["AdminId"]) ? 0 : intval($_SESSION["AdminId"]));
        $account = new self($id);
        return $account;
    }

    /**
     * Set the specified account as currently logged
     *
     * @param Account $acct Account to be set as current logged
     */
    public static function SetSession(&$account) {
        global $AdminLogged, $Database;
        if ($account && is_a($account, "CB_AdminAccount") && $account->Id > 0) {
            $AdminLogged = $account;
            $_SESSION["AdminId"] = $account->Id;
        }
    }

    /**
     * Set the specified account as not currently logged
     */
    public static function UnsetSession() {
        global $AdminLogged;
        $AdminLogged = new self();
        $_SESSION["AdminId"] = 0;
    }

    /**
     * Log off this account
     */
    public static function Logout() {
        self::UnsetSession();
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (Username, Password) VALUES ('%s', '%s')",
                    self::TABLE_NAME,
                    $Database->Escape($this->Username),
                    $Database->Escape($this->Password));
        } else {
            $query = sprintf("UPDATE %s SET Username = '%s', Password = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Username),
                    $Database->Escape($this->Password),
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }

    public function ToJson () {
        if ($this->Id < 1)
            return json_decode(array());
        $array = Utils::ObjectToArray($this);
        // Remove password from response
        unset($array["Password"]);
        return json_encode($array);
    }
}
