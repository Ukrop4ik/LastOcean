<?php

/**
 * Class to handle User Files' Activity from Accounts
 *
 * @author Skared Creations
 */
class CB_UserFilesActivity extends DataClass {

    const TABLE_NAME = "CB_UserFilesActivity";

    public $Id = 0;
    public $IdFile = 0;
    public $IdAccount = 0;
    public $Likes = 0;
    public $Views = 0;
    public $LastActivity = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered files
     *
     * @param string $idFile Filter IdFile
     * @param string $idAccount Filter IdAccount
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_UserFilesActivity[] Returns the array of records
     */
    public static function Load ($idFile = 0, $idAccount = 0, $returnArray = false) {
        $where = "";
        if ($idFile > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdFile = %d)", $idFile);
        if ($idAccount > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdAccount = %d)", $idAccount);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_UserFilesActivity"), $where);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $this->LastActivity = date("Y-m-d H:i:s");
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Likes = %d, Views = %d, LastActivity = %s WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Likes,
                    $this->Views,
                    $Database->EscapeDate($this->LastActivity),
                    $this->Id);
        } else {
            $query = sprintf("INSERT INTO %s (IdFile, IdAccount, LastActivity, Likes, Views) VALUES (%d, %d, %s, %d, %d)",
                    self::TABLE_NAME,
                    $this->IdFile,
                    $this->IdAccount,
                    $Database->EscapeDate($this->LastActivity),
                    $this->Likes,
                    $this->Views);
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
