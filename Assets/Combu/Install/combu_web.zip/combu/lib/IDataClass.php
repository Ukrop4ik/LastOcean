<?php

require_once "Database.php";

/**
 * Standard interface for database table classes
 */
interface IDataClass {

    public function Save();

    public function Delete();
}

/**
 * Standard base class for database table classes
 */
class DataClass implements IDataClass {

    /**
     * Load record data from a filter
     *
     * @param string $tableName Name of the table
     * @param string $filter Filter to apply
     *
     */
    protected function _loadFilter($tableName, $filter) {
        global $Database;
        $res = $Database->Query("SELECT * FROM $tableName WHERE $filter");
        if ($res) {
            $row = $Database->Fetch($res);
            if ($row)
                $this->_loadByRow($row);
        }
    }

    /**
     * Initialize the current object from an associative array
     *
     * @param array $row Associative array to load
     */
    protected function _loadByRow($row, $stripSlashes = false, $callbackOnExists = false) {
        Utils::FillObjectFromRow($this, $row, $stripSlashes, $callbackOnExists);
    }

    /**
     * Returns the records count from a query
     *
     * @param string $filter If specified it is specified as WHERE clause (do not include 'WHERE')
     * @return int Records count
     */
    protected static function _count($tableName, $filter = null) {
        global $Database;
        $query = "SELECT COUNT(*) FROM " . $tableName;
        if ($filter != null)
            $query .= " WHERE " . $filter;
        $res = $Database->Query($query);
        if ($res) {
            $row = $Database->Fetch($res, MYSQL_NUM);
            if ($row)
                return intval($row[0]);
        }
        return 0;
    }

    /**
     * Load the records from a table with specified WHERE, ORDER and LIMIT clauses
     * @param string $tableName
     * @param string $returnedClass The class name to convert records, if empty then returns associative array
     * @param string $where Clause WHERE
     * @param string $order Clause ORDER BY
     * @param int $limit Clause LIMIT count
     * @param int $offset Clause LIMIT offset
     * @param int $count If not NULL then this will be set to total COUNT (no LIMIT clause)
     * @return array
     */
    protected static function _load($tableName, $returnedClass = "", $where = "", $order = null, $limit = null, $offset = null, &$count = null) {
        return self::_loadEx(null, $tableName, $returnedClass, $where, $order, $limit, $offset, $count);
    }

    protected static function _loadEx($select, $from, $returnedClass = "", $where = "", $order = null, $limit = null, $offset = null, &$count = null, $debug = false) {
        global $Database;
        if ($count !== null) {
            // Count the total results
            $count = self::_count($from, $where);
        }

        $query = "SELECT " . ($select ? $select : "*") . " FROM $from";

        if ($where != "")
            $query .= " WHERE " . $where;

        if ($order != null)
            $query .= " ORDER BY $order";

        if ($limit != null)
            $query .= " LIMIT " . ($offset > 0 ? "$offset," : "") . $limit;

        if ($debug === true)
            AppLog::Info($query);

        return self::_loadQuery($query, $returnedClass);
    }

    protected static function _loadQuery($query, $returnedClass = "") {
        global $Database;
        $rows = array();
        $res = $Database->Query($query);
        if ($res) {
            while ($row = $Database->Fetch($res)) {
                $rows[] = ($returnedClass == "" ? $row : new $returnedClass($row));
            }
        }
        return $rows;
    }

    /**
     * Load the records from a query
     * @param string $query Statement SQL
     * @param string $returnedClass Class name to convert the returned objects, if empty then returns associative arrays
     * @return array
     */
    public static function LoadRecords($query, $returnedClass = "") {
        return self::_loadQuery($query, $returnedClass);
    }

    /**
     * Count the records from a table with specified filter
     * @param string $tableName Table name
     * @param string $filter Clause WHERE
     * @return int
     */
    public static function CountRecords($tableName, $filter = null) {
        return self::_count($tableName, $filter);
    }

    /**
     * Save to database the current object
     * @return boolean TRUE on successful operation
     */
    public function Save() {
        return FALSE;
    }

    /**
     * Delete the current object from database
     * @return boolean TRUE on successful operation
     */
    public function Delete() {
        return FALSE;
    }

    /**
     * Delete a record from the table with the specified filter
     * @global Database $Database
     * @param string $tableName Table name
     * @param string $filter Clause WHERE
     * @return boolean TRUE on successful operation
     */
    protected function _Delete($tableName, $filter = null) {
        global $Database;
        if ($filter) {
            if ($Database->Query("DELETE FROM $tableName WHERE $filter"))
                return TRUE;
        }
        return FALSE;
    }

    /**
     * Returns this object in JSON format
     * @return string The formatted object
     */
    public function ToJson () {
        return json_encode($this->ToArray());
    }

    public function ToArray() {
        return Utils::ObjectToArray($this);
    }
}
