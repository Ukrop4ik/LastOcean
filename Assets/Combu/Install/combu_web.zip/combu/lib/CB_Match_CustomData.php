<?php

/**
 * This class handles the Match Custom Data
 * 
 * @author Skared Creations
 */
class CB_Match_CustomData extends DataClass {

    const TABLE_NAME = "CB_Match_CustomData";

    public $IdMatch = 0;
    public $DataKey = "";
    public $DataValue = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }

    /**
     * Get the registered custom data
     *
     * @param string $idMatch Filter IdMatch
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Match_CustomData[]
     */
    public static function Load ($idMatch, $returnArray = false) {
        $where = sprintf("IdMatch = %d", $idMatch);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Match_CustomData"), $where);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $query = sprintf("REPLACE INTO %s (IdMatch, DataKey, DataValue) VALUES (%d, '%s', '%s')",
                self::TABLE_NAME,
                $this->IdMatch,
                $Database->Escape($this->DataKey),
                $Database->Escape($this->DataValue));
        return $Database->Query($query);
    }
    
    /**
     * Delete the record from the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        global $Database;
        if ($this->IdMatch > 0 && $this->DataKey) {
            return $this->_Delete(self::TABLE_NAME, sprintf("IdMatch = %d AND DataKey = '%s'", $this->IdMatch, $Database->Escape($this->DataKey)));
        }
        return FALSE;
    }
}
