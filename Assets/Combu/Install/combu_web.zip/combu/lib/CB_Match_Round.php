<?php

/**
 * This class handles the Match Rounds
 *
 * @author Skared Creations
 */
class CB_Match_Round extends DataClass {
    
    const TABLE_NAME = "CB_Match_Round";

    public $Id = 0;
    public $IdMatchAccount = 0;
    public $Score = 0;
    public $DateScore = NULL;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }
    
    /**
     * Load matches corresponding to the filters
     * @global Database $Database
     * @param int $idMatchAccount Filter IdMatchAccount
     * @return CB_Match_Round[]
     */
    public static function Load($idMatchAccount = 0) {
        global $Database;
        $where = "";
        if ($idMatchAccount > 0) {
            $where .= ($where == "" ? "" : " AND ") . sprintf("(IdMatchAccount = %d)", $idMatchAccount);
        }
        return self::_load(self::TABLE_NAME, "CB_Match_Round", $where);
    }
    
    /**
     * Save the record in the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Score = %f, DateScore = %s WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Score,
                    $Database->EscapeDate($this->DateScore),
                    $this->Id);
        } else {
            $this->DateCreation = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (IdMatchAccount, Score, DateScore) VALUES (%d, %f, %s)",
                    self::TABLE_NAME,
                    $this->IdMatchAccount,
                    $this->Score,
                    $Database->EscapeDate($this->DateScore));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1) {
                $this->Id = $Database->InsertedId();
            }
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id > 0) {
            if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
                $this->_Delete(CB_Match_CustomData::TABLE_NAME, "IdMatch = " . $this->Id);
                $this->_Delete(CB_Match_Account::TABLE_NAME, "IdMatch = " . $this->Id);
                return TRUE;
            }
        }
        return FALSE;
    }
}
