<?php

include_once "Database.php";
include_once "IDataClass.php";
include_once "CB_Achievement_User.php";

/**
 * Class to handle Achievement
 *
 * @author Skared Creations
 */
class CB_Achievement extends DataClass {

    const TABLE_NAME = "CB_Achievement";

    public $Id = 0;
    public $Title = "";
    public $Description = "";
    public $UniqueRecords = 1;
    public $Position = 0;


    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered leaderboards
     *
     * @param string $idAccount Filter IdAccount
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($limit = null, $offset = null, &$count = null, $returnArray = false) {
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Achievement"), "", "Position", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id < 1) {
            $this->Position = self::GetNextPosition();
            $query = sprintf("INSERT INTO %s (Title, Description, UniqueRecords, Position) VALUES ('%s', '%s', %d, %d)",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $Database->Escape($this->Description),
                    $this->UniqueRecords,
                    $this->Position);
        } else {
            $query = sprintf("UPDATE %s SET Title = '%s', Description = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $Database->Escape($this->Description),
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }
    
    private static function GetNextPosition() {
        $maxPosition = 0;
        $count = self::CountRecords(self::TABLE_NAME);
        if ($count > 0)
            $maxPosition = $count;
        return $maxPosition;
    }
    
    public function MoveUp() {
        global $Database;
        if ($this->Id > 0 && $this->Position > 0) {
            // Calculate the desired position
            $newPosition = $this->Position - 1;
            // Try to update the early positions
            $query = sprintf("UPDATE %s SET Position = Position + 1 WHERE Position = %d",
                    self::TABLE_NAME, $newPosition);
            if ($Database->Query($query)) {
                // Try to update the current position
                $query = sprintf("UPDATE %s SET Position = %d WHERE Id = %d",
                        self::TABLE_NAME, $newPosition, $this->Id);
                if ($Database->Query($query)) {
                    $this->Position = $newPosition;
                    return TRUE;
                } else {
                    // Update current position failed, revert the previous statement
                    $query = sprintf("UPDATE %s SET Position = Position - 1 WHERE Position <= %d",
                            self::TABLE_NAME, $newPosition);
                    $Database->Query($query);
                }
            }
        }
        return FALSE;
    }
    
    public function MoveDown() {
        global $Database;
        if ($this->Id > 0) {
            $maxPosition = self::GetNextPosition() - 1;
            if ($maxPosition > 0 && $this->Position < $maxPosition) {
                // Calculate the desired position
                $newPosition = $this->Position + 1;
                // Try to update the early positions
                $query = sprintf("UPDATE %s SET Position = Position - 1 WHERE Position = %d",
                        self::TABLE_NAME, $newPosition);
                if ($Database->Query($query)) {
                    // Try to update the current position
                    $query = sprintf("UPDATE %s SET Position = %d WHERE Id = %d",
                            self::TABLE_NAME, $newPosition, $this->Id);
                    if ($Database->Query($query)) {
                        $this->Position = $newPosition;
                        return TRUE;
                    } else {
                        // Update current position failed, revert the previous statement
                        $query = sprintf("UPDATE %s SET Position = Position + 1 WHERE Position <= %d",
                                self::TABLE_NAME, $newPosition);
                        $Database->Query($query);
                    }
                }
            }
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        global $Database;
        if ($this->Id < 1)
            return FALSE;
        if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
            // Reorder the next positions
            $query = sprintf("UPDATE %s SET Position = Position - 1 WHERE Position > %d",
                        self::TABLE_NAME, $this->Position);
            $Database->Query($query);
            // Delete all the associated resources
            $this->_Delete(CB_Achievement_User::TABLE_NAME, "IdAchievement = " . $this->Id);
            return TRUE;
        }
        return FALSE;
    }
    
    /**
     * Load high scores list with rank, value and user data
     * 
     * @param int $timeInterval Specify the interval type, can be: CB_LEADERBOARD_HIGHSCORE_TOTAL, CB_LEADERBOARD_HIGHSCORE_WEEK, CB_LEADERBOARD_HIGHSCORE_TODAY
     * @param int $limit Number of records to fetch
     * @param int $offset Offset limit to fetch
     * @param int $count It will contain the total number of records, counted without LIMIT clause
     * @return array Highscore records list
     */
    public static function LoadUserAchievements ($idAccount) {
        $result = array();
        $achievements = self::_load(self::TABLE_NAME, "CB_Achievement", null, "Position");
        foreach ($achievements as $achievement) {
            $records = CB_Achievement_User::LoadAccount($idAccount, $achievement->Id);
            if (count($records) == 0 && $idAccount > 0) {
                $newAchievement = new CB_Achievement_User();
                $newAchievement->IdAchievement = $achievement->Id;
                $newAchievement->IdAccount = $idAccount;
                $newAchievement->Progress = 0;
                $records[] = $newAchievement;
            }
            $finished = 0;
            foreach ($records as $progress1) {
                if ($progress1->Progress >= 100)
                    ++$finished;
            }
            foreach ($records as $progress) {
                $result[] = array(
                    "Id" => $achievement->Id,
                    "Title" => $achievement->Title,
                    "Description" => $achievement->Description,
                    "Progress" => $progress->Progress,
                    "Finished" => $finished
                );
            }
        }
        return $result;
    }
    
    /**
     * Post a progress in the achieveement from a user
     * 
     * @param CB_Account $account CB_Account who scored
     * @param mixed $progressValue Progress value to save (0-100)
     * @return boolean Returns TRUE on success, otherwise FALSE
     */
    public function PostProgress ($account, $progressValue, &$newProgress = 0, &$cannotRepeat = NULL) {
        $newProgress = $progressValue;
        $cannotRepeat = FALSE;
        // Load the current saved records for this user
        $records = CB_Achievement_User::LoadAccount($account->Id, $this->Id);
        if (count($records) == 0) {
            // We still haven't records, create new one
            $newRecord = new CB_Achievement_User();
            $newRecord->IdAchievement = $this->Id;
            $newRecord->IdAccount = $account->Id;
            $newRecord->Progress = $progressValue;
            return $newRecord->Save();
        }
        // Ok! So we have at least one record for this user in the achievement...
        // Check to see if the achievement requires unique records per user
        if ($this->UniqueRecords == 1) {
            // Achievement has already been completed, return TRUE
            if ($records[0]->Progress >= 100)
                return TRUE;
            // It requires unique records, so update the current saved
            $records[0]->Progress += $progressValue;
            if ($records[0]->Progress > 100)
                $records[0]->Progress = 100;
            $newProgress = $records[0]->Progress;
            return $records[0]->Save();
        }
        // It doesn't require unique records, so create new one if needed
        if ($records[count($records) - 1]->Progress < 100)
            $newRecord = $records[count($records) - 1];
        else {
            $newRecord = new CB_Achievement_User();
            $newRecord->IdAchievement = $this->Id;
            $newRecord->IdAccount = $account->Id;
        }
        $newRecord->Progress += $progressValue;
        if ($newRecord->Progress > 100)
            $newRecord->Progress = 100;
        $newProgress = $newRecord->Progress;
        return $newRecord->Save();
    }
}
