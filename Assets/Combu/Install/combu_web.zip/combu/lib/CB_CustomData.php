<?php

include_once "Database.php";
include_once "IDataClass.php";

/**
 * Class to handle User Custom Data
 *
 * @author Skared Creations
 */
class CB_CustomData extends DataClass {

    const TABLE_NAME = "CB_CustomData";

    public $IdAccount = 0;
    public $DataKey = "";
    public $DataValue = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }

    /**
     * Get the registered custom data
     *
     * @param string $idAccount Filter IdAccount
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_CustomData[] Returns the array of records
     */
    public static function Load ($idAccount, $returnArray = false) {
        $where = sprintf("IdAccount = %d", $idAccount);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_CustomData"), $where);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $query = sprintf("REPLACE INTO %s (IdAccount, DataKey, DataValue) VALUES (%d, '%s', '%s')",
                self::TABLE_NAME,
                $this->IdAccount,
                $Database->Escape($this->DataKey),
                $Database->Escape($this->DataValue));
        return $Database->Query($query);
    }
    
    /**
     * Delete the record from the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        global $Database;
        if ($this->IdAccount > 0 && $this->DataKey) {
            return $this->_Delete(self::TABLE_NAME, sprintf("IdAccount = %d AND DataKey = '%s'", $this->IdAccount, $Database->Escape($this->DataKey)));
        }
        return FALSE;
    }
    
    /**
     * A shortcut to quickly update custom data for an account and returns if it was successful
     * @param int $idAccount
     * @param string $key
     * @param string $value
     * @return boolean
     */
    public static function SetCustomData($idAccount, $key, $value) {
        $data = new self();
        $data->IdAccount = $idAccount;
        $data->DataKey = $key;
        $data->DataValue = $value;
        return $data->Save();
    }
}
