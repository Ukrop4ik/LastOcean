<?php

/**
 * Class to handle membership of Accounts in in-game Mail Groups
 *
 * @author Skared Creations
 */
class CB_UserGroupAccount extends DataClass {

    const TABLE_NAME = "CB_UserGroupAccount";

    public $IdGroup = 0;
    public $IdAccount = 0;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }
    
    /**
     * Check if an account is already member of a group
     * @param int $idGroup Id of the group
     * @param int $idAccount Id of the account
     * @return boolean Membership exists
     */
    public static function Exists($idGroup, $idAccount) {
        global $Database;
        $where = sprintf("IdGroup = %d AND IdAccount = %d", $idGroup, $idAccount);
        $recs = self::_load(self::TABLE_NAME, "", $where);
        return (count($recs) > 0);
    }

    /**
     * Get the registered memberships
     *
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($idGroup = 0, $idAccount = 0, $returnArray = false) {
        $where = NULL;
        if ($idGroup > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdGroup = %d)", $idGroup);
        if ($idAccount > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdAccount = %d)", $idAccount);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_UserGroupAccount"), $where);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->IdGroup <= 0 || $this->IdAccount <= 0)
            return FALSE;
        $query = sprintf("REPLACE INTO %s (IdGroup, IdAccount) VALUES (%d, %d)",
                self::TABLE_NAME,
                $this->IdGroup,
                $this->IdAccount);
        return $Database->Query($query);
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->IdGroup > 0 && $this->IdAccount > 0) {
            return $this->_Delete(self::TABLE_NAME, sprintf("IdGroup = %d AND IdAccount = %d", $this->IdGroup, $this->IdAccount));
        }
        return FALSE;
    }
}
