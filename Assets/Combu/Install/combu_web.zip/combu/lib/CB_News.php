<?php

/**
 * Class to handle News
 *
 * @author Skared Creations
 */
class CB_News extends DataClass {

    const TABLE_NAME = "CB_News";

    public $Id = 0;
    public $IdAdminAccount = 0;
    public $PublishDate = "";
    public $Subject = "";
    public $Message = "";
    public $Url = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered news
     *
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($limit = null, $offset = null, &$count = null, $returnArray = false) {
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_News"), NULL, "PublishDate DESC", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Subject = '%s', Message = '%s', Url = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Message),
                    $Database->Escape($this->Url),
                    $this->Id);
        } else {
            $this->PublishDate = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (PublishDate, IdAdminAccount, Subject, Message, Url) VALUES (%s, %d, '%s', '%s', '%s')",
                    self::TABLE_NAME,
                    $Database->EscapeDate($this->PublishDate),
                    $this->IdAdminAccount,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Message),
                    $Database->Escape($this->Url));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
