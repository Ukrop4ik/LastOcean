<?

include_once dirname(__FILE__) . "/config.php";

/**
 * Management class for file uploads handle
 */
class FileUpload {

    private $inputName = "";
    private $createTempStruct = true;
    private $rootPath = "";
    private $destRootPath = "";
    private $destFilePath = "";
    private $allowedExtensions = array();

    /**
     * Constructor
     *
     * @param string $inputName Name of the INPUT form field
     * @param string $rootPath Path of the upload root folder
     * @param string $createTempStruct If TRUE then create a directory tree in the upload root (year-month-day)
     */
    public function __construct($inputName, $rootPath = null, $createTempStruct = true) {
        $this->inputName = $inputName;
        $this->createTempStruct = $createTempStruct;
        if ($rootPath) {
            $this->rootPath = $rootPath;
            if (substr($this->rootPath, -1) != "/")
                $this->rootPath .= "/";
        } else {
            $this->rootPath = (defined("UPLOAD") ? UPLOAD : "./");
        }
    }

    /**
     * Set the allowed file extensions to upload
     *
     * @param string $allowedExtensions Array of allowed extensions (each extension should include prefix '.')
     */
    public function SetAllowedExtensions($allowedExtensions) {
        if (!is_array($allowedExtensions))
            $allowedExtensions = array($allowedExtensions);
        $this->allowedExtensions = array();
        foreach ($allowedExtensions as $ext) {
            if (substr($ext, 0, 1) != ".")
                $ext = '.' . $ext;
            $this->allowedExtensions[] = $ext;
        }
    }

    /**
     * Check if a file has been uploaded
     *
     * @return boolean Return TRUE if a file has been uploaded
     */
    public function IsUploaded() {
        if (!isset($_FILES[$this->inputName]))
            return false;
        $file = $_FILES[$this->inputName];
        // Is it uploaded?
        if (is_uploaded_file($file['tmp_name']) && $file['size'] > 0)
            return true;
        return false;
    }

    function GetTempname($fileExt = ".tmp") {
        $tmp_name = md5(microtime()) . $fileExt;
        return $tmp_name;
    }

    function GetFilenameExtension($filename) {
        $i = strrpos($filename, ".");
        if ($i === false)
            return "";
        return substr($filename, $i);
    }

    /**
     * Do an upload action
     *
     * @return boolean Return TRUE on successful upload
     */
    public function Upload() {
        $success = false;
        $this->destFilePath = null;
        $this->destRootPath = "";
        $file = $_FILES[$this->inputName];
        // Is it uploaded?
        if ($this->IsUploaded()) {
            // Get the base file name
            $basename = basename($file['name']);
            // Make sure we have a file name
            if (!$basename) {
                $basename = basename($file['tmp_name']);
            }
            // Check if the file extension is allowed
            if (!$this->IsAllowedExtension($basename)) {
                return false;
            }
            // Create the destination folder structure
            $path = $this->GetDestinationFolder();
            if (!$path) {
                return false;
            }
            $path = $path . $this->GetTempname($this->GetFilenameExtension($basename));
            // Try to move the uploaded file to the destination folder
            if (move_uploaded_file($file['tmp_name'], $path)) {
                // Extract the destination url
                $this->destRootPath = str_replace('\\', '/', substr($path, strlen($this->rootPath)));
                // Set the destination full path
                $this->destFilePath = $path;
                $success = true;
            }
        }
        return $success;
    }

    /**
     * Check if the uploaded file has an allowed extension
     *
     * @param string $fileName The uploaded file name
     * @return boolean Return TRUE if the file extension is allowed
     */
    private function IsAllowedExtension($fileName) {
        if (count($this->allowedExtensions) == 0)
            return true;
        $fileExt = $this->GetFilenameExtension($fileName);
        foreach ($this->allowedExtensions as $ext) {
            if (strcasecmp($ext, $fileExt) == 0)
                return true;
        }
        return false;
    }

    /**
     * Create the destination folder tree and return its full path
     *
     * @return string The destination folder relative path
     */
    private function GetDestinationFolder() {
        if (!file_exists($this->rootPath))
            return false;
        $folder = $this->rootPath . date("Y");
        if (!file_exists($folder))
            @mkdir($folder);
        $folder .= '/' . date("m");
        if (!file_exists($folder))
            @mkdir($folder);
        $folder .= '/' . date("d");
        if (!file_exists($folder))
            @mkdir($folder);
        if (!file_exists($folder))
            return false;
        return $folder . "/";
    }

    /**
     * Get the destination folder path relative to the root folder
     *
     * @return string The destination folder relative path
     */
    public function GetDestinationPath() {
        return $this->destFilePath;
    }

    /**
     * Get the address URL of the destination folder relative to the root path
     *
     * @return string The destination folder address URL
     */
    public function GetDestinationUrl() {
        return $this->destRootPath;
    }

}
