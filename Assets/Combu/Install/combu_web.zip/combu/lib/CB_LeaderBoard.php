<?php

include_once "Database.php";
include_once "IDataClass.php";
include_once "CB_LeaderBoard_User.php";

define ("CB_LEADERBOARD_VALUE_INT", 0);
define ("CB_LEADERBOARD_VALUE_FLOAT", 1);

define ("CB_LEADERBOARD_ORDER_DESC", 0);
define ("CB_LEADERBOARD_ORDER_ASC", 1);

define ("CB_LEADERBOARD_UNIQUE_NONE", 0);
define ("CB_LEADERBOARD_UNIQUE_INCREASE", 1);
define ("CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER", 2);
define ("CB_LEADERBOARD_UNIQUE_REPLACE_ANY", 3);

$LEADERBOARD_SCORETYPE = array(
    CB_LEADERBOARD_UNIQUE_NONE => "Create new score per match",
    CB_LEADERBOARD_UNIQUE_INCREASE => "Increase the same score per user",
    CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER => "Replace the best score per user",
    CB_LEADERBOARD_UNIQUE_REPLACE_ANY => "Replace the same score per user"
);

define ("CB_LEADERBOARD_HIGHSCORE_TOTAL", 0);
define ("CB_LEADERBOARD_HIGHSCORE_MONTH", 1);
define ("CB_LEADERBOARD_HIGHSCORE_WEEK", 2);
define ("CB_LEADERBOARD_HIGHSCORE_TODAY", 3);

/**
 * Class to handle Leaderboards
 *
 * @author Skared Creations
 */
class CB_LeaderBoard extends DataClass {

    const TABLE_NAME = "CB_LeaderBoard";

    public $Id = 0;
    public $Title = "";
    public $Description = "";
    public $UniqueRecords = CB_LEADERBOARD_UNIQUE_INCREASE;
    public $ValueType = CB_LEADERBOARD_VALUE_INT;
    public $OrderType = CB_LEADERBOARD_ORDER_DESC;
    public $AllowAnonymous = 0;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered leaderboards
     *
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($limit = null, $offset = null, &$count = null, $returnArray = false) {
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_LeaderBoard"), "", "", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (Title, Description, UniqueRecords, ValueType, OrderType, AllowAnonymous) VALUES ('%s', '%s', %d, %d, %d, %d)",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $Database->Escape($this->Description),
                    $this->UniqueRecords,
                    $this->ValueType,
                    $this->OrderType,
                    $this->AllowAnonymous);
        } else {
            $query = sprintf("UPDATE %s SET Title = '%s', Description = '%s', ValueType = %d, OrderType = %d, AllowAnonymous = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $Database->Escape($this->Description),
                    $this->ValueType,
                    $this->OrderType,
                    $this->AllowAnonymous,
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
            // Delete all the associated resources
            $this->_Delete(CB_LeaderBoard_User::TABLE_NAME, "IdLeaderboard = " . $this->Id);
            return TRUE;
        }
        return FALSE;
    }
    
    /**
     * Load high scores list with rank, value and user data
     * 
     * @param int $timeInterval Specify the interval type, can be: CB_LEADERBOARD_HIGHSCORE_TOTAL, CB_LEADERBOARD_HIGHSCORE_WEEK, CB_LEADERBOARD_HIGHSCORE_TODAY
     * @param boolean $groupPlayer Returns only the highest scores per players (only for non UniqueRecords leaderboards)
     * @param boolean $groupPlayer Returns the sum of scores per players (only for non UniqueRecords leaderboards)
     * @param int $limit Number of records to fetch
     * @param int $offset Offset limit to fetch
     * @param int $count It will contain the total number of records, counted without LIMIT clause
     * @return array Highscore records list
     */
    public function LoadHighscore ($timeInterval, $groupPlayer = FALSE, $sumPlayer = FALSE, $limit = NULL, $offset = NULL, &$count = NULL) {
        // Set the first filter on the current leaderboard
        $where = sprintf("(IdLeaderboard = %d)", $this->Id);
        // Filter Last Updated datetime to reflect the time interval desired
        switch ($timeInterval) {
            case CB_LEADERBOARD_HIGHSCORE_TODAY:
                $where .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d"),
                        date("Y-m-d"));
                break;
            case CB_LEADERBOARD_HIGHSCORE_WEEK:
                $where .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") - 7, date("Y"))),
                        date("Y-m-d"));
                break;
            case CB_LEADERBOARD_HIGHSCORE_MONTH:
                $where .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d", mktime(0, 0, 0, date("m"), 1, date("Y"))),
                        date("Y-m-t", mktime(0, 0, 0, date("m"), 1, date("Y"))));
                break;
            case CB_LEADERBOARD_HIGHSCORE_TOTAL:
            default:
                // No filter on date by default and for TOTAL interval
                break;
        }
        // Build ORDER BY statement and get the field to update
        $order = "";
        $field = "";
        $this->GetOrderBy($order, $field);
        // Load the records from users in the leaderboard
        if ($this->UniqueRecords == CB_LEADERBOARD_UNIQUE_NONE && ($groupPlayer || $sumPlayer)) {
            // Leaderboards with multiple scores can be grouped to load only the highest score per player
            $where .= " GROUP BY IdAccount";
            if ($sumPlayer) {
                $select = "*, SUM(ValueInt) AS ValueInt, SUM(ValueFloat) AS ValueFloat";
            } else {
                $select = "*, MAX(ValueInt) AS ValueInt, MAX(ValueFloat) AS ValueFloat";
            }
            $records = self::_loadEx($select, CB_LeaderBoard_User::TABLE_NAME, "CB_LeaderBoard_User", $where, $order, $limit, $offset);
            $recordCount = self::_loadQuery("SELECT COUNT(Id) AS CountScores FROM (SELECT Id FROM " . CB_LeaderBoard_User::TABLE_NAME . " WHERE " . $where . ") T");
            if (count($recordCount) > 0)
                $count = $recordCount[0]["CountScores"];
        } else {
            // Load all the records filtered in the time interval
            $records = self::_load(CB_LeaderBoard_User::TABLE_NAME, "CB_LeaderBoard_User", $where, $order, $limit, $offset, $count);
        }
        // Finally build the highscore custom list!
        $highscore = array();
        $rank = $offset + 1;
        foreach ($records as $record) {
            if ($record->IdAccount > 0) {
                $user = new CB_Account($record->IdAccount);
            } else {
                $user = new CB_Account();
                $user->Username = $record->Username;
            }
            $highscore[] = array(
                "Id" => $record->Id,
                "IdLeaderboard" => $this->Id,
                "Rank" => $rank++,
                "User" => $user->ToJson(),
                "Score" => $record->$field
            );
        }
        return $highscore;
    }
    
    public function GetOrderBy (&$order, &$field) {
        // Build ORDER BY statement and get the field to update
        switch ($this->ValueType) {
            case CB_LEADERBOARD_VALUE_FLOAT:
                $order = $field = "ValueFloat";
                break;
            case CB_LEADERBOARD_VALUE_INT:
            default:
                $order = $field = "ValueInt";
                break;
        }
        // Apply Descending or Ascending to ORDER BY
        if ($this->OrderType == CB_LEADERBOARD_ORDER_ASC)
            $order .= " ASC, IdAccount ASC";
        else
            $order .= " DESC, IdAccount ASC";
    }
    
    public function LoadHighscoreForAccount ($timeInterval, $groupPlayer, $sumPlayer, $idAccount) {
        // Set the time interval statement
        $where_time = "";
        switch ($timeInterval) {
            case CB_LEADERBOARD_HIGHSCORE_TODAY:
                $where_time .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d"),
                        date("Y-m-d"));
                break;
            case CB_LEADERBOARD_HIGHSCORE_WEEK:
                $where_time .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d", mktime(0, 0, 0, date("m"), date("d") - 7, date("Y"))),
                        date("Y-m-d"));
                break;
            case CB_LEADERBOARD_HIGHSCORE_MONTH:
                $where_time .= sprintf(" AND (LastUpdated BETWEEN '%s 00:00:00' AND '%s 23:59:59')",
                        date("Y-m-d", mktime(0, 0, 0, date("m"), 1, date("Y"))),
                        date("Y-m-t", mktime(0, 0, 0, date("m"), 1, date("Y"))));
                break;
            case CB_LEADERBOARD_HIGHSCORE_TOTAL:
            default:
                // No filter on date by default and for TOTAL interval
                break;
        }
        // Get the current score for this user
        $where = sprintf("(IdLeaderboard = %d AND IdAccount = %d)", $this->Id, $idAccount) . $where_time;
        $order = "";
        $field = "";
        $this->GetOrderBy($order, $field);
        $records = self::_load(CB_LeaderBoard_User::TABLE_NAME, "CB_LeaderBoard_User", $where);
        $userScore = 0;
        if (count($records) > 0) {
            if ($this->UniqueRecords == CB_LEADERBOARD_UNIQUE_NONE && ($groupPlayer || $sumPlayer)) {
                foreach ($records as $record) {
                    if ($sumPlayer)
                        $userScore += $record->$field;
                    else if ($record->$field > $userScore)
                        $userScore = $record->$field;
                }
            } else {
                $userScore = $records[0]->$field;
            }
        }
        // Now count how many players with higher score
        $where = sprintf("(IdLeaderboard = %d AND $field " . ($this->OrderType == CB_LEADERBOARD_ORDER_ASC ? "<" : ">") . " %f)", $this->Id, $userScore) . $where_time;
        if ($this->UniqueRecords == CB_LEADERBOARD_UNIQUE_NONE && ($groupPlayer || $sumPlayer)) {
            $where .= " GROUP BY IdAccount";
            if ($sumPlayer) {
                $select = "*, SUM(ValueInt) AS ValueInt, SUM(ValueFloat) AS ValueFloat";
            } else {
                $select = "*, MAX(ValueInt) AS ValueInt, MAX(ValueFloat) AS ValueFloat";
            }
            $recordCount = self::_loadQuery("SELECT COUNT(Id) AS CountScores FROM (SELECT Id FROM " . CB_LeaderBoard_User::TABLE_NAME . " WHERE " . $where . ") T");
            if (count($recordCount) > 0)
                $rank = $recordCount[0]["CountScores"];
        } else {
            $rank = self::_count(CB_LeaderBoard_User::TABLE_NAME, $where);
        }
        $rank++; // Add "1" to the count, because the first rank is "1" and not "0"
        // Finally count how many players have equal score
        $where = sprintf("(IdLeaderboard = %d AND $field = %f AND IdAccount < %d)", $this->Id, $userScore, $idAccount);
        $rank += count(self::_load(CB_LeaderBoard_User::TABLE_NAME, "CB_LeaderBoard_User", $where));
        return array( "IdLeaderboard" => $this->Id, "Score" => $userScore, "Rank" => $rank );
    }
    
    /**
     * Post a score in the leaderboard from a user
     * 
     * @param CB_Account $account CB_Account who scored
     * @param mixed $scoreValue Value to save (can actually be int or float)
     * @return boolean Returns TRUE on success, otherwise FALSE
     */
    public function PostScore ($account, $scoreValue) {
        // Check the value type of the leaderboard
        // to get the field name to update and adjust score value
        switch ($this->ValueType) {
            case CB_LEADERBOARD_VALUE_FLOAT:
                $field = "ValueFloat";
                $scoreValue = floatval($scoreValue);
                break;
            case CB_LEADERBOARD_VALUE_INT:
            default:
                $field = "ValueInt";
                $scoreValue = intval($scoreValue);
                break;
        }
        // Load the current saved records for this user
        $records = array();
        if ($account->Id > 0)
            $records = CB_LeaderBoard_User::LoadAccount($account->Id, $this->Id);
        if (count($records) == 0) {
            // We still haven't records, create new one
            $newRecord = new CB_LeaderBoard_User();
            $newRecord->IdLeaderboard = $this->Id;
            $newRecord->IdAccount = $account->Id;
            $newRecord->Username = $account->Username;
            $newRecord->$field = $scoreValue;
            return $newRecord->Save();
        }
        // Ok! So we have at least one record for this user in the leaderboard...
        // Check to see if the leaderboard requires unique records per user
        if ($this->UniqueRecords != CB_LEADERBOARD_UNIQUE_NONE) {
            // It requires unique records, so update the current saved
            $records[0]->Username = $account->Username;
            switch ($this->UniqueRecords) {
                case CB_LEADERBOARD_UNIQUE_INCREASE:
                    // Increase score
                    $records[0]->$field += $scoreValue;
                    break;
                case CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER:
                    // Replace score if it is highest
                    if (($this->OrderType == CB_LEADERBOARD_ORDER_DESC && $records[0]->$field >= $scoreValue) || ($this->OrderType == CB_LEADERBOARD_ORDER_ASC && $records[0]->$field <= $scoreValue))
                        return TRUE;
                    $records[0]->$field = $scoreValue;
                    break;
                case CB_LEADERBOARD_UNIQUE_REPLACE_ANY:
                    $records[0]->$field = $scoreValue;
                    break;
            }
            return $records[0]->Save();
        }
        // It doesn't require unique records, so create new one
        $newRecord = new CB_LeaderBoard_User();
        $newRecord->IdLeaderboard = $this->Id;
        $newRecord->IdAccount = $account->Id;
        $newRecord->Username = $account->Username;
        $newRecord->$field = $scoreValue;
        return $newRecord->Save();
    }
}
