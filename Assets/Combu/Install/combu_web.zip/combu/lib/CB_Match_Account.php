<?php

/**
 * This class handles the association of Matches to Accounts
 *
 * @author Skared Creations
 */
class CB_Match_Account extends DataClass {
    
    const TABLE_NAME = "CB_Match_Account";
    
    public $Id = 0;
    public $IdMatch = 0;
    public $IdAccount = 0;
    public $CustomData = "";
    
    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }
    
    /**
     * Load the accounts of a match
     * @param int $idMatch Filter Match ID
     * @param int $idAccount Filter Account ID
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Match_Account[]
     */
    public static function Load($idMatch = 0, $idAccount = 0, $returnArray = FALSE) {
        $where = "";
        if ($idMatch > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdMatch = %d)", $idMatch);
        if ($idAccount > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdAccount = %d)", $idAccount);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Match_Account"), $where, "Id");
    }
    
     /**
     * Save the record in the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
   public function Save() {
        global $Database;
        if ($this->IdMatch < 1 || $this->IdAccount < 1) {
            return FALSE;
        }
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET CustomData = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->CustomData),
                    $this->Id);
        } else {
            $this->DateCreation = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (IdMatch, IdAccount, CustomData) VALUES (%d, %d, '%s')",
                    self::TABLE_NAME,
                    $this->IdMatch,
                    $this->IdAccount,
                    $Database->Escape($this->CustomData));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1) {
                $this->Id = $Database->InsertedId();
            }
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id > 0) {
            if ($this->_Delete(self::TABLE_NAME, sprintf("Id = %d", $this->Id))) {
                $this->_Delete(CB_Match_Round::TABLE_NAME, sprintf("IdMatchAccount = %d", $this->Id));
                return TRUE;
            }
        }
        return FALSE;
    }
    
    public function ToArray() {
        $user = new CB_Account($this->IdAccount);
        $array = Utils::ObjectToArray($this);
        $array["User"] = $user->ToArray();
        $array["Rounds"] = array();
        $rounds = CB_Match_Round::Load($this->Id);
        foreach ($rounds as $r) {
            $array["Rounds"][] = $r->ToArray();
        }
        return $array;
    }
    
    public function ToJson() {
        $array = $this->ToArray();
        return json_encode($array);
    }
}