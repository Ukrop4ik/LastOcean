<?php

include_once 'CB_Match_CustomData.php';
include_once 'CB_Match_Round.php';
include_once 'CB_Match_Account.php';

/**
 * Class to handle Matches
 *
 * @author Skared Creations
 */
class CB_Match extends DataClass {
    
    const TABLE_NAME = "CB_Match";

    public $Id = 0;
    public $IdTournament = 0;
    public $Title = "";
    public $DateCreation = NULL;
    public $DateExpire = NULL;
    public $Rounds = 0;
    public $Finished = 0;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }
    
    /**
     * Load matches corresponding to the filters
     * @global Database $Database
     * @param int $idTournament Filter IdTournament
     * @param boolean $activeOnly Load only in progress matches, not expired
     * @param string $title Filter Title as REGEXP
     * @param array $customData Filter CustomData (must be an array of associative arrays: [{"key1":"value"},{"key2":"value"}])
     * @param string $order
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param bool $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Match[]
     */
    public static function Load($idTournament = 0, $idUser = 0, $activeOnly = FALSE, $title = "", $customData = array(), $order = NULL, $limit = NULL, $offset = NULL, $count = NULL, $returnArray = FALSE) {
        global $Database;
        $where = "";
        if ($idTournament > 0) {
            $where .= ($where == "" ? "" : " AND ") . sprintf("(IdTournament = %d)", $idTournament);
        } else if ($idTournament == -1) {
            $where .= ($where == "" ? "" : " AND ") . "(IdTournament = 0)";
        }
        if ($idUser > 0) {
            if ($activeOnly) {
                $where .= ($where == "" ? "" : " AND ") . "(DateExpire IS NULL OR DateExpire < CURRENT_DATE())" .
                    sprintf(" AND (Finished = 0 AND Id IN (SELECT IdMatch FROM %s WHERE IdAccount = %d))", CB_Match_Account::TABLE_NAME, $idUser);
            } else {
                $where .= ($where == "" ? "" : " AND ") . sprintf("(Finished = 1 AND Id IN (SELECT IdMatch FROM %s WHERE IdAccount = %d))", CB_Match_Account::TABLE_NAME, $idUser);
            }
        }
        if ($title) {
            $where .= sprintf("(Title REGEXP '%s')", $Database->Escape($title));
        }
        if ($customData && is_array($customData)) {
            $whereCustom = "";
            foreach ($customData as $search_row) {
                if (!is_array($search_row)) {
                    continue;
                }
                $key = $search_row["key"];
                $op = $search_row["op"];
                $value = $search_row["value"];
                $whereCustom .= ($whereCustom == "" ? "" : " AND ") . sprintf("(DataKey = '%s' AND DataValue %s '%s')", $Database->Escape($key), $op, $Database->Escape($value));
            }
            if ($whereCustom) {
                $where .= ($where == "" ? "" : " AND ") . sprintf("(Id IN (SELECT IdMatch FROM %s WHERE %s))", CB_Match_CustomData::TABLE_NAME, $whereCustom);
            }
        }
        if (!$order) {
            $order = "Id";
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Match"), $where, $order, $limit, $offset, $count);
    }
    
    /**
     * Save the record in the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Title = '%s', Rounds = %d, DateExpire = %s, Finished = %d WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Title),
                    $this->Rounds,
                    $Database->EscapeDate($this->DateExpire),
                    $this->Finished,
                    $this->Id);
        } else {
            $this->DateCreation = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (IdTournament, Title, Rounds, DateCreation, DateExpire, Finished) VALUES (%d, '%s', %d, %s, %s, 0)",
                    self::TABLE_NAME,
                    $this->IdTournament,
                    $Database->Escape($this->Title),
                    $this->Rounds,
                    $Database->EscapeDate($this->DateCreation),
                    $Database->EscapeDate($this->DateExpire));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1) {
                $this->Id = $Database->InsertedId();
            }
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id > 0) {
            if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
                $this->_Delete(CB_Match_CustomData::TABLE_NAME, "IdMatch = " . $this->Id);
                // Delete all match accounts and rounds
                $accounts = CB_Match_Account::Load($this->Id);
                foreach ($accounts as $account) {
                    $account->Delete();
                }
                return TRUE;
            }
        }
        return FALSE;
    }
    
    /**
     * Check if all the scores have been sent
     */
    public function CheckFinished() {
        $allScores = TRUE;
        $accounts = CB_Match_Account::Load($this->Id);
        foreach ($accounts as $a) {
            $rounds = CB_Match_Round::Load($a->Id);
            foreach ($rounds as $r) {
                if (!$r->DateScore) {
                    $allScores = FALSE;
                    break;
                }
            }
        }
        if ($allScores) {
            $this->Finished = 1;
            if ($this->Save()) {
                // Check if the tournament has finished
                $tournament = new CB_Tournament($this->IdTournament);
                if ($tournament->Id > 0)
                    $tournament->CheckFinished();
            }
        }
    }
    
    public function ToArray() {
        $array = Utils::ObjectToArray($this);
        // Add the Match Custom Data
        $array["CustomData"] = array();
        $customData = CB_Match_CustomData::Load($this->Id);
        foreach ($customData as $data) {
            $array["CustomData"][$data->DataKey] = $data->DataValue;
        }
        // Add the Accounts
        $array["Users"] = array();
        $accounts = CB_Match_Account::Load($this->Id);
        foreach ($accounts as $i) {
            $array["Users"][] = $i->ToArray();
        }
        // Return the full array
        return $array;
    }
    
    public function ToJson() {
        $array = $this->ToArray();
        return json_encode($array);
    }
}
