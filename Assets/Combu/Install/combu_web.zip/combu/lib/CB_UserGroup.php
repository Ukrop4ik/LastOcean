<?php

include_once 'CB_UserGroupAccount.php';

/**
 * Class to handle User Groups
 *
 * @author Skared Creations
 */
class CB_UserGroup extends DataClass {

    const TABLE_NAME = "CB_UserGroup";

    public $Id = 0;
    public $Name = "";
    public $IdOwner = 0;
    public $Public = 0;
    public $CustomData = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Check if the current Name already exists
     *
     * @return boolean Returns TRUE if exists
     */
    public function Exists() {
        global $Database;
        $sql = "IdOwner = " . $this->IdOwner . " AND Name = '" . $Database->Escape($this->Name) . "'";
        if ($this->Id > 0)
            $sql .= " AND Id <> " . $this->Id;
        $recs = self::_load(self::TABLE_NAME, "", $sql);
        if (count($recs) > 0)
            return TRUE;
        return FALSE;
    }

    /**
     * Get the registered groups
     *
     * @param int $idAccount Filter membership of an account
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @global Database $Database
     * @return CB_UserGroup[] Returns the array of records
     */
    public static function Load ($name = NULL, $idOwner = 0, $idAccount = 0, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        global $Database;
        $where = "(Public = 1)";
        if ($name)
            $where .= ($where ? " AND " : "") . sprintf("(Name REGEXP '%s')", $Database->Escape($name));
        if ($idOwner > 0 && $idOwner == $idAccount) {
            $where .= ($where ? " AND " : "") . "(" .
                    sprintf("(IdOwner = %d)", $idOwner) .
                    " OR " . sprintf("(Id IN (SELECT IdGroup FROM %s WHERE IdAccount = %d))", CB_UserGroupAccount::TABLE_NAME, $idAccount) .
                    ")";
        } else {
            if ($idOwner > 0)
                $where .= ($where ? " AND " : "") . sprintf("(IdOwner = %d)", $idOwner);
            if ($idAccount > 0)
                $where .= ($where ? " AND " : "") . sprintf("(Id IN (SELECT IdGroup FROM %s WHERE IdAccount = %d))", CB_UserGroupAccount::TABLE_NAME, $idAccount);
        }
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_UserGroup"), $where, "Name", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Name = '%s', IdOwner = %d, CustomData = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Name),
                    $this->IdOwner,
                    $Database->Escape($this->CustomData),
                    $this->Id);
        } else {
            $query = sprintf("INSERT INTO %s (Name, IdOwner, Public, CustomData) VALUES ('%s', %d, %d, '%s')",
                    self::TABLE_NAME,
                    $Database->Escape($this->Name),
                    $this->IdOwner,
                    $this->Public,
                    $Database->Escape($this->CustomData));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        if ($this->_Delete(self::TABLE_NAME, "Id = " . $this->Id)) {
            // Delete all memberships
            $this->_Delete(CB_UserGroupAccount::TABLE_NAME, "IdGroup = " . $this->Id);
            // Delete all messages
            $this->_Delete(CB_Mail::TABLE_NAME, "IdGroup = " . $this->Id);
            return TRUE;
        }
        return FALSE;
    }
    
    /**
     * Get the members of this group
     * @return CB_UserGroupAccount[] List of CB_UserGroupAccount
     */
    public function GetMembers() {
        $members = array();
        if ($this->Id > 0) {
            $members = CB_UserGroupAccount::Load($this->Id);
        }
        return $members;
    }
    
    /**
     * Get the members account of this group
     * @return CB_Account[] List of CB_Account
     */
    public function GetMembersAccount() {
        $members = array();
        $recs = $this->GetMembers();
        foreach ($recs as $member) {
            $user = new CB_Account($member->IdAccount);
            if ($user->Id > 0)
                $members[] = $user;
        }
        return $members;
    }
    
    /**
     * Get the array representation of this object
     * @return array
     */
    public function ToArray() {
        $array = Utils::ObjectToArray($this);
        $array["Owner"] = new CB_Account($this->IdOwner);
        $array["Owner"] = $array["Owner"]->ToJson();
        $array["Users"] = array();
        $members = $this->GetMembersAccount();
        foreach ($members as $user) {
            $array["Users"][] = $user->ToArray();
        }
        return $array;
    }
}
