<?php

/**
 * Description of AdminModule
 *
 * @author Skared Creations
 */
class AddonModule
{
    public $Name = "";
    public $OnUserCreate = NULL;
    public $OnUserUpdate = NULL;
    public $OnUserDelete = NULL;
    public $OnUserCustomDataOutput = NULL;
    public $OnUserLogout = NULL;

    private $Folder = "";
    private $Properties = array();
    private $AdminMenu = array();
    private $BlockedUpdateUserCustomData = array();

    public function __construct($folder) {
        $this->Folder = $folder;
        if (substr($this->Folder, -1) != "/")
            $this->Folder .= "/";
    }

    /**
     * Load the admin modules installed
     * @return AddonModule[]
     */
    public static function LoadAddons() {
        $addons = array();
        $handle = NULL;
        if (file_exists(ADDONS_FOLDER))
            $handle = opendir(ADDONS_FOLDER);
        if ($handle) {
            while (false !== ($entry = readdir($handle))) {
                // Skip files
                if (!is_dir(ADDONS_FOLDER . "/" . $entry))
                    continue;
                // Skip back/current directories
                if ($entry == "." || $entry == "..")
                    continue;
                // Try to load the add-on in this directory
                $addon = self::LoadAddon(ADDONS_FOLDER . "/" . $entry);
                if ($addon)
                    $addons[] = $addon;
            }
        }
        return $addons;
    }
    
    /**
     * Try to load the add-on in the folder
     * @param string $folder
     * @return boolean
     */
    private static function LoadAddon($folder) {
        // Is there a loader file in this folder?
        $addon_file = $folder . "/addon.php";
        $disabled_file = $folder . "/.disabled";
        if (file_exists($addon_file) && !file_exists($disabled_file)) {
            try {
                // Create a new AddonModule for this entry
                $addon = new self($folder);
                // Run the add-on loader
                include_once $addon_file;
                return $addon;
            } catch (Exception $ex) {
                // Loading this add-on failed, log the exception
                AppLog::Error("Error trying to load add-on " . $entry . ": " . $ex->getMessage());
            }
        }
        return NULL;
    }
    
    /**
     * Get the installed addon if exists
     * @global self[] $Addons
     * @param string $addonName
     * @return self
     */
    public static function GetAddon($addonName) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->Name == $addonName)
                return $addon;
        }
        return NULL;
    }
    
    /**
     * Get the folder of this Addon
     * @return string
     */
    public function GetFolder() {
        return $this->Folder;
    }
    
    /**
     * Get the path to a file in the folder of this Addon
     * @param string $fileRelativePath
     * @return string
     */
    public function GetFile($fileRelativePath) {
        if (substr($fileRelativePath, 0, 1) == "/")
            $fileRelativePath = substr($fileRelativePath, 1);
        return $this->Folder . $fileRelativePath;
    }
    
    /**
     * Get the link to the specified menu for the admin console
     * @param int $menu
     * @return type
     */
    public function GetMenuLink($menu) {
        return URL_ROOT . "admin/addon-load.php?addon=" . urlencode($this->Name) . "&menu=" . $menu;
    }
    
    /**
     * Get all custom properties of this Addon as associative array
     * @return array
     */
    public function GetProperties () {
        return $this->Properties;
    }
    
    /**
     * Get a custom property of this Addon
     * @param type $name
     * @return object
     */
    public function GetProperty($name) {
        if (array_key_exists($name, $this->Properties))
            return $this->Properties[$name];
        return NULL;
    }
    
    /**
     * Set a custom property for this Addon
     * @param string $name
     * @param object $value
     */
    public function SetProperty($name, $value) {
        $this->Properties[$name] = $value;
    }
    
    /**
     * Add a link in the Addon section of the admin console menu
     * @param string $displayText
     * @param string $url
     */
    public function AddAdminMenu($displayText, $url) {
        if ($displayText && $url)
            $this->AdminMenu[] = array( "Display" => $displayText, "Url" => $url );
    }
    
    /**
     * Get the links in the Addon section of the admin console menu
     * @return array
     */
    public function GetAdminMenu() {
        return $this->AdminMenu;
    }
    
    /**
     * Block an account custom data key from being updated by clients
     * @param string $dataKey
     */
    public function BlockUpdateUserCustomData($dataKey) {
        if (!array_key_exists($dataKey, $this->BlockedUpdateUserCustomData))
            $this->BlockedUpdateUserCustomData[] = $dataKey;
    }
    
    /**
     * Check if an account custom data key is blocked by this Addon
     * @global self[] $Addons
     * @param string $dataKey
     * @return boolean
     */
    public static function IsBlockedUpdateUserCustomData($dataKey) {
        global $Addons;
        foreach ($Addons as $addon) {
            if (in_array($dataKey, $addon->BlockedUpdateUserCustomData))
                return TRUE;
        }
        return FALSE;
    }
    
    /**
     * This function is called in CB_Account::ToArrayFiltered to filter the outgoing custom data of an account.
     * Addons can use their own callback to add, remove or edit custom data that will be sent to the clients.
     * @global self[] $Addons
     * @param CB_Account $user
     * @param array $customData
     */
    public static function ProcessOutputUserCustomData($user, &$customData) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->OnUserCustomDataOutput)
                eval ($addon->OnUserCustomDataOutput . "(\$user, \$customData);");
        }
    }
    
    /**
     * This function is called when a new account is created
     * @global self[] $Addons
     * @param CB_Account $user
     */
    public static function NotifyUserCreate($user) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->OnUserCreate)
                eval ($addon->OnUserCreate . "(\$user);");
        }
    }
    
    /**
     * This function is called when an account is updated
     * @global self[] $Addons
     * @param CB_Account $user
     */
    public static function NotifyUserUpdate($user) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->OnUserUpdate)
                eval ($addon->OnUserUpdate . "(\$user);");
        }
    }
    
    /**
     * This function is called when an account is deleted
     * @global self[] $Addons
     * @param CB_Account $user
     */
    public static function NotifyUserDelete($user) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->OnUserDelete)
                eval ($addon->OnUserDelete . "(\$user);");
        }
    }
    
    /**
     * This function is called when an account logged out
     * @global self[] $Addons
     * @param CB_Account $user
     */
    public static function NotifyUserLogout($user) {
        global $Addons;
        foreach ($Addons as $addon) {
            if ($addon->OnUserLogout)
                eval ($addon->OnUserLogout . "(\$user);");
        }
    }
}
