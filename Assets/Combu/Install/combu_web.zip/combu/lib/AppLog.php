<?

/**
 * This class manages the log into a file the info, warnings and errors requested by the application
 */
class AppLog {
   private static $FilePath = null;
   private static $MaxFileSize = 0;
   
   public static function Initialize($filePath = null, $maxFileSize = null) {
      if ($filePath)
         self::$FilePath = $filePath;
      elseif (defined('LOG_FILEPATH'))
         self::$FilePath = LOG_FILEPATH;
      if ($maxFileSize !== null)
         self::$MaxFileSize = $maxFileSize;
      elseif (defined('LOG_MAXFILESIZE'))
         self::$MaxFileSize = LOG_MAXFILESIZE;
   }
   
   private static function WriteToFile($text) {
      if (self::$MaxFileSize > 0) {
         if (@filesize(self::$FilePath) > self::$MaxFileSize) {
            $ext = Utils::GetFilenameExtension(basename(self::$FilePath));
            $suffix = "_" . date("d-m-Y_H-i-s") . $ext;
            $bakFile = substr(self::$FilePath, 0, strlen($ext) - 1) . $suffix;
            @rename(self::$FilePath, $bakFile);
         }
      }
      file_put_contents(self::$FilePath, $text, FILE_APPEND);
   }
   
   private static function SanatizeText($log) {
      $text = $log;
      $text = str_replace("\n", " ", $text);
      $text = str_replace("\r", " ", $text);
      $text = str_replace("  ", " ", $text);
      $text = trim($text);
      return $text;
   }
   
   private static function AppendLog($prefix, $log) {
      $text = date("d/m/Y H:i:s") . " [$prefix] " . self::SanatizeText($log) . "\n";
      self::WriteToFile($text);
   }
   
   public static function Info($log) {
      self::AppendLog("INFO", $log);
   }
   public static function Warning($log) {
      self::AppendLog("WARNING", $log);
   }
   public static function Error($log) {
      self::AppendLog("ERROR", $log);
   }
}
