<?php

/**
 * Class to handle Inventory items
 *
 * @author Skared Creations
 */
class CB_Inventory extends DataClass {

    const TABLE_NAME = "CB_Inventory";

    public $Id = 0;
    public $IdAccount = 0;
    public $Name = "";
    public $Quantity = 0;
    public $CustomData = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        } else {
            // Load by Name
            $this->_loadFilter(self::TABLE_NAME, "Name = '" . $Database->Escape($src) . "' ORDER BY Id");
        }
    }

    /**
     * Get the registered inventory items
     *
     * @param string $idAccount Filter IdAccount
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($idAccount, $returnArray = false) {
        $where = sprintf("IdAccount = %d", $idAccount);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Inventory"), $where);
    }
    
    public static function LoadOrCreate ($idAccount, $itemName, $returnArray = false) {
        global $Database;
        // Load the existing record
        $where = sprintf("IdAccount = %d AND Name = '%s'", $idAccount, $Database->Escape($itemName));
        $recs = self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Inventory"), $where);
        if (count($recs) > 0)
            return $recs[0];
        // If no record was found, then create new instance
        $rec = new self();
        $rec->IdAccount = $idAccount;
        $rec->Name = $itemName;
        return $rec;
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET Quantity = %d, CustomData = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Quantity,
                    $Database->Escape($this->CustomData),
                    $this->Id);
        } else {
            $query = sprintf("INSERT INTO %s (IdAccount, Name, Quantity, CustomData) VALUES (%d, '%s', %d, '%s')",
                    self::TABLE_NAME,
                    $this->IdAccount,
                    $Database->Escape($this->Name),
                    $this->Quantity,
                    $Database->Escape($this->CustomData));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
