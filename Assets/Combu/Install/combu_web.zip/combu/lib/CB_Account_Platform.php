<?php

/**
 * Handle the association of CB_Account with Platforms (GameCenter, GooglePlay, Facebook and everyone else)
 *
 * @author Skared Creations
 */
class CB_Account_Platform extends DataClass {
    
    const TABLE_NAME = "CB_Account_Platform";

    public $IdAccount = 0;
    public $PlatformKey = "";
    public $PlatformId = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if (!$src)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }

    /**
     * Get the registered platform logins
     * @global Database $Database
     * @param int $idAccount Filter IdAccount
     * @return CB_Account_Platform
     */
    public static function Load($idAccount) {
        global $Database;
        $where = sprintf("IdAccount = %d", $idAccount);
        return self::_load(self::TABLE_NAME, "CB_Account_Platform", $where);
    }
    
    /**
     * Load or create an account associated to the platform
     * @param string $platformKey The Platform Key (e.g.: "GameCenter", "GooglePlay", "Facebook", etc.)
     * @param string $platformId The User Id returned by the Platform authentication
     * @param string $customData The JSON string representation of an associative array for custom data
     * @param CB_Account_Platform $accountPlatform It is set with the loaded or created Account-Platform object
     * @global Database $Database
     * @return CB_Account
     */
    public static function LoadAccount ($platformKey, $platformId, &$accountPlatform = NULL, &$justCreated = FALSE) {
        global $Database;
        $account = NULL;
        $accountPlatform = NULL;
        $justCreated = FALSE;
        $query = sprintf("SELECT IdAccount FROM %s WHERE PlatformKey = '%s' AND PlatformId = '%s'",
                self::TABLE_NAME,
                $Database->Escape($platformKey),
                $Database->Escape($platformId));
        $rows = self::LoadRecords($query, "CB_Account_Platform");
        if (count($rows) > 0) {
            $accountPlatform = $rows[0];
            // We have an account
            $account = new CB_Account($accountPlatform->IdAccount);
            if ($account->Id < 1) {
                $account = NULL;
                // Delete this record because the account is invalid
                $accountPlatform->Delete();
                $accountPlatform = NULL;
            }
        } else {
            // Create new account
            $account = new CB_Account();
            $account->Username = $platformKey . "_" . $platformId;
            $account->Enabled = 1;
            if ($account->Save()) {
                $accountPlatform = new CB_Account_Platform();
                $accountPlatform->PlatformKey = $platformKey;
                $accountPlatform->PlatformId = $platformId;
                $accountPlatform->IdAccount = $account->Id;
                if ($accountPlatform->Save()) {
                    $justCreated = TRUE;
                } else {
                    $accountPlatform = NULL;
                    // Delete this record because it didn't save the Account-Platform object
                    $account->Delete();
                    $account = NULL;
                }
            } else {
                $account = NULL;
            }
        }
        return $account;
    }

    /**
     * Save the record in the database
     *
     * @return boolean Returns TRUE on success
     */
    public function Save() {
        global $Database;
        // Data integrity check
        if ($this->IdAccount < 1 || !$this->PlatformKey || !$this->PlatformId)
            return FALSE;
        if ($this->Id > 0) {
            return FALSE;
        } else {
            $query = sprintf("INSERT INTO %s (IdAccount, PlatformKey, PlatformId) VALUES (%d, '%s', '%s')",
                    self::TABLE_NAME,
                    $this->IdAccount,
                    $Database->Escape($this->PlatformKey),
                    $Database->Escape($this->PlatformId));
        }
        return $Database->Query($query);
    }

    /**
     * Delete the record from the database
     *
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
    	global $Database;
        $where = sprintf("IdAccount = %d AND PlatformKey = '%s' AND PlatformId = '%s'",
                $this->IdAccount,
                $Database->Escape($this->PlatformKey),
                $Database->Escape($this->PlatformId));
        return $this->_Delete(self::TABLE_NAME, $where);
    }
}
