<?php

include_once "Database.php";
include_once "IDataClass.php";

/**
 * Class to handle LeaderBoard User Records
 *
 * @author Skared Creations
 */
class CB_LeaderBoard_User extends DataClass {

    const TABLE_NAME = "CB_LeaderBoard_User";

    public $Id = 0;
    public $IdLeaderboard = 0;
    public $IdAccount = 0;
    public $Username = "";
    public $ValueInt = 0;
    public $ValueFloat = 0;
    public $ValueString = "";
    public $LastUpdated = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered scores
     *
     * @param string $idAccount Filter IdAccount
     * @param string $idLeaderboard Filter IdLeaderboard
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function LoadAccount ($idAccount, $idLeaderboard, $returnArray = false) {
        $where = sprintf("IdAccount = %d AND IdLeaderboard = %d", $idAccount, $idLeaderboard);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_LeaderBoard_User"), $where);
    }

    /**
     * Get the registered scores
     *
     * @param string $idLeaderboard Filter IdLeaderboard
     * @param string $order Order statement (without 'ORDER BY')
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($idLeaderboard, $order, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        $where = sprintf("al.IdLeaderboard = %d", $idLeaderboard);
        return self::_loadEx("al.*", self::TABLE_NAME . " al INNER JOIN " . CB_Account::TABLE_NAME . " u ON u.Id = al.IdAccount", ($returnArray ? "" : "CB_LeaderBoard_User"), $where, $order, $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (IdLeaderboard, IdAccount, Username, ValueInt, ValueFloat, LastUpdated) VALUES (%d, %d, '%s', %d, %f, '%s')",
                    self::TABLE_NAME,
                    $this->IdLeaderboard,
                    $this->IdAccount,
                    $Database->Escape($this->Username),
                    $this->ValueInt,
                    $this->ValueFloat,
                    date("Y-m-d H:i:s"));
        } else {
            $query = sprintf("UPDATE %s SET Username = '%s', ValueInt = %d, ValueFloat = %f, LastUpdated = '%s' WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->Username),
                    $this->ValueInt,
                    $this->ValueFloat,
                    date("Y-m-d H:i:s"),
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
