<?

require_once 'PhpMailer/class.phpmailer.php';

class Mail extends PHPMailer {

    public $body;
    
    function __construct() {
        parent::__construct();
        $this->CharSet = 'UTF-8';
    }
    
    private function reset() {
        $this->ClearAddresses();
        $this->ClearAllRecipients();
        $this->ClearAttachments();
        $this->ClearBCCs();
        $this->ClearCCs();
        $this->ClearCustomHeaders();
        $this->ClearReplyTos();
    }
    
    public function prepare($subject, $body, $sTo, $sFrom = "", $sFromName = "") {
        $this->reset();
        if (!$body || !$sTo)
            return false;
        $this->AddAddress($sTo);
        if ($sFrom) {
            /*$this->From = $sFrom;
            if ($sFromName)
                $this->FromName = $sFromName;*/
            $this->SetFrom($sFrom, $sFromName);
        }
        $this->Subject = $subject;
        $this->body = $body;
        $this->AltBody = strip_tags($body);
        return true;
    }
    
    public function replace($search, $replace) {
        $this->Subject = str_replace("[*$search*]", $replace, $this->Subject);
        $this->body = str_replace("[*$search*]", $replace, $this->body);
    }
    
    public function Send() {
        $this->body = stripslashes($this->body);
        $this->MsgHTML($this->body);
        $esito = parent::Send();
        $this->reset();
        return $esito;
    }
}
?>
