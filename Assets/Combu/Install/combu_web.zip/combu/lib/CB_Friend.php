<?php

include_once "Database.php";
include_once "IDataClass.php";

/**
 * Class to handle User Friends
 *
 * @author Skared Creations
 */
class CB_Friend extends DataClass {

    const TABLE_NAME = "CB_Friend";

    public $IdAccount = 0;
    public $IdFriend = 0;
    public $State = FRIEND_STATE_ACCEPTED;

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        }
    }

    /**
     * Get the registered custom data
     *
     * @param string $idAccount Filter IdAccount
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Friend[] Returns the array of records
     */
    public static function Load ($idAccount, $state = NULL, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        $where = sprintf("(IdAccount = %d)", $idAccount);
        if ($state !== NULL)
            $where .= ($where ? "AND " : "") . sprintf("(State = %d)", $state);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Friend"), $where, NULL, $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $query = sprintf("REPLACE INTO %s (IdAccount, IdFriend, State) VALUES (%d, %d, %d)",
                self::TABLE_NAME,
                $this->IdAccount,
                $this->IdFriend,
                $this->State);
        return $Database->Query($query);
    }

    public function Delete() {
        if ($this->IdAccount < 1 || $this->IdFriend < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, sprintf("IdAccount = %d AND IdFriend = %d", $this->IdAccount, $this->IdFriend));
    }
}
