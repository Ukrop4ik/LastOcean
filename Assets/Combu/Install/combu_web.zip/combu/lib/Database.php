<?

class Database {

    /**
     * Instance connection settings
     */
    private $_dbServer;
    private $_dbName;
    private $_dbUser;
    private $_dbPass;

    /**
     * Instance connection resource
     * @var MySQL_Resource 
     */
    private $_connection;

    /**
     * Class constructor
     */
    public function __construct($dbServer, $dbName, $dbUser, $dbPass) {
        $this->_dbServer = $dbServer;
        $this->_dbName = $dbName;
        $this->_dbUser = $dbUser;
        $this->_dbPass = $dbPass;
        $this->_setConnection();
    }

    /**
     * Returns the connection resource
     * @return MySQL_Resource Oggetto connessione
     */
    public function GetConnection() {
        return $this->_connection;
    }

    /**
     * Open the connection to the database
     */
    private function _setConnection() {
        $this->_connection = @mysql_connect($this->_dbServer, $this->_dbUser, $this->_dbPass);
        if ($this->_connection) {
            $this->_selectDatabase();
        } else {
            $this->_connection = false;
        }
    }

    /**
     * Select the database specified for this instance 
     */
    private function _selectDatabase() {
        @mysql_select_db($this->_dbName, $this->_connection);
        //$this->Query("SET NAMES 'UTF8'");
    }

    /**
     * Close the connection to the database 
     */
    public function CloseConnection() {
        if ($this->_connection) {
            @mysql_close($this->_connection);
            $this->_connection = null;
        }
    }

    /**
     * Executes a query on the database
     * @param string $query SQL query string to execute
     * @return MySQL_Result Query result
     */
    public function Query($query) {
        if ($this->_connection) {
            // Make sure we execute the query on the schema specified for the current connection
            $this->_selectDatabase();
            return @mysql_query($query, $this->_connection);
        }
        $this->_setConnection();
        return @mysql_query($query, $this->_connection);
    }

    /**
     * Returns the autoincrement field value of the last INSERT query
     * @return int 
     */
    public function InsertedId() {
        if (!$this->_connection)
            $this->_setConnection();
        $res = $this->Query("SELECT LAST_INSERT_ID()");
        if ($res) {
            $row = $this->Fetch($res, MYSQL_NUM);
            if ($row)
                return $row[0];
        }
        return 0;
    }

    /**
     * Returns the records count affected by last query
     * @return int The affected records count
     */
    public function AffectedRows() {
        return intval(@mysql_affected_rows($this->_connection));
    }

    /**
     * Fetch next record from a resource
     *
     * @param MySQL_Result $result Resource
     * @param mixed $result_type Result type (Default: MYSQL_ASSOC)
     * @return MySQL_Fetch Result from fetch
     *
     */
    public function Fetch($result, $result_type = MYSQL_ASSOC) {
        return @mysql_fetch_array($result, $result_type);
    }

    /**
     * Escape a string to be used in a query
     * @param string $text The string value to escape
     * @return string The escaped string
     */
    public function Escape($text) {
        return @mysql_real_escape_string($text);
    }

    /**
     * Escape a date/datetime to be used in a query
     * @param string $text The date/datetime string value to escape
     * @return string The escaped date string
     */
    public function EscapeDate($text) {
        if (!$text || $text == '')
            return "NULL";
        if (strpos($text, ":") === false)
            return "'" . date("Y-m-d", Utils::GetTimestamp($text)) . "'";
        return "'" . date("Y-m-d H:i:s", Utils::GetTimestamp($text)) . "'";
    }

    /**
     * Check if a record exists from a specified query
     * @param string $sql SELECT query to execute
     * @return boolean Returns TRUE if at least one record exists
     */
    public function RecordExists($sql) {
        if ($sql == "")
            return false;
        $res = $this->Query($sql);
        if ($res) {
            $row = $this->Fetch($res);
            if ($row)
                return true;
        }
        return false;
    }

    /**
     * Starts a transaction
     * @return boolean Returns TRUE if the transaction started successfully
     */
    public function TransactionStart() {
        $res = $this->Query("START TRANSACTION");
        if ($res) {
            return true;
        }
        return false;
    }

    /**
     * Commits a transaction
     * @return boolean Returns TRUE if the transaction was committed successfully
     */
    public function TransactionCommit() {
        $res = $this->Query("COMMIT");
        if ($res) {
            return true;
        }
        return false;
    }

    /**
     * Rollbacks a transaction
     * @return boolean Returns TRUE if the transaction was rolled back successfully
     */
    public function TransactionRollback() {
        $res = $this->Query("ROLLBACK");
        if ($res) {
            return true;
        }
        return false;
    }

    /**
     * Returns the description of the last error occurred
     * @return string The error description
     */
    public function GetError() {
        return @mysql_error($this->_connection);
    }

    /**
     * Returns the code of the last error occurred
     * @return string The error code
     */
    public function GetErrorNo() {
        return @mysql_errno($this->_connection);
    }

}
