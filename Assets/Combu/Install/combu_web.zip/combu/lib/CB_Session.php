<?php

/**
 * Handler for Account Sessions
 *
 * @author Skared Creations
 */
class CB_Session extends DataClass {

    const TABLE_NAME = "CB_Session";

    public $Id = 0;
    public $IdAccount = 0;
    public $GUID = "";
    public $LastActionDate = "";
    public $LastActionIP = "";
    public $SignatureTimestamp = "";
    public $Expire = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered object
     *
     * @param int $idAccount Filter IdAccount
     * @param string $guid Filter GUID
     * @return CB_Session[] Returns the array of records
     */
    public static function Load ($idAccount, $guid = NULL) {
        global $Database;
        $where = "";
        if ($idAccount > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdAccount = %d)", $idAccount);
        if ($guid)
            $where .= ($where ? " AND " : "") . sprintf("(GUID = '%s')", $Database->Escape($guid));
        return self::_load(self::TABLE_NAME, "CB_Session", $where, "LastActionDate DESC", 1);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->IdAccount <= 0 || !$this->GUID)
            return FALSE;
        $this->SetExpireDate();
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (IdAccount, GUID, LastActionDate, LastActionIP, Expire) VALUES (%d, '%s', %s, '%s', %s)",
                    self::TABLE_NAME,
                    $this->IdAccount,
                    $Database->Escape($this->GUID),
                    $Database->EscapeDate($this->LastActionDate),
                    $Database->Escape($this->LastActionIP),
                    $Database->EscapeDate($this->Expire));
        } else {
            $query = sprintf("UPDATE %s SET GUID = '%s', LastActionDate = %s, LastActionIP = '%s', Expire = %s WHERE Id = %d",
                    self::TABLE_NAME,
                    $Database->Escape($this->GUID),
                    $Database->EscapeDate($this->LastActionDate),
                    $Database->Escape($this->LastActionIP),
                    $Database->EscapeDate($this->Expire),
                    $this->Id);
        }
        if ($Database->Query($query)) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     * @global Database $Database
     * @return boolean
     */
    public function Delete() {
        global $Database;
        if ($this->Id > 0) {
            return $this->_Delete(self::TABLE_NAME, sprintf("Id = %d", $this->Id));
        }
        return FALSE;
    }
    
    private function SetExpireDate() {
        if (defined("EXPIRE_CLIENT_SESSION") && EXPIRE_CLIENT_SESSION) {
            try {
                $timezone = new DateTimeZone("Etc/UTC");
                $now = new DateTime("now", $timezone);
                $interval = new DateInterval('PT1H');
                $this->Expire = $now->add($interval)->format("Y-m-d H:i:s");
            } catch (Exception $ex) {
                $this->Expire = NULL;
                AppLog::Error("CB_Session::SetExpireDate error: " . $ex->getMessage());
            }
        } else {
            $this->Expire = NULL;
        }
    }
    
    /**
     * Updates the signature timestamp
     * 
     * @global Database $Database
     * @param int $timestamp The new signature timestamp
     * @return boolean Returns TRUE on success
     */
    function UpdateSignature ($timestamp) {
        global $Database;
        $this->SetExpireDate();
        $query = sprintf("UPDATE %s SET SignatureTimestamp = '%s', LastActionDate = %s, LastActionIP = '%s', Expire = %s WHERE Id = %d",
                self::TABLE_NAME,
                $Database->Escape($timestamp),
                $Database->EscapeDate(date("Y-m-d H:i:s")),
                $Database->Escape($_SERVER["REMOTE_ADDR"]),
                $Database->EscapeDate($this->Expire),
                $this->Id);
        if ($Database->Query($query)) {
            $this->SignatureTimestamp = $timestamp;
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Set the specified account as currently logged
     *
     * @param CB_Account $account Account to be set as current logged
     */
    public static function SetSession(&$account) {
        if ($account && is_a($account, "CB_Account") && $account->Id > 0) {
            $session = self::Load($account->Id, $account->GUID);
            if (count($session) > 0) {
                $session = $session[0];
            } else {
                $session = new self();
                $session->IdAccount = $account->Id;
                $session->GUID = $account->GUID;
            }
            $session->LastActionDate = date("Y-m-d H:i:s");
            $session->LastActionIP = $_SERVER["REMOTE_ADDR"];
            $session->Save();
        }
    }

    /**
     * Unset the current logged session
     * @global Database $Database
     * @param int $idAccount Filter IdAccount
     * @param string $guid Filter GUID
     * @return boolean
     */
    public static function UnsetSession($idAccount, $guid) {
        global $Database;
        $sql = sprintf("DELETE FROM %s WHERE IdAccount = %d AND GUID = '%s'", self::TABLE_NAME, $idAccount, $Database->Escape($guid));
        return $Database->Query($sql);
    }
    
    /**
     * Delete older sessions of this player
     * @param int $idAccount IdAccount
     * @global Database $Database
     */
    public static function ClearSessions($idAccount) {
        global $Database;
        // Get all sessions from 24 hours ago and earlier
        $date = date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), date("d") - 1, date("Y")));
        $where = sprintf("IdAccount = %d AND LastActionDate <= %s", $idAccount, $Database->EscapeDate($date));
        $recs = self::_load(self::TABLE_NAME, "CB_Session", $where);
        foreach ($recs as $rec) {
            $rec->Delete();
        }
    }
    
    public function IsExpired() {
        if ($this->Expire) {
            $timezone = new DateTimeZone("Etc/UTC");
            $now = new DateTime("now", $timezone);
            $expire = new DateTime($this->Expire, $timezone);
            //$diff = $expire->diff($now, FALSE)->s;
            $diff = $now->getTimestamp() - $expire->getTimestamp();
            return ($diff >= 0);
        }
        return FALSE;
    }
}
