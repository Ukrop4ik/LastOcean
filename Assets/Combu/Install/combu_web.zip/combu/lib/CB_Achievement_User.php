<?php

include_once "Database.php";
include_once "IDataClass.php";

/**
 * Class to handle Achievement User Records
 *
 * @author Skared Creations
 */
class CB_Achievement_User extends DataClass {

    const TABLE_NAME = "CB_Achievement_User";

    public $Id = 0;
    public $IdAchievement = 0;
    public $IdAccount = 0;
    public $Progress = 0;
    public $LastUpdated = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered scores
     *
     * @param string $idAccount Filter IdAccount
     * @param string $idAchievement Filter IdAchievement
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function LoadAccount ($idAccount, $idAchievement, $returnArray = false) {
        $where = sprintf("IdAccount = %d AND IdAchievement = %d", $idAccount, $idAchievement);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Achievement_User"), $where, "IdAchievement");
    }

    /**
     * Get the registered scores
     *
     * @param string $idAchievement Filter IdLeaderboard
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($idAchievement, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        $where = sprintf("au.IdAchievement = %d", $idAchievement);
        return self::_loadEx("au.*", self::TABLE_NAME . " au INNER JOIN " . CB_Account::TABLE_NAME . " u ON u.Id = au.IdAccount", ($returnArray ? "" : "CB_Achievement_User"), $where, "u.Username", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        $this->LastUpdated = date("Y-m-d H:i:s");
        if ($this->Id < 1) {
            $query = sprintf("INSERT INTO %s (IdAchievement, IdAccount, Progress, LastUpdated) VALUES (%d, %d, %d, %s)",
                    self::TABLE_NAME,
                    $this->IdAchievement,
                    $this->IdAccount,
                    $this->Progress,
                    $Database->EscapeDate($this->LastUpdated));
        } else {
            $query = sprintf("UPDATE %s SET Progress = %d, LastUpdated = %s WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->Progress,
                    $Database->EscapeDate($this->LastUpdated),
                    $this->Id);
        }
        $saved = $Database->Query($query);
        if ($saved) {
            if ($this->Id <= 0)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
