<?php

/**
 * Class to handle in-game Mail
 *
 * @author Skared Creations
 */
class CB_Mail extends DataClass {

    const TABLE_NAME = "CB_Mail";

    public $Id = 0;
    public $IdAccount = 0;
    public $IdGroup = 0;
    public $IdSender = 0;
    public $IsPublic = 0;
    public $SendDate = "";
    public $ReadDate = "";
    public $Subject = "";
    public $Message = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered messages
     *
     * @param int $idAccount Filter IdAccount (recipient)
     * @param int $idSender Filter IdSender (sender)
     * @param int $idGroup Filter IdGroup (multiple recipients)
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return CB_Mail[] Returns the array of records
     */
    public static function Load ($idAccount = 0, $idSender = 0, $idGroup = 0, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        $where = NULL;
        if ($idAccount > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdAccount = %d)", $idAccount);
        if ($idSender > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdSender = %d)", $idSender);
        if ($idGroup > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdGroup = %d)", $idGroup);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Mail"), $where, "SendDate DESC", $limit, $offset, $count);
    }
    
    /**
     * Get the messages sent to a user marked as unread
     * @param int $idAccount Filter the recipient
     * @return CB_Mail[]
     */
    public static function LoadUnread($idAccount, $idSenders = array(), $idGroups = array(), $returnArray = false) {
        $where = sprintf("(ReadDate IS NULL AND IdAccount = %d)", $idAccount);
        if (count($idSenders) > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdGroup = 0 AND IdSender IN (%s))", implode(",", $idSenders));
        if (count($idGroups) > 0)
            $where .= ($where ? " AND " : "") . sprintf("(IdGroup IN (%s))", implode(",", $idGroups));
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Mail"), $where, "SendDate DESC", $limit, $offset, $count);
    }
    
    /**
     * Get the conversations senders as array of users and groups
     * @param int $idAccount
     * @return array Array of CB_User and CB_UserGroup
     */
    public static function LoadConversations ($idAccount) {
        $where = sprintf("(IdAccount = %d OR IdSender = %d)", $idAccount, $idAccount);
        $query = "(SELECT IF(IdSender = " . $idAccount . ", IdAccount, IdSender) AS IdSender, IdGroup, SendDate FROM " . self::TABLE_NAME . " WHERE IdGroup = 0 AND " . $where . " GROUP BY IF(IdSender = " . $idAccount . ", IdAccount, IdSender))" .
                " UNION (SELECT 0 AS IdSender, IdGroup, SendDate FROM " . self::TABLE_NAME . " WHERE IdGroup > 0 AND IdAccount = " . $idAccount . " GROUP BY IdGroup ORDER BY SendDate DESC)" .
                " ORDER BY SendDate DESC";
        $recs = self::_loadQuery($query);
        $result = array();
        foreach ($recs as $r) {
            if ($r["IdGroup"] > 0) {
                $group = new CB_UserGroup($r["IdGroup"]);
                $result[] = $group->ToArray();
            } else {
                $user = new CB_Account($r["IdSender"]);
                $result[] = $user->ToArray();
            }
        }
        return $result;
    }

    /**
     * Get the registered messages
     *
     * @param int $myAccount Filter the owner account Id of the request (recipient or sender)
     * @param int $idGroup Filter IdGroup (multiple recipients)
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function LoadConversationMessages ($myAccount, $otherAccount, $idGroup, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        if ($otherAccount < 1 && $idGroup < 1) {
            return array();
        }
        $where = sprintf("(IdAccount = %d OR IdSender = %d)", $myAccount, $myAccount);
        if ($otherAccount > 0)
            $where .= sprintf(" AND (IdAccount = %d OR IdSender = %d)", $otherAccount, $otherAccount);
        if ($idGroup > 0)
            $where .= sprintf(" AND (IdGroup = %d)", $idGroup) . " GROUP BY IdSender, SendDate";
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_Mail"), $where, "SendDate DESC", $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     * @global Database $Database
     * @return boolean Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0) {
            $query = sprintf("UPDATE %s SET IsPublic = %d, Subject = '%s', Message = '%s', ReadDate = %s WHERE Id = %d",
                    self::TABLE_NAME,
                    $this->IsPublic,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Message),
                    $Database->EscapeDate($this->ReadDate),
                    $this->Id);
        } else {
            if (!$this->SendDate)
                $this->SendDate = date("Y-m-d H:i:s");
            $query = sprintf("INSERT INTO %s (SendDate, ReadDate, IdAccount, IdGroup, IdSender, IsPublic, Subject, Message) VALUES (%s, NULL, %d, %d, %d, %d, '%s', '%s')",
                    self::TABLE_NAME,
                    $Database->EscapeDate($this->SendDate),
                    $this->IdAccount,
                    $this->IdGroup,
                    $this->IdSender,
                    $this->IsPublic,
                    $Database->Escape($this->Subject),
                    $Database->Escape($this->Message));
        }
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return boolean Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
    
    public function ToArray() {
        $from = new CB_Account($this->IdSender);
        $to = new CB_Account($this->IdAccount);
        $array = Utils::ObjectToArray($this);
        $array["From"] = $from->ToJson();
        $array["To"] = $to->ToJson();
        if ($this->IdGroup > 0) {
            $group = new CB_UserGroup($this->IdGroup);
            $array["ToGroup"] = $group->ToArray();
        }
        return $array;
    }
    
    public function ToJson() {
        $array = $this->ToArray();
        return json_encode($array);
    }
}
