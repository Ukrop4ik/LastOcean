<?php

/**
 * Class to handle Newsletter's Log
 *
 * @author Skared Creations
 */
class CB_NewsletterLog extends DataClass {

    const TABLE_NAME = "CB_NewsletterLog";

    public $Id = 0;
    public $IdNewsletter = 0;
    public $IdAccount = 0;
    public $Sent = 0;
    public $DateCreation = "";
    public $Message = "";

    /**
     * Contructor
     */
    public function __construct($src = null, $stripSlashes = false) {
        global $Database;
        if ($src == null)
            return;
        if (is_array($src)) {
            // Load by array
            $this->_loadByRow($src, $stripSlashes);
        } else if (is_numeric($src) && intval($src) > 0) {
            // Load by Id
            $this->_loadFilter(self::TABLE_NAME, "Id = " . intval($src));
        }
    }

    /**
     * Get the registered inventory items
     *
     * @param int $idNewsletter Identifier of the Newsletter
     * @param int $limit Max number of results (for paged results)
     * @param int $offset Offset number of results (for paged results)
     * @param int $count Will be set to the total count of results
     * @param boolean $returnArray If TRUE then it will return associative arrays else objects
     * @return array Returns the array of records
     */
    public static function Load ($idNewsletter, $limit = null, $offset = null, &$count = null, $returnArray = false) {
        $where = sprintf("IdNewsletter = %d", $idNewsletter);
        return self::_load(self::TABLE_NAME, ($returnArray ? "" : "CB_NewsletterLog"), $where, NULL, $limit, $offset, $count);
    }

    /**
     * Save the record in the database
     *
     * @return bool Returns TRUE on success
     */
    public function Save() {
        global $Database;
        if ($this->Id > 0)
            return FALSE;
        $this->DateCreation = date("Y-m-d H:i:s");
        $query = sprintf("INSERT INTO %s (IdNewsletter, IdAccount, Sent, DateCreation, Message) VALUES (%d, %d, %d, %s, '%s')",
                self::TABLE_NAME,
                $this->IdNewsletter,
                $this->IdAccount,
                $this->Sent,
                $Database->EscapeDate($this->DateCreation),
                $Database->Escape($this->Message));
        if ($Database->Query($query)) {
            if ($this->Id < 1)
                $this->Id = $Database->InsertedId();
            return TRUE;
        }
        return FALSE;
    }

    /**
     * Delete the record from the database
     *
     * @return bool Returns TRUE on success
     */
    public function Delete() {
        if ($this->Id < 1)
            return FALSE;
        return $this->_Delete(self::TABLE_NAME, "Id = " . $this->Id);
    }
}
