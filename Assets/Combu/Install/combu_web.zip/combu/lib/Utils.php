<?

class Utils {
    
    /**
     * Converts from C# DateTime.Ticks to a Unix Timestamp
     * 
     * @param Integer $ticks
     * @return Integer 
     */
    public static function TicksToTime($ticks) {
        $mktime = (($ticks - 621355968000000000) / 10000000);
        $mktime -= 60 * 120;
        return $mktime;
    }
    /**
     * Converts from a Unix Timestamp to C# DateTime.Ticks
     * @param Integer $time
     * @return Integer
     */
    public static function TimeToTicks($time) {
        $time += 60 * 120;
        return number_format(($time * 10000000) + 621355968000000000 , 0, '.', '');
    }
    /**
     * Converts a given string into C# DateTime.Ticks. Uses strings valid in PHP
     * 
     * @link http://php.net/manual/en/function.strtotime.php
     * @param String $str
     * @return Integer
     */
    public static function StringToTicks($str) {
        return time_to_ticks(strtotime($str));
    }
    
    public static function RedirectTo ($url = "") {
        if (!$url)
            $url = $_SERVER["PHP_SELF"];
        header("Location: $url");
        exit();
    }
    public static function RedirectToSelf () {
        $url = $_SERVER["PHP_SELF"];
        $queryString = "";
        foreach ($_GET as $key => $value) {
            $queryString .= ($queryString ? "&" : "") . "$key=" . urlencode($value);
        }
        $url .= "?" . $queryString;
        header("Location: $url");
        exit();
    }

    public static function EchoJson($text, $encodeJson = FALSE) {
        if ($encodeJson === TRUE) {
            $text = json_encode($text);
        }
        ob_clean();
        header("Access-Control-Allow-Credentials:true");
        header("Access-Control-Allow-Headers:Accept, X-Access-Token, X-Application-Name, X-Request-Sent-Time");
        header("Access-Control-Allow-Methods:GET, POST, OPTIONS");
        header("Access-Control-Allow-Origin:*");
        header("Content-Type:text/json");
        echo $text;
        exit();
    }

    public static function EchoXml($xml) {
        ob_clean();
        header("Content-Type:text/xml");
        echo $xml;
        exit();
    }

    public static function StartsWith($text, $search, $ignoreCase = false) {
        $s = substr($text, 0, strlen($search));
        if ($ignoreCase === true)
            return (strtolower($s) == strtolower($search));
        return ($s == $search);
    }

    public static function EndsWith($text, $search, $ignoreCase = false) {
        $s = substr($text, -strlen($search));
        if ($ignoreCase === true)
            return (strtolower($s) == strtolower($search));
        return ($s == $search);
    }

    /**
     * Returns UNIX timestamp from the specified date string
     *
     * @param DateTime $data Date to check
     * @param int $add_days Number of days to add to the date
     * @return int Date/time UNIX timestamp
     *
     */
    public static function GetTimestamp($data, $add_days = 0) {
        if (strpos($data, " ") === false) {
            $a_data = $data;
            $a_time = "00:00";
        } else {
            $a_data = substr($data, 0, strpos($data, " "));
            $a_time = substr($data, strpos($data, " ") + 1);
        }
        $a_data = explode("/", str_replace("-", "/", $a_data));
        $a_time = explode(":", str_replace(".", ":", $a_time));
        if (strlen($a_data[0]) == 4) {
            // From ISO format (YYYY/MM/DD)
            $timestamp = mktime($a_time[0], $a_time[1], count($a_time) == 3 ? $a_time[2] : 0, $a_data[1], $add_days + $a_data[2], $a_data[0]);
        } else {
            // From ITA format (DD/MM/YYYY)
            $timestamp = mktime($a_time[0], $a_time[1], count($a_time) == 3 ? $a_time[2] : 0, $a_data[1], $add_days + $a_data[0], $a_data[2]);
        }
        return $timestamp;
    }
    
    public static function IsValidDate($text) {
        $datebit = "";
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $text, $datebit))
           return checkdate($datebit[2] , $datebit[3] , $datebit[1]);
        return false;
    }
    
    public static function IsValidTime($text) {
        $datebit = "";
        if (preg_match('/^(\d{2}):(\d{2})$/', $text, $datebit))
           return ($datebit[1] >= 0 && $datebit[1] <= 59) && ($datebit[2] >= 0 && $datebit[2] <= 59);
        else if (preg_match('/^(\d{2}):(\d{2}):(\d{2})$/', $text, $datebit))
           return ($datebit[1] >= 0 && $datebit[1] <= 59) && ($datebit[2] >= 0 && $datebit[2] <= 59) && ($datebit[3] >= 0 && $datebit[3] <= 59);
        return false;
    }

    public static function ConvertSizeFromBytes($bytes, $to = NULL) {
        $float = floatval($bytes);
        switch ($to) {
            case 'Kb' :            // Kilobit
                $float = ( $float * 8 ) / 1024;
                break;
            case 'b' :             // bit
                $float *= 8;
                break;
            case 'GB' :            // Gigabyte
                $float /= 1024;
            case 'MB' :            // Megabyte
                $float /= 1024;
            case 'KB' :            // Kilobyte
                $float /= 1024;
            default :              // byte
        }
        unset($bytes, $to);
        $float = round($float, 1);
        return( $float );
    }

    public static function ExtractSearchKeywords($searchText) {
        $keys = array();
        $testo = preg_replace("/\s{2,}/", " ", $searchText);
        preg_match_all("|\"[^\"]+\"|", $testo, $multiple);
        foreach ($multiple[0] as $frase) {
            $testo = str_replace($frase, "", $testo);
            $keys[] = str_replace('"', '', $frase);
        }
        $arr_testo = explode(" ", $testo);
        foreach ($arr_testo as $s) {
            if ($s == "" || in_array($s, $keys))
                continue;
            $keys[] = $s;
        }
        return $keys;
    }

    public static function CalcPercentage($total, $count) {
        if ($total == 0 || $count == 0)
            return 0;
        $perc = number_format((floatval($count) / floatval($total)) * 100, 2);
        if (substr($perc, -2) == "00")
            return substr($perc, 0, strlen($perc) - 3);
        if (substr($perc, -1) == "0")
            return substr($perc, 0, strlen($perc) - 1);
        return $perc;
    }

    public static function GetPageOffset($page, $limit) {
        if ($page == 1)
            return 0;
        return $limit * ($page - 1);
    }

    public static function GetPagesCount($count, $limit) {
        return ceil($count / $limit);
    }

    /**
     * Get a normalized string to use as filename starting from a specified file path, replacing all the non alphanumeric characters with an underscore
     *
     * @param string $oldName String to normalize
     * @param type $newExt New extension to append to the returned string
     * @return string A valid filename
     */
    public static function GetValidFilename($oldName, $newExt = "") {
        $newName = "";
        $name = $oldName;
        $ext = Utils::GetFilenameExtension($name);
        if ($ext != "") {
            $name = substr($name, 0, strlen($name) - strlen($ext));
        }
        for ($i = 0; $i < strlen($name); $i++) {
            $char = substr($name, $i, 1);
            if (!preg_match("/^[a-zA-Z0-9._-]$/", $char))
                $char = "_";
            $newName .= $char;
        }
        $newName .= ($newExt != "" ? $newExt : $ext);
        return $newName;
    }

    /**
     * Get the extension of a file path
     *
     * @param string $filename The file path to check
     * @return string The file extension
     */
    public static function GetFilenameExtension($filename) {
        $i = strrpos($filename, ".");
        if ($i === false)
            return "";
        return substr($filename, $i);
    }

    /**
     * Generate a random temporary filename with ".tmp" extension
     *
     * @return string Temporary file name
     */
    public static function GetTempname($fileExt = ".tmp") {
        $tmp_name = md5(microtime()) . $fileExt;
        return $tmp_name;
    }

    /**
     * Generate a random sequence of characters for password
     *
     * @param int $length The length of the password to generate
     * @return string A random password
     */
    public static function GenerateRandomPassword($length = "8") {
        $password = "";
        $ulettera = "";
        // Generate random characters until the requested length
        for ($i = 0; $i < $length; $i++) {
            $letter = chr(rand(48, 122));
            // If it is not alphanumeric then generate another the character
            //while (!ereg("[a-zA-Z0-9]", $letter)) {
            while (!preg_match('/[a-zA-Z0-9]/', $letter)) {
                // Avoid the last selected character
                if ($letter == $ulettera)
                    continue;
                $letter = chr(rand(48, 90));
            }
            // Add the character to the password
            $password .= $letter;
            // Store the latest generated character
            $ulettera = $letter;
        }
        return $password; // restituisci alla funzione
    }

    /**
     * Verify if a string is a valid email address
     * @param string $email String to check
     * @return boolean TRUE if is a valid email address
     */
    public static function IsValidEmail($email) {
        $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i';
        return preg_match($regex, $email);
    }

    /**
     * Returns a pre-formatted JSON string: {total: <$count>, results: <$rows>}
     * @param array $rows Array of associative arrays
     * @param int $count Total value
     * @return string JSON formatted string
     */
    public static function JsonEncodeRowsMessage($rows, $count, $pagesCount = NULL, $extraParams = NULL) {
        if (count($rows) > 0 && $rows[0] !== NULL && is_subclass_of($rows[0], "DataClass")) {
            $temp = array();
            foreach ($rows as $r) {
                $temp[] = $r->ToArray();
            }
            $rows = $temp;
        }
        for ($i = 0; $i < count($rows); $i++) {
            foreach ($rows[$i] as $k => $v) {
                if (is_array($v) || is_object($v))
                    continue;
                if (is_numeric($v) || is_bool($v))
                    continue;
                elseif ($v == null || $v == "NULL")
                    $rows[$i][$k] = "";
                elseif (substr($v, 0, 10) == "00/00/0000" || substr($v, 0, 10) == "0000-00-00")
                    $rows[$i][$k] = "";
            }
        }
        $result = array("total" => $count, "results" => $rows);
        if ($pagesCount !== NULL)
            $result["pages"] = $pagesCount;
        if ($extraParams !== NULL && is_array($extraParams))
            $result = array_merge ($result, $extraParams);
        return json_encode($result);
    }

    /**
     * Returns a pre-formatted JSON string: {success: <$success>, message: <$message>, errors: <$errors>}
     * @param boolean $success Success value
     * @param string $message Message value
     * @param array $errors Array of error strings
     * @return string JSON formatted string
     */
    public static function JsonEncodeSuccessMessage($success = true, $message = "", $errors = array()) {
        return json_encode(array("success" => $success, "message" => $message, "errors" => $errors));
    }

    /**
     * Initialize the object properties from an associative array
     *
     * @param mixed $obj Object to initialize
     * @param array $row Associative array from to load the properties
     * @param boolean $stripSlashes Use stripslashes() on $row (usually if $row is $_REQUEST/$_GET/$_POST
     * @param mixed $callbackOnExists (Optional) Callback to call when setting a property, it overrides the common property value assignment
     */
    public static function FillObjectFromRow(&$obj, $row, $stripSlashes = false, $callbackOnExists = false) {
        $props = get_class_vars(get_class($obj));
        foreach ($props as $prop => $value) {
            if (array_key_exists($prop, $row)) {
                if (!$callbackOnExists) {
                    $value = ($stripSlashes ? trim(stripslashes($row[$prop])) : $row[$prop]);
                    /*if ($stripSlashes && self::IsUtf8($value)) {
                        $value = utf8_decode($value);
                    }*/
                    $obj->$prop = $value;
                }
                else
                    $obj->$callbackOnExists($prop, $row[$prop]);
            }
        }
    }

    /**
     * Returns an associative array from object properties (the property name will be the key)
     *
     * @param mixed $obj Object to convert
     * @return array Associative array filled with properties names and values
     *
     */
    public static function ObjectToArray($obj) {
        $array = array();
        if (is_a($obj, "stdClass")) {
            $variables = get_object_vars($obj);
            $keys = array_keys($variables);
            foreach ($keys as $k) {
                $array[$k] = $obj->$k;
            }
        } else {
            $props = get_class_vars(get_class($obj));
            foreach ($props as $prop => $value) {
                $array[$prop] = $obj->$prop;
            }
        }
        return $array;
    }
}
