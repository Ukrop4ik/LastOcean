<?

define ("COMBU_VERSION", "2.1.10");
define ("ROOT", dirname(dirname(__FILE__)));
define ("LIBROOT", ROOT . "/lib/");
define ("ADDONS_FOLDER", ROOT . "/addons/");

include_once dirname(__FILE__) . "/config.php";
include_once dirname(__FILE__) . "/constants.php";

// Base classes
include_once LIBROOT . "/Database.php";
include_once LIBROOT . "/Utils.php";
include_once LIBROOT . "/SymmetricEncryption.php";
include_once LIBROOT . "/FileUpload.php";
include_once LIBROOT . "/AppLog.php";
include_once LIBROOT . "/Mail.php";
include_once LIBROOT . '/AddonModule.php';

// Database classes
include_once LIBROOT . "/CB_ServerSettings.php";
include_once LIBROOT . "/CB_Account.php";
include_once LIBROOT . "/CB_Session.php";
include_once LIBROOT . "/CB_Account_Platform.php";
include_once LIBROOT . "/CB_CustomData.php";
include_once LIBROOT . "/CB_Inventory.php";
include_once LIBROOT . "/CB_UserFiles.php";
include_once LIBROOT . "/CB_UserFilesActivity.php";
include_once LIBROOT . "/CB_Friend.php";
include_once LIBROOT . "/CB_LeaderBoard.php";
include_once LIBROOT . "/CB_LeaderBoard_User.php";
include_once LIBROOT . "/CB_Achievement.php";
include_once LIBROOT . "/CB_Achievement_User.php";
include_once LIBROOT . "/CB_News.php";
include_once LIBROOT . "/CB_Mail.php";
include_once LIBROOT . "/CB_UserGroup.php";
include_once LIBROOT . "/CB_Newsletter.php";
include_once LIBROOT . "/CB_Match.php";
include_once LIBROOT . "/CB_Tournament.php";

ob_start();
session_start();

// Initialize the application logging utility
AppLog::Initialize();

// Set the default Timezone to UTC
date_default_timezone_set ("UTC");

// Initialize the global Database
global $Database;
$Database = new Database(GAME_DB_SERVER, GAME_DB_NAME, GAME_DB_USER, GAME_DB_PASS);

// Initialize the global logged account (frontend)
global $LoggedAccount;
$LoggedAccount = CB_Account::LoadRequest();

// Initialize the game server settings
global $ServerSettings;
$ServerSettings = CB_ServerSettings::GetCurrentSettings();

define("SECURITY_ENABLED", (defined("SECRET_KEY") && SECRET_KEY != ""));

global $Addons;
$Addons = AddonModule::LoadAddons();

/**
 * Verify that the call to a webservice is valid and secure signed
 * 
 * @global type $LoggedAccount
 */
function checkWebserviceSecurity () {
    global $LoggedAccount;
    // Exit function if no secret key is defined
    if (!SECURITY_ENABLED)
        return TRUE;
    // Get the request timestamp
    $timestamp = (isset($_REQUEST["sig_time"]) ? stripslashes($_REQUEST["sig_time"]) : "");
    $savedTimestamp = NULL;
    $skipUserTimestamp = (!defined("SKIP_USER_TIMESTAMP") || SKIP_USER_TIMESTAMP);
    
    // Check the session timestamp
    if (!$skipUserTimestamp && $LoggedAccount->IsLogged()) {
        $session = $LoggedAccount->GetSession();
        // Verify that the request timestamp is greater than the latest
        $savedTimestamp = $session->SignatureTimestamp;
        if (strcmp($savedTimestamp, $timestamp) > 0) {
            AppLog::Info("Unauthorized SignatureTimestamp: ". $savedTimestamp . " - " . $timestamp . " = " . strcmp($savedTimestamp, $timestamp) . " - Id: " . $LoggedAccount->Id . " - GUID: " . $LoggedAccount->GUID);
            die ("Unauthorized request");
        }
    }

    // Build the signature value that is expected
    $test = "";
    // First add the request timestamp
    $test .= $timestamp;
    // Then add the GUID of the logged account
    $test .= $LoggedAccount->GUID;
    // Finally add the secret key
    $test .= SECRET_KEY;
    // Encrypt the expected signature
    $test = sha1($test);
    // Compare the received checksum signature to what we expect
    $signature = (isset ($_REQUEST["sig_crc"]) ? stripslashes ($_REQUEST["sig_crc"]) : "");
    if (strcmp($test, $signature) == 0) {
        // If the player is logged, then update the last action date/time
        if ($LoggedAccount->IsLogged())
            $LoggedAccount->UpdateSignature($timestamp);
        return TRUE;
    }
    AppLog::Info("Unauthorized CRC: " . $test . " - Signature: " . $signature . " - Saved Timestamp: " . $savedTimestamp . " - Timestamp: " . $timestamp . " - Id: " . $LoggedAccount->Id . " - GUID: " . $LoggedAccount->GUID);
    die ("Unauthorized request");
}
