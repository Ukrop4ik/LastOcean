<?php

/**
 * This script is an example of how to integrate Combu with Photon Server,
 * you have to set the URL to this file as endpoint of Photon Server account verification
 */

include '../lib/api.php';

$username = filter_input(INPUT_GET, "username");
$password = filter_input(INPUT_GET, "password");

if (!$username || !$password) {
    $login_info = array(
        "ResultCode" => 3,
        "Message" => "Wrong data",
    );
} else {
    // Verify the credentials
    $success = CB_Account::CheckLogin($username, $password);

    if ($success) {
        $login_info = array(
            "ResultCode" => 1,
            "Message" => "You are connected!",
        );
    } else {
        $login_info = array(
            "ResultCode" => 2,
            "Message" => "Wrong username or password",
        );
    }
}

Utils::EchoJson($login_info, TRUE);
