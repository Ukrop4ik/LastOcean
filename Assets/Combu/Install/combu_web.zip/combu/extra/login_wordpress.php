<?php

/**
 * This script is an example of how to integrate Combu with your Wordpress accounts
 */

define ("WORDPRESS_SERVER", "localhost");
define ("WORDPRESS_NAME", "wordpress");
define ("WORDPRESS_USERNAME", "root");
define ("WORDPRESS_PASSWORD", "");
define ("WORDPRESS_ROOT", "../../../wp/");

include '../lib/api.php';
include WORDPRESS_ROOT . 'wp-load.php';

$success = FALSE;
$message = "";

$DatabaseWP = new Database(WORDPRESS_SERVER, WORDPRESS_NAME, WORDPRESS_USERNAME, WORDPRESS_PASSWORD);

if (!$DatabaseWP->GetConnection()) {
    
    // You can debug by passing $DatabaseWP->GetError()
    // but it's not recommended in live environment for security reasons
    $message = "Connection to WP not established";
    
} else {

    $username = filter_input(INPUT_POST, "Username");
    $password = filter_input(INPUT_POST, "Password");
    
    $user = NULL;
    
    // Get the Wordpress account
    $query = sprintf("SELECT ID, user_pass FROM wp_users WHERE user_login = '%s'", $DatabaseWP->Escape($username));
    $res = $DatabaseWP->Query($query);
    if ($res) {
        $userWP = $DatabaseWP->Fetch($res);
        if ($userWP) {
            // Verify the password with Wordpress API
            if (wp_check_password($password, $userWP["user_pass"])) {
                // Load or create the Combu account
                $user = new CB_Account($username);
                if ($user->Id > 0) {
                    $success = TRUE;
                } else {
                    $user->Username = $username;
                    $user->Enabled = 1;
                    if ($user->Save()) {
                        $success = TRUE;
                        // We can store Wordpress UserID for later use
                        $platform = new CB_Account_Platform();
                        $platform->IdAccount = $user->Id;
                        $platform->PlatformKey = "Wordpress";
                        $platform->PlatformId = $userWP["ID"];
                        $platform->Save();
                    }
                }
            }
        }
    }
    
    if ($success) {
        if (!$user->Enabled) {
            $message = "Your account is disabled";
            $success = FALSE;
        } else {
            if (SECURITY_ENABLED)
                $user->UpdateSignature($timestamp);
            CB_Account::SetSession($user);
            $message = $user->ToJson();
        }
    } else {
        $message = "Credentials are invalid";
    }
}

Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
