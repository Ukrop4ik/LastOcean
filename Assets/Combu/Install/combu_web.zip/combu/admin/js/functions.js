// Add .trim() method to strings
if(!String.prototype.trim) {  
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g,'');  
    };
}

function toggleBusy (isBusy) {
    if (isBusy) {
        dialogLoading.dialog("open");
    } else {
        dialogLoading.dialog("close");
    }
}
