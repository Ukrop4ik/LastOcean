<?php

include_once '../lib/api.php';

// Include admin-only classes
include_once '../lib/CB_AdminAccount.php';

define("ADMIN_ROOT", ROOT . "/admin/");
define("ADMIN_ROOT_URL", URL_ROOT . "admin/");

function printAlertError($error) {
    if ($error)
        $error = '<div class="error ui-widget" data-time="3">' .
            '<div class="ui-state-error ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">' .
            '<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span>' .
            $error .
            '</div></div>';
    return $error;
}

function printAlertDisappear($text, $icon = "ui-icon-info") {
    if ($text)
        $text = '<div class="disappear-text ui-widget" data-time="3">' .
                '<div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">' .
                '<p>' . ($icon ? '<span class="ui-icon ' . $icon . '" style="float: left; margin-right: .3em;"></span>' : '') .
                $text .
                '</p></div></div>';
    return $text;
}

global $AdminLogged;
$AdminLogged = CB_AdminAccount::GetSession();
