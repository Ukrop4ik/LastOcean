<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$achievement = (!isset($_REQUEST["Id"]) ? NULL : new CB_Achievement(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($achievement) {
                Utils::FillObjectFromRow($achievement, $_REQUEST, TRUE);
                if (!$achievement->Title)
                    $error = "Enter the Title";
                else {
                    if ($achievement->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($achievement) {
                $achievement->Delete();
            }
            // Return to list
            Utils::RedirectTo("?deleted=1");
            break;

    // Action Delete Score
        case "delete_score":
            if ($achievement) {
                $score = new CB_Achievement_User(!isset($_REQUEST["IdScore"]) ? 0 : intval($_REQUEST["IdScore"]));
                $score->Delete();
            }
            // Return to list
            Utils::RedirectTo("?saved=1");
            break;

    // Action Move Up an achievement in the list
        case "up":
            if ($achievement) {
                $achievement->MoveUp();
            }
            // Return to list
            Utils::RedirectTo("?saved=1");
            break;

    // Action Move Down an achievement in the list
        case "down":
            if ($achievement) {
                $achievement->MoveDown();
            }
            // Return to list
            Utils::RedirectTo("?saved=1");
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$achievement) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $achievements = CB_Achievement::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$achievement) { ?>

    <fieldset id="list">
        <legend>Achievements</legend>
        
        <div align="right">
            <button class="button" onclick="document.location.href='?Id=0'">Create Achievement</button>
        </div>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="300"></th>
                    <th width="100" align="right">Id</th>
                    <th align="left">Title</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
        
        <?
        $i = 0;
        $max = count($achievements);
        ?>
        <? foreach ($achievements as $achievement) { ?>
            <? $i++; ?>
            
            <tr>
                <td nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this Achievement?')) document.location.href='?action=delete&Id=<?= $achievement->Id ?>';">Delete</button>
                    <button class="button" onclick="document.location.href='?action=scores&Id=<?= $achievement->Id ?>';">Scores</button>
                    <button style="width:48px;" class="button <? if ($i >= $max) echo "button_disabled"; ?>" <? if ($i < $max) { ?>onclick="document.location.href='?action=down&Id=<?= $achievement->Id ?>';"<? } else { ?>disabled<? } ?>>&DownArrow;</button>
                    <button style="width:48px;" class="button <? if ($i <= 1) echo "button_disabled"; ?>" <? if ($i > 1) { ?>onclick="document.location.href='?action=up&Id=<?= $achievement->Id ?>';"<? } else { ?>disabled<? } ?>>&UpArrow;</button>
                </td>
                <td align="right"><a href="?Id=<?= $achievement->Id ?>"><?= $achievement->Id ?></a></td>
                <td><?= htmlentities($achievement->Title, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>

    <? if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "scores") { ?>

    &LeftArrow; <a href="?">Back to Achievements</a>
    
    <fieldset id="list">
        <legend>Progresses from: <?= htmlentities($achievement->Title, ENT_QUOTES, 'UTF-8') ?></legend>
        <?
        $limit = DEFAULT_LIST_LIMIT;
        $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
        $count = 0;
        $order = "";
        $field = "";
        $scores = CB_Achievement_User::Load($achievement->Id, $limit, Utils::GetPageOffset($page, $limit), $count);
        $pagesCount = Utils::GetPagesCount($count, $limit);
        ?>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th align="left">Player</th>
                    <th width="150" align="right">Progress <img src="images/ribbon.png" alt="Progress" title="Progress" /></th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>

        <? foreach ($scores as $score) { ?>
        
        <? $user = new CB_Account($score->IdAccount); ?>
            <tr>
                <td nowrap>
                    <button style="float:right;" class="button ui-state-error" onclick="if (confirm('Delete this Progress?')) document.location.href='?action=delete_score&Id=<?= $achievement->Id ?>&IdScore=<?= $score->Id ?>';">Delete</button>
                </td>
                <td><a href="users.php?Id=<?= $user->Id ?>"><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></a></td>
                <td align="right"><?= $score->Progress ?>&percnt;</td>
            </tr>
        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="action" value="scores"/>
                                <input type="hidden" name="Id" value="<?= $achievement->Id ?>"/>
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>
        
    </fieldset>

    <? } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Achievements</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Achievement Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <? if ($achievement->Id > 0) { ?><div class="field"><label>Id</label> <b><?= $achievement->Id ?></b></div><? } ?>
            <div class="field"><label>Title</label><input type="text" name="Title" value="<?= htmlentities($achievement->Title, ENT_QUOTES, 'UTF-8') ?>"/></div>
            <div class="field"><label>Description</label><textarea name="Description"><?= htmlentities($achievement->Description, ENT_QUOTES, 'UTF-8') ?></textarea></div>
            <div class="field">
                <label>Can Be Repeated</label>
            <? if ($achievement->Id > 0) { ?>
                <input type="hidden" name="UniqueRecords" value="<?= $achievement->UniqueRecords ?>"/>
                <strong><?= ($achievement->UniqueRecords == 1 ? "No (user can complete one time)" : "Yes (the user can repeat it)") ?></strong>
            <? } else { ?>
                <select name="UniqueRecords">
                    <option value="1" <? if ($achievement->UniqueRecords == 1) echo ' selected'; ?>>No (user can complete one time)</option>
                    <option value="0" <? if ($achievement->UniqueRecords == 0) echo ' selected'; ?>>Yes (the user can repeat it)</option>
                </select>
            <? } ?>
            </div>
            <div class="field"><label>&nbsp;</label>
            <input type="submit" class="button" value="Save"/> or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

    <? } ?>

<? } ?>

<? include './footer.php'; ?>