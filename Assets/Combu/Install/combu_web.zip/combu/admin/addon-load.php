<?php

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$addonName = filter_input(INPUT_GET, "addon");
$addonMenu = intval(filter_input(INPUT_GET, "menu"));

// Load the addon
$addon = AddonModule::GetAddon($addonName);
if (!$addon)
    Utils::RedirectTo ("index.php");

// Verify that admin menu is valid
$menu = $addon->GetAdminMenu();
if ($addonMenu < 0 || $addonMenu >= count($menu))
    Utils::RedirectTo ("index.php");

// Verify that requested menu url exists
$addonFile = $addon->GetFile($menu[$addonMenu]["Url"]);
if (!file_exists($addonFile))
    Utils::RedirectTo ("index.php");

// Load the addon page
include './header.php';
include $addonFile;
include './footer.php';

?>
<script>
    $(function () {
        $("#menu .menu-section-link[data-addon-menu='<?= $addonMenu ?>']").addClass("menu-section-active");
    });
</script>