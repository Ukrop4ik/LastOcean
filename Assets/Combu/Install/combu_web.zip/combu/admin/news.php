<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$record = (!isset($_REQUEST["Id"]) ? NULL : new CB_News(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($record) {
                Utils::FillObjectFromRow($record, $_REQUEST, TRUE);
                if (!$record->Subject)
                    $error = "Enter the Subject";
                else if (!$record->Message)
                    $error = "Enter the Message";
                else {
                    $record->IdAdminAccount = $AdminLogged->Id;
                    if ($record->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($record) {
                $record->Delete();
                // Return to list
                Utils::RedirectTo("?deleted=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$record) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $records = CB_News::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$record) { ?>

    <fieldset id="list">
        <legend>News</legend>
        
        <div align="right">
            <button class="button" onclick="document.location.href='?Id=0'">Create News</button>
        </div>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th width="100" align="right">Id</th>
                    <th width="200" align="left">Date</th>
                    <th align="left">Subject</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>
        
        <? foreach ($records as $record) { ?>

            <tr>
                <td nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this News?')) document.location.href='?action=delete&Id=<?= $record->Id ?>';">Delete</button>
                </td>
                <td align="right"><a href="?Id=<?= $record->Id ?>"><?= $record->Id ?></a></td>
                <td><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->PublishDate)) ?></td>
                <td><?= htmlentities($record->Subject, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to News</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>News Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <? if ($record->Id > 0) { ?>
            <div class="field"><label>Id</label> <b><?= $record->Id ?></b></div>
            <div class="field"><label>Publish date</label> <b><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->PublishDate)) ?></b></div>
            <? } ?>
            <div class="field"><label>Subject</label><input type="text" name="Subject" value="<?= htmlentities($record->Subject, ENT_QUOTES, 'UTF-8') ?>"/></div>
            <div class="field"><label>Message</label><textarea name="Message"><?= htmlentities($record->Message, ENT_QUOTES, 'UTF-8') ?></textarea></div>
            <div class="field"><label>URL</label><input type="text" name="Url" value="<?= htmlentities($record->Url, ENT_QUOTES, 'UTF-8') ?>"/></div>
            <div class="field"><label>&nbsp;</label>
            <input type="submit" class="button" value="Save"/> or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

<? } ?>

<? include './footer.php'; ?>