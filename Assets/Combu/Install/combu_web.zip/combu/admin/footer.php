            </div>
            <div id="footer">&copy; <?= date("Y") ?> <a href="http://skaredcreations.com/wp/products/combu/" target="_blank"><strong>Combu</strong></a> is a product from <a href="http://skaredcreations.com" target="_blank" title="Skared Creations"><img src="images/skared_creations.png" border="0" alt="Skared Creations"/></a></div>
        </div>
        
        <div id="dlg-loading">Please wait...<br/><img src="images/loading.gif" /></div>
        
    </body>
</html>