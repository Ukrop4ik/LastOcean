<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$user = (!isset($_REQUEST["Id"]) ? NULL : new CB_Account(intval($_REQUEST["Id"])));
$currentUsername = ($user ? $user->Username : "");
$customData = ($user ? CB_CustomData::Load($user->Id) : NULL);

$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // Action Save
        case "save":
            if ($user) {
                $errorPassword = "";
                $newPassword = stripslashes( $user->Id > 0 ? $_REQUEST["NewPassword"] : $_REQUEST["Password"] );
                $confirmPassword = stripslashes($_REQUEST["ConfirmPassword"]);
                if ($user->Id > 0) {
                    if ($newPassword) {
                        if ($newPassword == $confirmPassword) {
                            $user->Password = md5($newPassword);
                        } else {
                            $errorPassword = "Confirm Password is different";
                        }
                    }
                } else {
                    if (!$newPassword) {
                        $errorPassword = "Enter the Password and Confirm";
                    } else if ($newPassword != $confirmPassword) {
                        $errorPassword = "Confirm Password is different";
                    }
                }
                Utils::FillObjectFromRow($user, $_REQUEST, TRUE);
                if ($errorPassword) {
                    $error = $errorPassword;
                } else if (!$user->Username) {
                    $error = "Enter the Username";
                } else {
                    $isNew = ($user->Id < 1);
                    if ($user->Save()) {
                        // Save custom data key/value pairs, if any
                        if (isset($_REQUEST["custom_key"])) {
                            $customKeys = $_REQUEST["custom_key"];
                            $customValues = $_REQUEST["custom_value"];
                            // Ensure they are array
                            if (!is_array($customKeys))
                                $customKeys = array($customKeys);
                            if (!is_array($customValues))
                                $customValues = array($customValues);
                            // Cycle through the keys/values
                            for ($i = 0; $i < count($customKeys); $i++) {
                                $customData = new CB_CustomData();
                                $customData->IdAccount = $user->Id;
                                $customData->DataKey = $customKeys[$i];
                                $customData->DataValue = $customValues[$i];
                                $customData->Save();
                            }
                        }
                        // Return to list
                        Utils::RedirectTo("?saved=1" . ($isNew ? "&Id=" . $user->Id : ""));
                    } else
                        $error = "An error occurred";
                }
            }
            break;

        // Action Delete
        case "delete":
            if ($user) {
                $user->Delete();
                Utils::RedirectTo("?deleted=1");
            }
            break;
            
        // Save a Custom Data
        case "save_custom":
            if ($user) {
                $myKey = filter_input(INPUT_POST, "custom_key");
                $myValue = filter_input(INPUT_POST, "custom_value");
                if ($myKey) {
                    $success = FALSE;
                    foreach ($customData as $data) {
                        if ($data->DataKey == $myKey) {
                            $data->DataValue = $myValue;
                            $data->Save();
                            $success = TRUE;
                            break;
                        }
                    }
                    if (!$success) {
                        $data = new CB_CustomData();
                        $data->IdAccount = $user->Id;
                        $data->DataKey = $myKey;
                        $data->DataValue = $myValue;
                        $data->Save();
                    }
                }
            }
            Utils::RedirectTo("?Id=" . $user->Id . "&saved=1");
            break;
            
        // Delete a Custom Data
        case "delete_custom":
            if ($user) {
                $myKey = filter_input(INPUT_POST, "custom_key");
                if ($myKey) {
                    foreach ($customData as $data) {
                        if ($data->DataKey == $myKey) {
                            $data->Delete();
                            break;
                        }
                    }
                }
            }
            Utils::RedirectTo("?Id=" . $user->Id . "&saved=1");
            break;
            
        // User File Delete
        case "delete_file":
            if ($user) {
                $file = new CB_UserFiles(!isset($_REQUEST["file"]) ? 0 : intval($_REQUEST["file"]));
                if ($file->Delete())
                    @unlink (UPLOAD . $file->Url);
                if (isset($_GET["action"]))
                    unset($_GET["action"]);
                Utils::RedirectTo("?Id=" . $user->Id . "&saved=1");
            }
            break;

    }
}

// Display list if there is no active record
if (!$user) {
    $username = (!isset($_REQUEST["Username"]) ? NULL : trim(stripslashes($_REQUEST["Username"])));
    $email = (!isset($_REQUEST["Email"]) ? NULL : trim(stripslashes($_REQUEST["Email"])));
    $online = ( isset($_REQUEST["Online"]) && $_REQUEST["Online"] == "1" );
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $users = CB_Account::Load($username, $email, NULL, $online, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
} else {
    $files = CB_UserFiles::Load($user->Id);
    
    // Load the leaderboards and scores
    $leaderboardsScores = array();
    $leaderboards = CB_LeaderBoard::Load();
    foreach ($leaderboards as $leaderboard) {
        $scoreToday = $leaderboard->LoadHighscoreForAccount(CB_LEADERBOARD_HIGHSCORE_TODAY, FALSE, FALSE, $user->Id);
        $scoreWeek = $leaderboard->LoadHighscoreForAccount(CB_LEADERBOARD_HIGHSCORE_WEEK, FALSE, FALSE, $user->Id);
        $scoreMonth = $leaderboard->LoadHighscoreForAccount(CB_LEADERBOARD_HIGHSCORE_MONTH, FALSE, FALSE, $user->Id);
        $scoreTotal = $leaderboard->LoadHighscoreForAccount(CB_LEADERBOARD_HIGHSCORE_TOTAL, FALSE, FALSE, $user->Id);
        $leaderboardsScores[$leaderboard->Id] = array(
            "today" => array( "rank" => $scoreToday["Rank"], "score" => $scoreToday["Score"] ),
            "week" => array( "rank" => $scoreWeek["Rank"], "score" => $scoreWeek["Score"] ),
            "month" => array( "rank" => $scoreMonth["Rank"], "score" => $scoreMonth["Score"] ),
            "total" => array( "rank" => $scoreTotal["Rank"], "score" => $scoreTotal["Score"] )
        );
    }
    
    // Load achievements
    $achievements = CB_Achievement::LoadUserAchievements($user->Id);
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$user) { ?>

    <style>
    .user-disabled td {background-color: #ededed;}
    .user-online td {background-color: #ccffcc;}
    </style>

    <fieldset id="list">
        <legend>Players</legend>
        
        <form method="post">
            <div class="field">
                <label>Username</label>
                <input type="text" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="field">
                <label>Email</label>
                <input type="text" name="Email" value="<?= htmlentities($email, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="field">
                <label>Online state</label>
                <select name="Online">
                    <option value="" <? if (!$online) echo 'selected'; ?>>Any state</option>
                    <option value="1" <? if ($online) echo 'selected'; ?>>Online</option>
                </select>
            </div>
            <div class="field" style="text-align: right;">
                <input type="submit" class="button" value="Search"/>
                <input type="button" class="button" value="Create Player" onclick="document.location.href = '?Id=0';"/>
            </div>
        </form>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th width="100" align="right">Id</th>
                    <th align="left">Username/Email</th>
                    <th width="160" align="left">Last action</th>
                    <th width="80" align="left">Enabled</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
        
        <? foreach ($users as $user) { ?>
            <?
            $userIsOnline = $user->IsOnline();
            $lastAction = $user->GetLastActionDate();
            if (!$user->Enabled)
                $title = "This user is disabled";
            else
                $title =  ($userIsOnline ? "This user is currently online" : "");
            ?>
            <tr class="<? if (!$user->Enabled) echo "user-disabled"; ?> <? if ($userIsOnline) echo "user-online"; ?>">
                <td title="<?= $title ?>" nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this User?')) document.location.href='?action=delete&Id=<?= $user->Id ?>';">Delete</button>
                </td>
                <td title="<?= $title ?>" align="right"><a href="?Id=<?= $user->Id ?>"><?= $user->Id ?></td>
                <td title="<?= $title ?>"><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?><br/><? if ($user->Email) { ?><a title="Send an email to this address" href="mailto:<?= htmlentities($user->Email) ?>"><?= htmlentities($user->Email) ?></a><? } ?></a></td>
                <td title="<?= $title ?>"><?= (!$lastAction ? "" : date("d M Y H:i:s", Utils::GetTimestamp($lastAction))) ?></td>
                <td title="<?= $title ?>"><?= ($user->Enabled ? "YES" : "NO") ?></td>
            </tr>

        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>
    
    <p>
        &LeftArrow; <a href="?">Back to Players</a>
    </p>
    
    <? if ($user->IsOnline()) { ?><p style="font-size: 1.1em;"><strong style="color: #009900;">THIS USER IS ONLINE</strong></p><? } ?>
    
    <?= printAlertError($error) ?>

    <fieldset id="player-info">
        <legend>Player Info</legend>
        
        <div id="tabs-player">
            <ul>
                <li><a href="#tab-account">Profile Data</a></li>
                <? if ($user->Id > 0) { ?>
                <li><a href="#tab-custom">Custom Data</a></li>
                <li><a href="#tab-files">Player Files</a></li>
                <li><a href="#tab-leaderboards">Leaderboards</a></li>
                <li><a href="#tab-achievements">Achievements</a></li>
                <? } ?>
            </ul>

            <div id="tab-account">
                <form method="post">
                    <input type="hidden" name="action" value="save"/>
                <? if ($user->Id > 0) { ?>
                    <?
                    $lastAction = $user->GetLastActionDate();
                    ?>
                    <div class="field"><label>Id</label> <b><?= $user->Id ?></b></div>
                    <div class="field"><label>Last action</label> <b><?= (!$lastAction ? "-" : date("d M Y H:i:s", Utils::GetTimestamp($lastAction))) ?></b></div>
                <? } ?>
                    <div class="field"><label>Enabled</label><select name="Enabled"><option value="0" <? if (!$user->Enabled) echo 'selected'; ?>>NO</option><option value="1" <? if ($user->Enabled) echo 'selected'; ?>>YES</option></select></div>
                    <div class="field"><label>Username (current: <?= htmlentities($currentUsername, ENT_QUOTES, 'UTF-8') ?>)</label><input type="text" name="Username" value="<?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?>"/></div>
                    <div class="field"><label>Email</label><input type="text" name="Email" value="<?= htmlentities($user->Email, ENT_QUOTES, 'UTF-8') ?>"/></div>
                    <div class="field"><label>Activation Code</label><input type="text" name="ActivationCode" value="<?= htmlentities($user->ActivationCode, ENT_QUOTES, 'UTF-8') ?>"/></div>
                <? if ($user->Id > 0) { ?>
                    <h3>Change Password</h3>
                    <div class="field"><label>New Password</label><input type="password" name="NewPassword" value=""/></div>
                    <div class="field"><label>Confirm Password</label><input type="password" name="ConfirmPassword" value=""/></div>
                    <div class="field"><label>&nbsp;</label>
                    <div class="field"><label>Friends</label><?= DataClass::CountRecords(CB_Friend::TABLE_NAME, "IdAccount = " . $user->Id) ?></div>
                <? } else { ?>
                    <div class="field"><label>Password</label><input type="password" name="Password" value=""/></div>
                    <div class="field"><label>Confirm Password</label><input type="password" name="ConfirmPassword" value=""/></div>
                <? } ?>
                    <input type="submit" class="button" value="Save"/> or <a href="?">Cancel</a>
                    </div>
                </form>
            </div>

            <? if ($user->Id > 0) { ?>
            <div id="tab-custom">
                <h4>Register a new Custom Data</h4>
                <p>
                    <form method="post">
                        <input type="hidden" name="action" value="save_custom"/>
                        <div class="field">
                            <input type="text" required="required" name="custom_key" value="New Key"/>
                            <input type="text" name="custom_value"/>
                            <br/><input type="submit" class="button" value="Add"/>
                        </div>
                    </form>
                </p>
                <h4>Registered Custom Data</h4>
                <p>
                <? if (count($customData) == 0) { ?>
                    No Custom Data.
                <? } else { ?>
                    <?
                    $iCustom = 0;
                    foreach ($customData as $data) {
                        $iCustom++;
                        ?>
                    <form method="post" id="frm-custom<?= $iCustom ?>" class="customdata">
                        <input type="hidden" name="action" value="save_custom"/>
                        <input type="hidden" name="custom_key" value="<?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?>"/>
                        <div class="field">
                            <label><?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?></label>
                            <input type="text" name="custom_value" value="<?= htmlentities($data->DataValue, ENT_QUOTES, 'UTF-8') ?>"/>
                            <input type="submit" class="button" value="Save"/>
                            <input type="button" class="button delete-custom" value="Delete" data-form="frm-custom<?= $iCustom ?>"/>
                        </div>
                    </form>
                    <? } ?>
                <? } ?>
                </p>
            </div>

            <div id="tab-files">
                <? if (count($files) == 0) { ?>
                    No Files.
                <? } else { ?>
                    <? foreach ($files as $file) { ?>
                    <form method="post" onsubmit="return confirm('Delete this File?')" class="userfile">
                        <input type="hidden" name="action" value="delete_file"/>
                        <input type="hidden" name="file" value="<?= $file->Id ?>"/>
                        <input type="submit" class="button" value="Delete"/>
                        <a href="<?= URL_ROOT . URL_UPLOAD . $file->Url ?>" target="_blank" class="button"><?= $file->Url ?></a>
                    </form>
                    <? } ?>
                <? } ?>
            </div>

            <div id="tab-leaderboards">
                <? foreach ($leaderboards as $leaderboard) { ?>
                <p>
                    <h4><?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></h4>
                    <?
                    $arrayScores = array(
                        array( "title" => "Today", "data" => $leaderboardsScores[$leaderboard->Id]["today"] ),
                        array( "title" => "Last Week", "data" => $leaderboardsScores[$leaderboard->Id]["week"] ),
                        array( "title" => "Last Month", "data" => $leaderboardsScores[$leaderboard->Id]["month"] ),
                        array( "title" => "All Time", "data" => $leaderboardsScores[$leaderboard->Id]["total"] )
                    );
                    ?>
                    <table class="table-records" width="100%">
                        <thead>
                            <tr>
                                <th align="left">Interval</th>
                                <th width="100" align="right">Rank <img src="images/mapmarker.png" alt="Rank" title="Rank" /></th>
                                <th width="150" align="right">Score <img src="images/flag_azure.png" alt="Score" title="Score" /></th>
                            </tr>
                        </thead>
                        <tbody>
                        <? foreach ($arrayScores as $value) { ?>
                            <tr>
                                <td><?= $value["title"] ?></td>
                                <td align="right"><?= $value["data"]["rank"] ?></td>
                                <td align="right"><?= $value["data"]["score"] ?></td>
                            </tr>
                        <? } ?>
                        </tbody>
                    </table>
                </p>
                <p>&nbsp;</p>
                <? } ?>
            </div>

            <div id="tab-achievements">
                <table class="table-records" width="100%">
                    <thead>
                        <tr>
                            <th width="150" align="right">Progress <img src="images/ribbon.png" alt="Progress" title="Progress" /></th>
                            <th align="left">Achievement</th>
                        </tr>
                    </thead>
                    <tbody>
                <? foreach ($achievements as $achievement) { ?>
                        <tr>
                            <td align="right"><?= $achievement["Progress"] ?>&percnt; <?= ($achievement["Finished"] > 1 ? " (x" . $achievement["Finished"] . ")" : "") ?></td>
                            <td><?= htmlentities($achievement["Title"], ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                <? } ?>
                    </tbody>
                </table>
            </div>
            <? } ?>

        </div>
        
    </fieldset>

    <div id="dlg-custom-new" title="Add a new Custom Data">
        <p>
            <form>
                <input type="hidden" name="action" value="custom_data" />
            </form>
        </p>
    </div>

    <script>
        $(function() {
            $("#tabs-player").tabs();
            $(".delete-custom").click(function(event) {
                if (confirm("Delete this Custom Data?")) {
                    toggleBusy(true);
                    var myForm = $("#" + $(this).attr("data-form"));
                    myForm.find("input[name='action']").val("delete_custom");
                    myForm.submit();
                }
            });
            $("#tabs-player form").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

<? } ?>

<? include './footer.php'; ?>