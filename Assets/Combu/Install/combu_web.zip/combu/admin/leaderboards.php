<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$leaderboard = (!isset($_REQUEST["Id"]) ? NULL : new CB_LeaderBoard(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($leaderboard) {
                Utils::FillObjectFromRow($leaderboard, $_REQUEST, TRUE);
                if (!$leaderboard->Title)
                    $error = "Enter the Title";
                else {
                    if ($leaderboard->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($leaderboard) {
                $leaderboard->Delete();
                // Return to list
                Utils::RedirectTo("?deleted=1");
            }
            break;

    // Action Delete Score
        case "delete_score":
            if ($leaderboard) {
                $score = new CB_LeaderBoard_User(!isset($_REQUEST["IdScore"]) ? 0 : intval($_REQUEST["IdScore"]));
                $score->Delete();
                Utils::RedirectTo("?action=scores&Id=" . $leaderboard->Id . "&saved=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$leaderboard) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $leaderboards = CB_LeaderBoard::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$leaderboard) { ?>

    <fieldset id="list">
        <legend>Leaderboards</legend>
        
        <div align="right">
            <button class="button" onclick="document.location.href='?Id=0'">Create Leaderboard</button>
        </div>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="200"></th>
                    <th width="100" align="right">Id</th>
                    <th align="left">Title</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
        
        <? foreach ($leaderboards as $leaderboard) { ?>

            <tr>
                <td nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this Leaderboard?')) document.location.href='?action=delete&Id=<?= $leaderboard->Id ?>';">Delete</button>
                    <button class="button" onclick="document.location.href='?action=scores&Id=<?= $leaderboard->Id ?>';">Scores</button>
                </td>
                <td align="right"><a href="?Id=<?= $leaderboard->Id ?>"><?= $leaderboard->Id ?></a></td>
                <td><?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>

    <? if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "scores") { ?>

    &LeftArrow; <a href="?">Back to Leaderboards</a>

    <fieldset id="list">
        <legend>High Scores from: <?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></legend>
        <?
        $limit = DEFAULT_LIST_LIMIT;
        $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
        $count = 0;
        $order = "";
        $field = "";
        $leaderboard->GetOrderBy($order, $field);
        //$scores = CB_LeaderBoard_User::Load($leaderboard->Id, $order, $limit, Utils::GetPageOffset($page, $limit), $count);
        $scores = $leaderboard->LoadHighscore(CB_LEADERBOARD_HIGHSCORE_TOTAL, FALSE, FALSE, $limit, Utils::GetPageOffset($page, $limit), $count);
        $pagesCount = Utils::GetPagesCount($count, $limit);
        ?>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th width="100" align="right">Rank <img src="images/mapmarker.png" alt="Rank" title="Rank" /></th>
                    <th align="left">Player</th>
                    <th width="150" align="right">Score <img src="images/flag_azure.png" alt="Score" title="Score" /></th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>

        <? foreach ($scores as $score) { ?>
        
        <? $user = json_decode($score["User"]); ?>
            <tr>
                <td nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this Score?')) document.location.href='?action=delete_score&Id=<?= $leaderboard->Id ?>&IdScore=<?= $score["Id"] ?>';">Delete</button>
                </td>
                <td align="right"><?= $score["Rank"] ?></td>
                <td><a href="users.php?Id=<?= $user->Id ?>"><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></a></td>
                <td align="right"><?= $score["Score"] ?></td>
            </tr>
        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="action" value="scores"/>
                                <input type="hidden" name="Id" value="<?= $leaderboard->Id ?>"/>
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>
        
    </fieldset>

    <? } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Leadernoards</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Leaderboard Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <? if ($leaderboard->Id > 0) { ?><div class="field"><label>Id</label> <b><?= $leaderboard->Id ?></b></div><? } ?>
            <div class="field"><label>Title</label><input type="text" name="Title" value="<?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?>"/></div>
            <div class="field"><label>Description</label><textarea name="Description"><?= htmlentities($leaderboard->Description, ENT_QUOTES, 'UTF-8') ?></textarea></div>
            <div class="field">
                <label>Score Type</label>
            <? if ($leaderboard->Id > 0) { ?>
                <input type="hidden" name="UniqueRecords" value="<?= $leaderboard->UniqueRecords ?>"/>
                <strong><?= $LEADERBOARD_SCORETYPE[$leaderboard->UniqueRecords] ?></strong>
            <? } else { ?>
                <select name="UniqueRecords">
                    <option value="<?= CB_LEADERBOARD_UNIQUE_INCREASE ?>" <? if ($leaderboard->UniqueRecords == CB_LEADERBOARD_UNIQUE_INCREASE) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[CB_LEADERBOARD_UNIQUE_INCREASE] ?></option>
                    <option value="<?= CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER ?>" <? if ($leaderboard->UniqueRecords == CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[CB_LEADERBOARD_UNIQUE_REPLACE_HIGHER] ?></option>
                    <option value="<?= CB_LEADERBOARD_UNIQUE_REPLACE_ANY ?>" <? if ($leaderboard->UniqueRecords == CB_LEADERBOARD_UNIQUE_REPLACE_ANY) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[CB_LEADERBOARD_UNIQUE_REPLACE_ANY] ?></option>
                    <option value="<?= CB_LEADERBOARD_UNIQUE_NONE ?>" <? if ($leaderboard->UniqueRecords == CB_LEADERBOARD_UNIQUE_NONE) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[CB_LEADERBOARD_UNIQUE_NONE] ?></option>
                </select>
            <? } ?>
            </div>
            <div class="field">
                <label>Values Type</label>
            <? if ($leaderboard->Id > 0) { ?>
                <input type="hidden" name="ValueType" value="<?= $leaderboard->ValueType ?>"/>
                <strong><?
                switch ($leaderboard->ValueType) {
                case CB_LEADERBOARD_VALUE_INT:
                    echo 'Integer (e.g.: 100)';
                    break;
                case CB_LEADERBOARD_VALUE_FLOAT:
                    echo 'Float (e.g.: 0.001)';
                    break;
                }
                ?></strong>
            <? } else { ?>
                <select name="ValueType">
                    <option value="<?= CB_LEADERBOARD_VALUE_INT ?>" <? if ($leaderboard->ValueType == CB_LEADERBOARD_VALUE_INT) echo ' selected'; ?>>Integer (e.g.: 100)</option>
                    <option value="<?= CB_LEADERBOARD_VALUE_FLOAT ?>" <? if ($leaderboard->ValueType == CB_LEADERBOARD_VALUE_FLOAT) echo ' selected'; ?>>Float (e.g.: 0.001)</option>
                </select>
            <? } ?>
            </div>
            <div class="field">
                <label>Order Type</label>
                <select name="OrderType">
                    <option value="<?= CB_LEADERBOARD_ORDER_DESC ?>" <? if ($leaderboard->OrderType == CB_LEADERBOARD_ORDER_DESC) echo ' selected'; ?>>Descending (e.g.: from 10 to 1)</option>
                    <option value="<?= CB_LEADERBOARD_ORDER_ASC ?>" <? if ($leaderboard->OrderType == CB_LEADERBOARD_ORDER_ASC) echo ' selected'; ?>>Ascending (e.g.: from 1 to 10)</option>
                </select>
            </div>
            <div class="field">
                <label>Allow anonymous</label>
                <select name="AllowAnonymous">
                    <option value="0" <? if ($leaderboard->AllowAnonymous == 0) echo ' selected'; ?>>No</option>
                    <option value="1" <? if ($leaderboard->AllowAnonymous == 1) echo ' selected'; ?>>Yes</option>
                </select>
                * Anonymous players always add new scores
            </div>
            <div class="field"><label>&nbsp;</label>
            <input type="submit" class="button" value="Save"/> or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

    <? } ?>

<? } ?>

<? include './footer.php'; ?>