<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            $record = new CB_ServerSettings($_REQUEST, TRUE);
            if (!$record->DataKey) {
                $error = "Enter the Key";
            } else if (isset ($_REQUEST["create"]) && array_key_exists($record->DataKey, $ServerSettings)) {
                $error = "This Key is already registered";
            } else {
                if ($record->Save()) {
                    // Return to list
                    Utils::RedirectTo("?saved=1");
                } else
                    $error = "An error occurred";
            }
            break;

    // Action Delete
        case "delete":
            $record = new CB_ServerSettings($_REQUEST, TRUE);
            if ($record->Delete()) {
                // Return to list
                Utils::RedirectTo("?deleted=1");
            } else {
                Utils::RedirectTo("?");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$records = CB_ServerSettings::Load();

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>
<?= printAlertError($error) ?>

<fieldset id="list">
    <legend>News</legend>

    <div>
        <h4>Create a new Key</h4>
        <p>
            <form id="formNewKey">
                <input type="hidden" name="action" value="save" />
                <input type="hidden" name="create" />
                <div class="field">
                    <label>Key</label>
                    <input type="text" name="DataKey" value="<?= (!isset($_REQUEST["DataKey"]) ? "" : htmlentities($_REQUEST["DataKey"], ENT_QUOTES, 'UTF-8')) ?>"/>
                </div>
                <div class="field">
                    <label>Value</label>
                    <input type="text" name="DataValue" value="<?= (!isset($_REQUEST["DataValue"]) ? "" : htmlentities($_REQUEST["DataValue"], ENT_QUOTES, 'UTF-8')) ?>"/>
                </div>
                <div class="field">
                    <label>&nbsp;</label>
                    <input type="submit" class="button" value="Create"/>
                </div>
            </form>
        </p>
    </div>

    <table class="table-records" width="100%">
        <thead>
            <tr>
                <th width="200"></th>
                <th width="200" align="left">Key</th>
                <th align="left">Value</th>
            </tr>
        </thead>
        <tbody>
    <? if (count($records) == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>

        <? $i = 0; ?>
    <? foreach ($records as $record) { ?>
        
        <tr>
            <td nowrap>
                <button class="button ui-state-error bt-delete-key" data-id="<?= $i ?>">Delete</button>
                <button class="button bt-save-key" data-id="<?= $i ?>">Save</button>
            </td>
            <td><?= htmlentities($record->DataKey, ENT_QUOTES, 'UTF-8') ?></td>
            <td><form id="form-edit-<?= $i ?>" method="post">
            <input type="hidden" name="action" value="save"/>
            <input type="hidden" name="DataKey" value="<?= urlencode($record->DataKey) ?>"/>
            <input type="text" name="DataValue" value="<?= htmlentities($record->DataValue, ENT_QUOTES, 'UTF-8') ?>"/>
            </form></td>
        </tr>
        <? $i++; ?>

    <? } ?>

        </tbody>
    </table>

</fieldset>

<script>
    $(function() {
        /*var dlgNewKey = $("#dlg-key-new").dialog()
        $("#bt-create-key")*/
        $("#formNewKey").submit(function() {
            if ($(this).find("input[name='DataKey']").val() == "") {
                event.preventDefault();
                alert("Enter the Key");
            }
        });
        $("button.bt-save-key").click(function() {
            event.preventDefault();
            toggleBusy(true);
            var myForm = $("#form-edit-" + $(this).attr("data-id"));
            myForm.submit();
        });
        $("button.bt-delete-key").click(function() {
            event.preventDefault();
            if (confirm('Delete this Key?')) {
                toggleBusy(true);
                var myForm = $("#form-edit-" + $(this).attr("data-id"));
                myForm.find("input[name='action']").val("delete");
                myForm.submit();
            }
        });
    });
</script>

<? include './footer.php'; ?>