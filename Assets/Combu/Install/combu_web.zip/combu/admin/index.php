<?

include_once './common.php';

if (isset($_REQUEST["logout"]) && $_REQUEST["logout"] === "1") {
    CB_AdminAccount::Logout();
    Utils::RedirectTo();
}

$error = "";

if ($AdminLogged->IsLogged()) {
    
    $usersOnlineTicks = time() - ONLINE_SECONDS;
    
    // Get some stats to display
    $admins = DataClass::CountRecords(CB_AdminAccount::TABLE_NAME);
    $users = DataClass::CountRecords(CB_Account::TABLE_NAME);
    $users_online = DataClass::CountRecords(CB_Session::TABLE_NAME, sprintf("LastActionDate >= '%s' GROUP BY IdAccount", date("Y-m-d H:i:s", $usersOnlineTicks)));
    $leaderboards = DataClass::CountRecords(CB_LeaderBoard::TABLE_NAME);
    $scores = DataClass::CountRecords(CB_LeaderBoard_User::TABLE_NAME);
    $achievements = DataClass::CountRecords(CB_Achievement::TABLE_NAME);
    $news = DataClass::CountRecords(CB_News::TABLE_NAME);
    $newsletters = DataClass::CountRecords(CB_Newsletter::TABLE_NAME);
    
} else {
    
    // Create a default account if the Admin Account table is empty
    if (CB_AdminAccount::CountRecords(CB_AdminAccount::TABLE_NAME) == 0) {
        $AdminLogged = new CB_AdminAccount();
        $AdminLogged->Username = "admin";
        $AdminLogged->Password = md5("admin");
        if ($AdminLogged->Save()) {
            CB_AdminAccount::SetSession($AdminLogged);
            Utils::RedirectTo();
        }
        else
            $error = "Error creating the default admin account (" . htmlentities (mysql_error(), ENT_QUOTES) . ")";
    }
    
    // Login action requested
    if (!$error && isset($_REQUEST["action"]) && $_REQUEST["action"] == "login") {
        $username = (!isset($_REQUEST["Username"]) ? NULL : trim(stripslashes($_REQUEST["Username"])));
        $password = (!isset($_REQUEST["Password"]) ? NULL : trim(stripslashes($_REQUEST["Password"])));
        if ($username && $password) {
            $account = NULL;
            if (CB_AdminAccount::CheckLogin($username, $password, $account)) {
                CB_AdminAccount::SetSession($account);
                Utils::RedirectTo();
            } else {
                $error = "Username and/or Password invalid";
            }
        }
    }
}

?>
<? include './header.php'; ?>

<? if (!$AdminLogged->IsLogged()) { ?>

    <fieldset id="login">
        <legend>Enter your credentials</legend>
        <? if ($error) { ?><div class="error"><?= $error ?></div><? } ?>
        <form method="post">
            <input type="hidden" name="action" value="login" />
            <div class="field"><label>Username</label><input type="text" name="Username" /></div>
            <div class="field"><label>Password</label><input type="password" name="Password" /></div>
            <div align="center"><input type="submit" class="button" value="Login" /></div>
        </form>
    </fieldset>
<script>
    $(function() {
        $("#login input[name='Username']").focus();
    });
</script>
    
<? } else { ?>
    
    <fieldset id="stats">
        <legend>Statistics</legend>
        <table class="table-records" width="100%">
            <tbody>
                <tr>
                    <td>Admins</td>
                    <td align="right"><?= $admins ?></td>
                </tr>
                <tr>
                    <td>Users</td>
                    <td align="right"><?= $users ?> (<?= $users_online ?> online)</td>
                </tr>
                <tr>
                    <td>Leaderboards</td>
                    <td align="right"><?= $leaderboards ?></td>
                </tr>
                <tr>
                    <td>Scores</td>
                    <td align="right"><?= $scores ?></td>
                </tr>
                <tr>
                    <td>Achievements</td>
                    <td align="right"><?= $achievements ?></td>
                </tr>
                <tr>
                    <td>News</td>
                    <td align="right"><?= $news ?></td>
                </tr>
                <tr>
                    <td>Newsletters</td>
                    <td align="right"><?= $newsletters ?></td>
                </tr>
            </tbody>
        </table>
    </fieldset>
    
<? } ?>

<? include './footer.php'; ?>