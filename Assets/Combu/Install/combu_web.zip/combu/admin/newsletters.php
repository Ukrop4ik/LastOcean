<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

// Disable the execution time limit to allow sending large amount of mails
set_time_limit(0);

$newsletter = (!isset($_REQUEST["Id"]) ? NULL : new CB_Newsletter(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($newsletter) {
                Utils::FillObjectFromRow($newsletter, $_REQUEST, TRUE);
                if (!$newsletter->Subject)
                    $error = "Enter the Subject";
                else if (!$newsletter->Body)
                    $error = "Enter the Body";
                else {
                    if ($newsletter->Id < 1)
                        $newsletter->IdAccount = $AdminLogged->Id;
                    if ($newsletter->Save()) {
                        
                        // Send newsletter to test address
                        $testsent = NULL;
                        if (isset($_REQUEST["testsend"]) && $_REQUEST["testsend"] == "Send") {
                            $email = (isset($_REQUEST["testemail"]) ? trim(stripslashes($_REQUEST["testemail"])) : "");
                            if ($email) {
                                $testsent = "0";
                                $mail = new Mail();
                                $mail->prepare($newsletter->Subject, $newsletter->Body, $email, NEWSLETTER_SENDER_ADDRESS, NEWSLETTER_SENDER_NAME);
                                if ($mail->Send())
                                    $testsent = "1";
                            }
                        }
                        
                        // Return to list
                        Utils::RedirectTo("?saved=1" . ($testsent !== NULL ? "&Id=" . $newsletter->Id . "&testsent=" . $testsent : ""));
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($newsletter) {
                $newsletter->Delete();
            }
            // Return to list
            Utils::RedirectTo("?deleted=1");
            break;

    // Action Delete Score
        case "send":
            if ($newsletter) {
                $success = $newsletter->Send();
                Utils::RedirectTo("?sent=" . ($success ? "1" : "0") . "&sentId=" . $newsletter->Id);
            } else {
                // Return to list
                Utils::RedirectTo("?saved=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");
$testsent = (!$error) && (filter_input(INPUT_GET, "testsent") === "1");

// Display list if there is no active record
if (!$newsletter) {
    $sentNewsletter = (isset($_REQUEST["sentId"]) ? new CB_Newsletter(intval($_REQUEST["sentId"])) : NULL);
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $newsletters = CB_Newsletter::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<? if ($saved && isset($_REQUEST["testsent"])) { ?><?= printAlertDisappear($testsent ? "The newsletter has been sent to the test address." : "An error occurred sending the newsletter to the test address.") ?><? } ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$newsletter) { ?>

    <fieldset id="list">
        <legend>Newsletters</legend>
        
        <? if ($sentNewsletter) { ?>
            <? if (intval($_REQUEST["sent"]) == 1) { ?>
            <div style="color:green;">The newsletter was sent</div>
            <? } else { ?>
            <div style="color:red;">The newsletter failed</div>
            <? } ?>
        <? } ?>
        
        <div align="right">
            <button class="button" onclick="document.location.href='?Id=0'">Create Newsletter</button>
        </div>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="200"></th>
                    <th width="100" align="right">Id</th>
                    <th align="left">Subject</th>
                    <th width="250" align="right">Info</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>
        <?
        $i = 0;
        $max = count($newsletters);
        ?>
        <? foreach ($newsletters as $newsletter) { ?>
            <?
            $i++;
            $log = json_decode($newsletter->LogMessage, TRUE);
            $account = new CB_AdminAccount($newsletter->IdAccount);
            ?>
            
            <tr>
                <td nowrap>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this Newsletter?')) document.location.href='?action=delete&Id=<?= $newsletter->Id ?>';">Delete</button>
                    <? if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?><button class="button" onclick="if (confirm('Send this Newsletter?')) document.location.href='?action=send&Id=<?= $newsletter->Id ?>';">Send</button><? } ?>
                    <? if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?><button class="button" onclick="document.location.href='?action=logs&Id=<?= $newsletter->Id ?>';">Log</button><? } ?>
                </td>
                <td align="right"><a href="?Id=<?= $newsletter->Id ?>"><?= $newsletter->Id ?></a></td>
                <td><?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></td>
                <td align="right">
                    Created at <strong><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($newsletter->DateCreation)) ?></strong>
                    <? if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?><br/>Sent: <?= $log["sent"] ?> | Skipped: <?= $log["skipped"] ?> | Errors: <?= $log["errors"] ?><? } ?>
                </td>
            </tr>
            
        <? } ?>
        
            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>

    <? if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "logs") { ?>

    &LeftArrow; <a href="?">Back to Newsletters</a>
    
    <fieldset id="list">
        <legend>Mail log from: <?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></legend>
        <?
        $limit = DEFAULT_LIST_LIMIT;
        $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
        $count = 0;
        $order = "";
        $field = "";
        $logs = CB_NewsletterLog::Load($newsletter->Id, $limit, Utils::GetPageOffset($page, $limit), $count);
        $pagesCount = Utils::GetPagesCount($count, $limit);
        ?>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="200" align="left">Player</th>
                    <th width="200" align="left">Email</th>
                    <th width="80" align="left">Status</th>
                    <th align="right">Info</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>

        <? foreach ($logs as $log) { ?>
        
        <? $user = new CB_Account($log->IdAccount); ?>
                <tr>
                    <td><?= ($user->Username ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : '<span style="color:#999;">(invalid account)</span>') ?></td>
                    <td><?= htmlentities($user->Email, ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= ($log->Sent ? '<span style="color:green;">SENT</span>' : '<span style="color:red;">ERROR</span>') ?></td>
                    <td><?= $log->DateCreation . " " . htmlentities($log->Message, ENT_QUOTES, 'UTF-8') ?></td>
                </tr>

        <? } ?>
        
            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="action" value="logs"/>
                                <input type="hidden" name="Id" value="<?= $newsletter->Id ?>"/>
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>
        
    </fieldset>

    <? } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Newsletters</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Newsletter Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <? if ($newsletter->Id > 0) { ?><div class="field"><label>Id</label> <b><?= $newsletter->Id ?></b></div><? } ?>
            <div class="field">
                <label>Is HTML</label>
            <? if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?>
                <strong><?= ($newsletter->IsHtml == 1 ? "Yes" : "No") ?></strong>
            <? } else { ?>
                <select id="IsHtml" name="IsHtml">
                    <option value="1" <? if ($newsletter->IsHtml == 1) echo ' selected'; ?>>Yes</option>
                    <option value="0" <? if ($newsletter->IsHtml == 0) echo ' selected'; ?>>No</option>
                </select>
            <? } ?>
            </div>
            <div class="field"><label>Subject</label><? if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?> <strong><?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></strong><? } else { ?><input type="text" name="Subject" value="<?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?>"/><? } ?></div>
            <div class="field"><label>Body</label><br clear="all"/><? if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?> <?= ($newsletter->IsHtml ? $newsletter->Body : htmlentities($newsletter->Body, ENT_QUOTES, 'UTF-8')) ?><? } else { ?><textarea id="Body" name="Body"><?= htmlentities($newsletter->Body, ENT_QUOTES, 'UTF-8') ?></textarea><? } ?></div>
            <div class="field"><label>&nbsp;</label>
            <? if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?><input type="submit" class="button" value="Save"/> or <? } ?><a href="?">Cancel</a>
            </div>
            <? if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?>
            <p>
                <label>Save and send to test address</label>
                <input type="text" name="testemail"/>
                <input type="submit" class="button" name="testsend" value="Send"/>
            </p>
            <? } ?>
        </form>

    </fieldset>
    
    <script type="text/javascript">
        $(function () {
            tinymce.init({
                selector:'textarea', menubar : false, width: '100%', height: 150, plugins: "textcolor link image autoresize",
                toolbar: [ "undo redo | styleselect | fontsizeselect | forecolor backcolor | bold italic | link image | alignleft aligncenter alignright | bullist numlist outdent indent" ]
            });
            var fieldBody = $("#formEdit textarea[name=Body]");
            $("#formEdit select[name=IsHtml]").change(function() {
                if ($(this).val() == "1") {
                    var bodyText = "<p>" + fieldBody.val() + "</p>";
                    bodyText = bodyText.replace(/\n\n/g, "</p><p>");
                    bodyText = bodyText.replace(/\n/g, "<br>");
                    fieldBody.val(bodyText);
                    tinymce.activeEditor.show();
                } else {
                    tinymce.activeEditor.hide();
                    fieldBody.val(tinymce.activeEditor.getContent({format : 'text'}));
                }
            });
            
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

    <? } ?>

<? } ?>

<? include './footer.php'; ?>