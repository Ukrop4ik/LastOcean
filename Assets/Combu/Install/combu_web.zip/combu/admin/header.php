<!DOCTYPE html>
<html>
    <head>
        <title>Combu - Admin Console</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="ROBOTS" content="NOINDEX, NOFOLLOW"/>
        <link href="https://code.jquery.com/ui/1.11.4/themes/start/jquery-ui.css" rel="stylesheet"/>
        <link href="css/default.css" rel="stylesheet"/>
        <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
        <script src="https://tinymce.cachefly.net/4.1/tinymce.min.js"></script>
        <script src="js/functions.js"></script>
        <script type="text/javascript">
            var dialogLoading = null;
            $(function () {
                dialogLoading = $("#dlg-loading").dialog({
                    modal: true,
                    resizable: false,
                    autoOpen: false
                });
                $(".ui-dialog[aria-describedby='dlg-loading'] .ui-dialog-titlebar-close").remove();
                $(".button").button();
                $(".navpages form select[name=Page]").change(function() { $(".navpages form").submit(); });
                
                var disappearTexts = $(".disappear-text");
                $.each(disappearTexts, function(index, value) {
                    var disappearTime = $(value).attr("data-time");
                    if ($.isNumeric(disappearTime)) {
                        $(value).delay(parseInt(disappearTime) * 1000).fadeOut(500);
                    }
                });
                
                $(document).on('keyup', '.numeric-only', function(event) {
                    var v = this.value;
                    if($.isNumeric(v) === false) {
                        //chop off the last char entered
                        this.value = this.value.slice(0,-1);
                    }
                });
            });
        </script>
    </head>
    <body>
        
        <div id="container">
            <h1 id="logo">
                <a href="index.php"><img src="images/combu.png" id="logo-img"/></a> Server Administration
                <div class="content">
                    <a href="http://skaredcreations.com/api/combu/pages.html" target="_blank"><img src="images/bubble_doc.png"/> Read the documentation</a>
                    <a href="http://skaredcreations.com/wp/support/forum/combu-1/" target="_blank"><img src="images/bubble_forum.png"/> Get support on forum</a>
                    <br/><span style="color:#999;">Version <?= COMBU_VERSION ?></span>
                </div>
            </h1>
            <? if ($AdminLogged->IsLogged()) { ?>
            <div id="menu">
                <div class="menu-section">
                    <div class="menu-section-title">Administration</div>
                    <div class="menu-section-link"><a href="index.php">Home</a></div>
                    <div class="menu-section-link"><a href="serversettings.php">Settings</a></div>
                    <div class="menu-section-link"><a href="admins.php">Admins</a></div>
                    <div class="menu-section-link"><a href="users.php">Players</a></div>
                    <div class="menu-section-link"><a href="leaderboards.php">Leaderboards</a></div>
                    <div class="menu-section-link"><a href="achievements.php">Achievements</a></div>
                    <div class="menu-section-link"><a href="news.php">News</a></div>
                    <div class="menu-section-link"><a href="newsletters.php">Newsletters</a></div>
                    <div class="menu-section-link"><a href="index.php?logout=1">Logout</a></div>
                </div>
                <? foreach ($Addons as $addon) { ?>
                    <?
                    // Skip addons that haven't admin menu
                    if (count($addon->GetAdminMenu()) == 0)
                        continue;
                    ?>
                <div class="menu-section">
                    <div class="menu-section-title"><?= htmlentities($addon->Name) ?></div>
                    <? $i = 0; ?>
                    <? foreach ($addon->GetAdminMenu() as $addonMenuItem) { ?>
                    <div class="menu-section-link" data-addon-menu="<?= $i ?>"><a href="<?= $addon->GetMenuLink($i) ?>"><?= htmlentities($addonMenuItem["Display"]) ?></a></div>
                    <? $i++; ?>
                    <? } ?>
                </div>
                <? } ?>
            </div>
            <? } ?>
            <div id="content">
