<?

include_once './common.php';

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$user = (!isset($_REQUEST["Id"]) ? NULL : new CB_AdminAccount(intval($_REQUEST["Id"])));
$currentUsername = ($user ? $user->Username : "");
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($user) {
                Utils::FillObjectFromRow($user, $_REQUEST, TRUE);
                if (!$user->Username)
                    $error = "Enter the Username";
                else if ($user->ExistsUsername())
                    $error = "This Username is already used";
                else {
                    $newpass = NULL;
                    // Set the password to the appropriate REQUEST param
                    if ($user->Id > 0) {
                        // We are modifying an existing user, check for new password
                        if (isset($_REQUEST["newpass"]))
                            $newpass = trim(stripslashes($_REQUEST["newpass"]));
                    } else {
                        // We are adding a new user, the password is set from the REQUEST
                        $newpass = $user->Password;
                    }
                    // If a password has been specified, then apply it
                    if ($newpass) {
                        $user->Password = md5($newpass);
                    }
                    // Save the changes
                    if ($user->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($user) {
                // I cannot delete myself!
                if ($user->Id != $AdminLogged->Id) {
                    $user->Delete();
                }
                Utils::RedirectTo("?deleted=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$user) {
    $username = (!isset($_REQUEST["Username"]) ? NULL : trim(stripslashes($_REQUEST["Username"])));
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $users = CB_AdminAccount::Load($username, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<? include './header.php'; ?>

<?= printAlertDisappear(!$saved ? "" : "Data have been correctly saved.") ?>
<?= printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.") ?>

<? if (!$user) { ?>

    <fieldset id="list">
        <legend>Admins</legend>
        
        <div align="right">
            <button class="button" onclick="document.location.href='?Id=0'">Create Admin</button>
        </div>
        
        <form method="post">
            <div class="field">
                <label>Username</label>
                <input type="text" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
                <input type="submit" class="button" value="Search"/>
            </div>
        </form>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th width="100" align="right">Id</th>
                    <th align="left">Username</th>
                </tr>
            </thead>
            <tbody>
        <? if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
            
        <? foreach ($users as $user) { ?>

            <tr>
                <td nowrap>
                    <? if ($user->Id != $AdminLogged->Id) { ?>
                    <button class="button ui-state-error" onclick="if (confirm('Delete this User?')) document.location.href='?action=delete&Id=<?= $user->Id ?>';">Delete</button>
                    <? } ?>
                </td>
                <td align="right"><a href="?Id=<?= $user->Id ?>"><?= $user->Id ?></a></td>
                <td><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <? } ?>

            </tbody>
            <tfoot>
        <? if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <? for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <? if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <? } ?>
                                </select>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <? } ?>
            </tfoot>
        </table>

    </fieldset>
            
<? } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Admins</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Admin Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <? if ($user->Id > 0) { ?><div class="field"><label>Id</label> <b><?= $user->Id ?></b></div><? } ?>
            <div class="field"><label>Username</label><input type="text" name="Username" value="<?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?>"/> (<?= htmlentities($currentUsername, ENT_QUOTES, 'UTF-8') ?>)</div>
            <? if ($user->Id > 0) { ?>
            <div class="field"><label>New Password</label><input type="password" name="newpass" value=""/></div>
            <div class="field"><label>Confirm Password</label><input type="password" name="newpass_confirm" value=""/></div>
            <? } else { ?>
            <div class="field"><label>Password</label><input type="password" name="Password" value=""/></div>
            <? } ?>
            <div class="field"><label>&nbsp;</label>
            <input type="submit" class="button" value="Save"/> or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>

    <script type="text/javascript">
        $(function () {
            var myForm = $("#formEdit");
            myForm.submit(function() {
                if (!myForm.find("input[name=Username]").val().trim()) {
                    alert("Username cannot be empty");
                    return false;
                }
            <? if ($user->Id > 0) { ?>
                if (myForm.find("input[name=newpass]").val().trim() && myForm.find("input[name=newpass]").val().trim() != myForm.find("input[name=newpass_confirm]").val().trim()) {
                    alert("The Confirm Password is wrong");
                    return false;
                }
            <? } else { ?>
                if (!myForm.find("input[name=Password]").val().trim()) {
                    alert("Password cannot be empty");
                    return false;
                }
            <? } ?>
                toggleBusy(true);
            });
        });
    </script>

<? } ?>

<? include './footer.php'; ?>