<?

include_once "lib/api.php";

// Deny access to unsecured/non-signed requests (excluding specific methods)
if (!isset($_REQUEST["action"]) || !in_array($_REQUEST["action"], array("create", "exists", "create_guest")))
    checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // User login
    case "login":
        wsLogin();
        break;

    // User logout
    case "logout":
        wsLogout();
        break;

    // Create new user
    case "create":
        wsCreate();
        break;

    // Get a user
    case "load":
        wsLoad();
        break;

    // Update user
    case "update":
        wsUpdate();
        break;

    // Check if user exists
    case "exists":
        wsUserExists();
        break;

    // Delete user
    case "delete":
        wsDelete();
        break;

    // Reset the password of a user
    case "reset_pwd":
        wsResetPassword();
        break;

    // Change the password of the logged user
    case "change_pwd":
        wsChangePassword();
        break;

    // Load a list of random users
    case "random":
        wsRandomList();
        break;

    // Create new guest user with random Username
    case "create_guest":
        wsCreateGuest();
        break;
    
    case "login_session":
        wsLoginSession();
        break;
    
    // Search users
    case "search":
        wsSearch();
        break;

    // User login with External Platform (Facebook, Game Center, Play Services etc.)
    case "login_platform":
        wsLoginPlatform();
        break;

    // Link the logged account to another (move the platform accounts to the new)
    case "link_account":
        wsLinkAccount();
        break;
    
    // Link a platform to the logged account
    case "link_platform":
        wsLinkPlatform();
        break;

    }
}
exit();

/**
 * Cleans the customData array coming from web requests by applying the filter of all addons
 * @param array $customData Associative key/value array of account custom data
 */
function cleanIncomingCustomData (&$customData) {
    $newCustomData = array();
    foreach ($customData as $key => $value) {
        if (!AddonModule::IsBlockedUpdateUserCustomData($key))
            $newCustomData[$key] = $value;
    }
    $customData = $newCustomData;
}

/**
 * Check the credentials to login an account
 * @global CB_Account $LoggedAccount
 */
function wsLogin() {
    global $LoggedAccount;
    $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
    $password = (isset($_REQUEST["Password"]) ? trim(stripslashes($_REQUEST["Password"])) : "");
    // If the player is logged, do logout
    if ($LoggedAccount->IsLogged())
        $LoggedAccount->Logout();
    // Verify the credentials
    $user = NULL;
    $success = CB_Account::CheckLogin($username, $password, $user);
    $message = "";
    if ($success) {
        if (!$user->Enabled) {
            $message = "Your account is disabled";
            $success = FALSE;
        } else if ($user->ActivationCode) {
            $message = "You must activate your account by following the link in the email";
            $success = FALSE;
        } else {
            $timestamp = (isset($_REQUEST["sig_time"]) ? stripslashes($_REQUEST["sig_time"]) : "");
            if ($success) {
                CB_Account::SetSession($user);
                $message = $LoggedAccount->ToJsonFiltered();
            }
        }
    } else {
        $message = "Credentials are invalid";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Check the account session to authorize auto-login
 * @global CB_Account $LoggedAccount
 */
function wsLoginSession() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $success = TRUE;
        $message = $LoggedAccount->ToJson();
    } else {
        $message = "Invalid session";
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

function wsLoginPlatform() {
    $platformKey = (isset($_REQUEST["PlatformKey"]) ? trim(stripslashes($_REQUEST["PlatformKey"])) : "");
    $platformId = (isset($_REQUEST["PlatformId"]) ? trim(stripslashes($_REQUEST["PlatformId"])) : "");
    $timestamp = (isset($_REQUEST["sig_time"]) ? stripslashes($_REQUEST["sig_time"]) : "");
    $success = FALSE;
    $message = "";
    $user = NULL;
    $justCreated = FALSE;
    // Verify the credentials
    if ($platformKey && $platformId) {
        $accountPlatform = NULL;
        $user = CB_Account_Platform::LoadAccount($platformKey, $platformId, $accountPlatform, $justCreated);
    } else {
        $message = "No Platform Key and/or Id provided";
    }
    if ($user != NULL) {
        if (!$user->Enabled) {
            $message = "Your account is disabled";
        } else {
            $success = TRUE;
            if (SECURITY_ENABLED && $timestamp) {
                $user->UpdateSignature($timestamp);
            }
            if ($user->ActivationCode) {
                $message = "You must activate your account by following the link in the email";
                $success = FALSE;
            } else {

                /*
                 * Sample code to add starting equipment on player registration
                 */
                /*
                if ($justCreated) {
                    $startItems = array(
                        array( "name" => "item1", "quantity" => 1 ),
                        array( "name" => "item2", "quantity" => 1 )
                    );
                    foreach ($startItems as $itemData) {
                        $newItem = new CB_Inventory();
                        $newItem->IdAccount = $user->Id;
                        $newItem->Name = $itemData["name"];
                        $newItem->Quantity = $itemData["quantity"];
                        $newItem->Save();
                    }
                }
                */

                CB_Account::SetSession($user);
                // Add the registered platforms for the logged user as result
                $userArray = $user->ToArrayFiltered();
                $message = json_encode($userArray);
            }
        }
    } else {
        $message = "Cannot get the account";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Link an account with a platform account
 * @global CB_Account $LoggedAccount
 */
function wsLinkAccount() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $user = NULL;
        $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
        $password = (isset($_REQUEST["Password"]) ? trim(stripslashes($_REQUEST["Password"])) : "");
        if (CB_Account::CheckLogin($username, $password, $user)) {
            // Move all my platforms, I lose all my data
            $platforms = CB_Account_Platform::Load($LoggedAccount->Id);
            $otherPlatforms = CB_Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $exists = FALSE;
                foreach ($otherPlatforms as $otherPlatform) {
                    if ($otherPlatform->PlatformKey == $platform->PlatformKey && strcasecmp($otherPlatform->PlatformId, $platform->PlatformId) == 0) {
                        $exists = TRUE;
                        break;
                    }
                }
                if (!$exists) {
                    $newPlatform = new CB_Account_Platform();
                    $newPlatform->IdAccount = $user->Id;
                    $newPlatform->PlatformKey = $platform->PlatformKey;
                    $newPlatform->PlatformId = $platform->PlatformId;
                    $newPlatform->Save();
                }
            }
            // Delete the current account
            $LoggedAccount->Delete();
            // Reset the session to the new account
            CB_Account::SetSession($user);
            // Return the account with all platforms
            $userArray = $user->ToArrayFiltered();
            $userArray["Platforms"] = array();
            $platforms = CB_Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $userArray["Platforms"][] = $platform->ToArray();
            }
            $message = json_encode($userArray);
            $success = TRUE;
        } else {
            $message = "Credentials are invalid";
        }
    } else {
        $message = "User not logged in";
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Link a platform to the logged account
 * @global CB_Account $LoggedAccount
 */
function wsLinkPlatform() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $platformKey = (isset($_REQUEST["PlatformKey"]) ? trim(stripslashes($_REQUEST["PlatformKey"])) : "");
        $platformId = (isset($_REQUEST["PlatformId"]) ? trim(stripslashes($_REQUEST["PlatformId"])) : "");
        if ($platformKey && $platformId) {
            $exists = FALSE;
            $platforms = CB_Account_Platform::Load($LoggedAccount->Id);
            foreach ($platforms as $platform) {
                if ($platformKey == $platform->PlatformKey && strcasecmp($platformId, $platform->PlatformId) == 0) {
                    $exists = TRUE;
                    break;
                }
            }
            if (!$exists) {
                $newPlatform = new CB_Account_Platform();
                $newPlatform->IdAccount = $LoggedAccount->Id;
                $newPlatform->PlatformKey = $platformKey;
                $newPlatform->PlatformId = $platformId;
                $newPlatform->Save();
            }
            $userArray = $LoggedAccount->ToArrayFiltered();
            $userArray["Platforms"] = array();
            $platforms = CB_Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $userArray["Platforms"][] = $platform->ToArray();
            }
            $message = json_encode($userArray);
            $success = TRUE;
        } else {
            $message = "Platform data are invalid";
        }
    } else {
        $message = "User not logged in";
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

/**
 * Logoff the current user
 * @global CB_Account $LoggedAccount
 */
function wsLogout() {
    global $LoggedAccount;
    $success = TRUE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        AddonModule::NotifyUserLogout($LoggedAccount);
        CB_Account::Logout();
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Create a new account
 */
function wsCreate() {
    global $Addons;
    // Fill a new object from the REQUEST parameters (must match with class public vars)
    $user = new CB_Account($_REQUEST, TRUE);
    $success = FALSE;
    if ($user->Id == 0 && $user->Username && $user->Password) {
        if ($user->ExistsUsername()) {
            $message = "This username has already been taken";
        } else {
            $proceed = TRUE;
            if (REGISTER_EMAIL_REQUIRED) {
                $proceed = FALSE;
                if (!($user->Email && Utils::IsValidEmail($user->Email)))
                    $message = "A valid email is required";
                else
                    $proceed = TRUE;
            }
            if ($proceed && $user->Email && !REGISTER_EMAIL_MULTIPLE && $user->ExistsEmail()) {
                $message = "Email already registered";
                $proceed = FALSE;
            }
            if ($proceed) {
                $user->Enabled = 1;
                // Set an activation code if required by settings
                if (REGISTER_EMAIL_REQUIRED && REGISTER_EMAIL_ACTIVATION) {
                    $user->ActivationCode = Utils::GenerateRandomPassword(10);
                }
                $success = $user->Save();
                if ($success) {
                    CB_Account::SetSession($user);
                    // Save custom data
                    $customData = "{}";
                    if (isset($_REQUEST["CustomData"]))
                    	$customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
                    $customData = json_decode($customData, TRUE);
                    cleanIncomingCustomData($customData);
                    foreach ($customData as $key => $value) {
                        $newData = new CB_CustomData();
                        $newData->IdAccount = $user->Id;
                        $newData->DataKey = $key;
                        $newData->DataValue = $value;
                        $newData->Save();
                    }
                    
                    /*
                     * Sample code to add starting equipment on player registration
                     */
                    /*
                    $startItems = array(
                        array( "name" => "item1", "quantity" => 1 ),
                        array( "name" => "item2", "quantity" => 1 )
                    );
                    foreach ($startItems as $itemData) {
                        $newItem = new CB_Inventory();
                        $newItem->IdAccount = $user->Id;
                        $newItem->Name = $itemData["name"];
                        $newItem->Quantity = $itemData["quantity"];
                        $newItem->Save();
                    }
                    */
                    
                    // Notify the addons
                    AddonModule::NotifyUserCreate($user);
                    
                    $message = $user->ToJsonFiltered();
                    
                    // Send the activation code to email
                    if ($user->ActivationCode) {
                        $mailMessage = @file_get_contents(REGISTER_EMAIL_MESSAGE);
                        if ($mailMessage) {
                            $urlActivation = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] ? "https" : "http") . "://" .
                                    $_SERVER["SERVER_NAME"] . ($_SERVER["SERVER_PORT"] != 80 ? ":" . $_SERVER["SERVER_PORT"] : "") .
                                    URL_ROOT . "activation.php?Id=" . $user->Id . "&Code=" . urlencode($user->ActivationCode);
                            $mailMessage = str_replace("{ACTIVATION_URL}", $urlActivation, $mailMessage);
                            $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                            $mail = new Mail();
                            $mail->prepare(REGISTER_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                            $mail->IsHTML(REGISTER_EMAIL_HTML);
                            $mail->Send();
                        }
                    }
                    
                } else {
                    $message = "An error occurred";
                }
            }
        }
    } else {
        $message = "Username/Password invalid";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Load one or more accounts
 */
function wsLoad() {
    $success = FALSE;
    $message = "";
    if (isset($_REQUEST["Ids"]) || isset($_REQUEST["Usernames"])) {
        $message = array();
        if (isset($_REQUEST["Ids"])) {
            $users = CB_Account::LoadIds(explode(",", trim(stripslashes($_REQUEST["Ids"]))));
        } else {
            $users = CB_Account::LoadUsernames(explode(",", trim(stripslashes($_REQUEST["Usernames"]))));
        }
        foreach ($users as $i) {
            $message[] = $i->ToArrayFiltered();
        }
        $success = TRUE;
        $message = json_encode($message);
    } else {
        $idUser = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
        $user = new CB_Account($idUser > 0 ? $idUser : $username);
        if ($user->Id > 0) {
            $success = TRUE;
            if ($success) {
                $message = $user->ToJsonFiltered();
            }
        } else {
            $message = "User does not exist";
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Update the data of the logged user
 */
function wsUpdate () {
    $success = FALSE;
    $message = "";
    $idUser = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
    $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
    $user = new CB_Account($idUser > 0 ? $idUser : $username);
    if ($user->Id > 0) {
        if (isset($_REQUEST["Username"]))
            $user->Username = stripslashes ($_REQUEST["Username"]);
        if (isset($_REQUEST["Email"]))
            $user->Email = stripslashes ($_REQUEST["Email"]);
        if (isset($_REQUEST["FacebookId"]))
            $user->FacebookId = stripslashes ($_REQUEST["FacebookId"]);
        if (isset($_REQUEST["GameCenterId"]))
            $user->GameCenterId = stripslashes ($_REQUEST["GameCenterId"]);
        if ($user->ExistsUsername()) {
            $message = "This username has already been taken";
        } else if ($user->Save()) {
            // Change custom data values
            $customData = "{}";
            if (isset($_REQUEST["CustomData"]))
                $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
            $customData = json_decode($customData, TRUE);
            cleanIncomingCustomData($customData);
            foreach ($customData as $key => $value) {
                $noData = FALSE;
                $newData = new CB_CustomData();
                $newData->IdAccount = $user->Id;
                $newData->DataKey = $key;
                $newData->DataValue = $value;
                $newData->Save();
            }

            // Notify the addons
            AddonModule::NotifyUserUpdate($user);
            
            // Assign the result
            $success = TRUE;
            $message = $user->ToJsonFiltered();
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Checks whether a user exists
 */
function wsUserExists() {
    $success = FALSE;
    $message = "";
    // Get the user data from request
    $user = new CB_Account();
    if (isset($_REQUEST["Username"]))
        $user->Username = stripslashes($_REQUEST["Username"]);
    if (isset($_REQUEST["Email"]))
        $user->Email = stripslashes($_REQUEST["Email"]);
    // Check data consistency
    if (!$user->Username && !$user->Email) {
        $message = "Username/Email invalid";
    } else {
        $success = TRUE;
        $message = FALSE;
        // Verify existing user
        if ($user->Username && $user->ExistsUsername())
            $message = TRUE;
        if ($user->Email && $user->ExistsEmail())
            $message = TRUE;
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Delete a user
 */
function wsDelete() {
    $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
    $password = (isset($_REQUEST["Password"]) ? trim(stripslashes($_REQUEST["Password"])) : "");
    $user = NULL;
    // Verify the credentials
    $success = FALSE;
    $message = "";
    if (CB_Account::CheckLogin($username, $password, $user)) {
        // Delete this user
        if ($user->Delete()) {
            $success = TRUE;

            // Notify the addons
            AddonModule::NotifyUserDelete($user);
        }
    } else {
        $message = "Username or Password invalid";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Reset the password of a user
 * @global CB_Account $LoggedAccount
 */
function wsResetPassword() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    // If the user isn't logged in, then check for Change Password Code passed
    if ($LoggedAccount->IsLogged()) {
        $message = "User is already logged in";
    } else {
        $id = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        $username = ($id <= 0 && isset($_REQUEST["Username"]) ? stripslashes($_REQUEST["Username"]) : "" );
        $user = new CB_Account($id > 0 ? $id : $username);
        if ($user->Id < 1) {
            $message = "User does not exist";
        } else if (!$user->Email) {
            $message = "User has no email address";
        } else {
            $code = "";
            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            while (strlen($code) < 5) {
                $code .= substr($chars, rand(0, strlen($chars) - 1), 1);
            }
            $user->ChangePwdCode = $code;
            if ($user->Save()) {
                $success = TRUE;
                $mailMessage = @file_get_contents(RESETPWD_EMAIL_MESSAGE);
                if ($mailMessage) {
                    $mailMessage = str_replace("{CODE}", $code, $mailMessage);
                    $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                    $mail = new Mail();
                    $mail->prepare(RESETPWD_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                    $mail->IsHTML(REGISTER_EMAIL_HTML);
                    $mail->Send();
                }
            } else {
                $message = "An unexpected error occurred";
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Change the password of a user
 * @global CB_Account $LoggedAccount
 */
function wsChangePassword() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    // If the user isn't logged in, then check for Change Password Code passed
    if (!$LoggedAccount->IsLogged()) {
        $id = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : 0);
        $code = (isset($_REQUEST["Code"]) ? stripslashes($_REQUEST["Code"]) : "");
        $username = ($id <= 0 && isset($_REQUEST["Username"]) ? stripslashes($_REQUEST["Username"]) : "" );
        //$LoggedAccount = new CB_Account($id);
        $LoggedAccount = new CB_Account($id > 0 ? $id : $username);
        if ($LoggedAccount->Id < 1) {
            $message = "User does not exist";
        } else if ($LoggedAccount->ChangePwdCode != $code) {
            $message = "Code is not valid";
        }
    }
    if (!$message) {
        if ($LoggedAccount->IsLogged()) {
            // Change the current password
            if (isset($_REQUEST["Password"]) && strlen(stripslashes($_REQUEST["Password"])) > 0) {
                $noData = FALSE;
                $newPassword = stripslashes($_REQUEST["Password"]);
                $success = $LoggedAccount->ChangePassword($newPassword);
                // Remove the change password code
                if ($success) {
                    $LoggedAccount->ChangePwdCode = "";
                    $LoggedAccount->Save();
                }
            } else {
                $message = "Password cannot be empty";
            }
            // Assign the result
            if ($success)
                $message = $LoggedAccount->ToJsonFiltered();
        } else {
            $message = "User is not logged in";
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

/**
 * Get the list of associative arrays for custom search fields
 * @param [string,string] $customData
 * @return string
 */
function getSearchCustomData ($customData) {
    $searchCustomData = array();
    foreach ($customData as $search_row) {
        if (!is_array($search_row))
            continue;
        $search = array(
            "key" => $search_row["key"],
            "value" => $search_row["value"]
        );
        // Check for allowed operators
        $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
        if (!in_array($search_row["op"], $allow_ops))
            continue;
        switch ($search_row["op"]) {
            case "!": // Disequal
                $search_row["op"] = "<>";
                break;
            case "%": // Like
                $search_row["op"] = "REGEXP";
                break;
        }
        $search["op"] = $search_row["op"];
        $searchCustomData[] = $search;
    }
    return $searchCustomData;
}

/**
 * Load a list of random users
 * @global CB_Account $LoggedAccount
 */
function wsRandomList() {
    global $LoggedAccount;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        $limit = (isset($_REQUEST["Count"]) ? intval($_REQUEST["Count"]) : 0);
        if ($limit < 1)
            $limit = 5;
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($_REQUEST["CustomData"]))
            $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
        $customData = json_decode($customData, TRUE);
        $searchCustomData = getSearchCustomData($customData);

        $users = CB_Account::LoadRandom($LoggedAccount->Id, $searchCustomData, $limit);
        foreach ($users as $user) {
            $rows[] = $user->ToArrayFiltered();
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($rows, count($rows), 1) );
}

/**
 * Search for users
 */
function wsSearch() {
    $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : NULL);
    $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
    $username = (isset($_REQUEST["Username"]) ? trim(stripslashes($_REQUEST["Username"])) : "");
    $email = (isset($_REQUEST["Email"]) ? trim(stripslashes($_REQUEST["Email"])) : "");
    $customData = (isset($_REQUEST["CustomData"]) ? trim(stripslashes($_REQUEST["CustomData"])) : "{}");
    $isOnline = (isset($_REQUEST["Online"]) && $_REQUEST["Online"] == 1 );
    
    // Build the filter by CustomData
    $customData = "[]";
    if (isset($_REQUEST["CustomData"]))
        $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
    $customData = json_decode($customData, TRUE);
    $searchCustomData = getSearchCustomData($customData);
    
    $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
    $count = 0;
    $users = CB_Account::Load($username, $email, $searchCustomData, $isOnline, $limit, $offset, $count);
    $rows = array();
    foreach ($users as $user) {
        $rows[] = $user->ToArrayFiltered();
    }
    
    $pagesCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($rows, $count, $pagesCount) );
}

/**
 * Create a user guest with random username
 */
function wsCreateGuest() {
    // Fill a new object from the REQUEST parameters (must match with class public vars)
    $user = NULL;
    $prefix = (defined("GUEST_PREFIX") ? GUEST_PREFIX : "");
    if (!$prefix)
        $prefix = "Guest-";
    $success = CB_Account::CreateRandom($prefix, $user);
    if (isset($_REQUEST["Username"]))
        unset($_REQUEST["Username"]);
    Utils::FillObjectFromRow($user, $_REQUEST, TRUE);
    if ($success && $user->Username) {
        if ($user->ExistsUsername()) {
            $message = "This username has already been taken";
        } else {
            $proceed = TRUE;
            if (REGISTER_EMAIL_REQUIRED) {
                $proceed = FALSE;
                if (!($user->Email && Utils::IsValidEmail($user->Email)))
                    $message = "A valid email is required";
                else
                    $proceed = TRUE;
            }
            if ($proceed && $user->Email && !REGISTER_EMAIL_MULTIPLE && $user->ExistsEmail()) {
                $message = "Email already registered";
                $proceed = FALSE;
            }
            if ($proceed) {
                $user->Password = md5($user->Password);
                $user->Enabled = 1;
                // Set an activation code if required by settings
                if (REGISTER_EMAIL_REQUIRED && REGISTER_EMAIL_ACTIVATION) {
                    $user->ActivationCode = Utils::GenerateRandomPassword(10);
                }
                $success = $user->Save();
                if ($success) {
                    CB_Account::SetSession($user);
                    
                    // Save custom data
                    $customData = "{}";
                    if (isset($_REQUEST["CustomData"]))
                    	$customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
                    $customData = json_decode($customData, TRUE);
                    foreach ($customData as $key => $value) {
                        $newData = new CB_CustomData();
                        $newData->IdAccount = $user->Id;
                        $newData->DataKey = $key;
                        $newData->DataValue = $value;
                        $newData->Save();
                    }
                    
                    // Notify the addons
                    AddonModule::NotifyUserCreate($user);
                    
                    $message = $user->ToJsonFiltered();
                    
                    // Send the activation code to email
                    if ($user->ActivationCode) {
                        $mailMessage = @file_get_contents(REGISTER_EMAIL_MESSAGE);
                        if ($mailMessage) {
                            $urlActivation = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] ? "https" : "http") . "://" .
                                    $_SERVER["SERVER_NAME"] . ($_SERVER["SERVER_PORT"] != 80 ? ":" . $_SERVER["SERVER_PORT"] : "") .
                                    URL_ROOT . "activation.php?Id=" . $user->Id . "&Code=" . urlencode($user->ActivationCode);
                            $mailMessage = str_replace("{ACTIVATION_URL}", $urlActivation, $mailMessage);
                            $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                            $mail = new Mail();
                            $mail->prepare(REGISTER_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                            $mail->IsHTML(REGISTER_EMAIL_HTML);
                            $mail->Send();
                        }
                    }
                } else {
                    $message = "An error occurred";
                }
            }
        }
    } else {
        $message = "Username/Password invalid";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
