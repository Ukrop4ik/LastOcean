<?php

include_once "lib/api.php";

// Deny access to unsecured/non-signed requests (excluding specific methods)
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Gets the Combu server version
    case "info":
        wsInfo();
        break;
    
    // Ping from clients
    case "ping":
        wsPing();
        break;
    
    }
}
exit();

function wsInfo() {
    global $ServerSettings;
    $version = array(
        "Version" => COMBU_VERSION,
        "Time" => date("Y-m-d H:i:s"),
        "Settings" => json_encode($ServerSettings)
    );
    Utils::EchoJson($version, TRUE);
}

function wsPing () {
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage(TRUE));
}