<?

include_once 'lib/api.php';

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List news
        case "list":
            wsList();
            break;

    }
}
exit();

function wsList() {
    $count = 0;
    $list = array();
    // Set the limit, offset and page for the results
    $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
    $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
    // Load the results
    $news = CB_News::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    foreach ($news as $i) {
        $array = Utils::ObjectToArray($i);
        // Hide Id admin account to clients
        unset($array["IdAdminAccount"]);
        $list[] = $array;
    }
    // Calculate the pages count
    $pageCount = Utils::GetPagesCount($count, $limit);
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount));
}
