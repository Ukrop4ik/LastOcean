<?

include_once 'lib/api.php';

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List all the items of a user inventory
        case "list":
            wsList();
            break;

        // Save an item to a user inventory
        case "save":
            wsSave();
            break;

        // Delete an item from a user inventory
        case "delete":
            wsDelete();
            break;

    }
}
exit();


function wsList() {
    global $LoggedAccount;
    $inventory = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of inventory from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new CB_Account($id);
            // Reset the request if the user doesn't exist
            if ($user->Id < 1)
                $id = 0;
        } else {
            // If no ID was specified, then load my inventory
            $id = $LoggedAccount->Id;
        }
        // Load the inventory items
        $inventory = CB_Inventory::Load($id, TRUE);
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($inventory, count($inventory)) );
}

function wsSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Integrity data validation
        if ((!isset($_REQUEST["Name"]) || $_REQUEST["Name"] === "")) {
            $message = "Invalid item";
        } else {
            // Get the inventory item from REQUEST
            if (isset($_REQUEST["Id"]) && intval($_REQUEST["Id"]) > 0) {
                $rec = new CB_Inventory(intval($_REQUEST["Id"]));
                Utils::FillObjectFromRow($rec, $_REQUEST, TRUE);
            } else if (isset($_REQUEST["OneInstance"]) && $_REQUEST["OneInstance"] === "1") {
                // Load or create only one instance of this item
                $rec = CB_Inventory::LoadOrCreate($LoggedAccount->Id, stripslashes($_REQUEST["Name"]));
                Utils::FillObjectFromRow($rec, $_REQUEST, TRUE);
            } else {
                $rec = new CB_Inventory($_REQUEST, TRUE);
            }
            if (!$rec) {
                $message = "Invalid item";
            } else {
                // Allow to edit only my inventory
                if ($rec->Id > 0 && $rec->IdAccount != $LoggedAccount->Id)
                    $message = "This item is invalid";
                else {
                    $customData = "{}";
                    if (isset($_REQUEST["CustomData"]))
                        $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
                    $rec->IdAccount = $LoggedAccount->Id;
                    $rec->Quantity = intval($rec->Quantity);
                    $rec->CustomData = $customData;
                    if (!$rec->Name)
                        $message = "Item must have a Name";
                    else {
                        $success = $rec->Save();
                        if (!$success)
                            $message = "An error occurred";
                        else
                            $message = $rec->ToJson();
                    }
                }
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $rec = new CB_Inventory($id);
        // Can delete only from my own inventory
        if ($rec->IdAccount != $LoggedAccount->Id)
            $message = "This item is invalid";
        else {
            $success = $rec->Delete();
            if (!$success)
                $message = "An error occurred";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
