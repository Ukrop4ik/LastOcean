<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?= PAGES_TITLE ?></title>
        <link rel="stylesheet" href="css/style.css"/>
    </head>
    <body>
        <h1 id="logo"><a href="index.php"><?= PAGES_TITLE ?></a></h1>