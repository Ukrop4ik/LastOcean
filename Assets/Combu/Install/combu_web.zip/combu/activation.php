<?php

include_once "lib/api.php";

$id = (isset($_REQUEST["Id"]) ? intval($_REQUEST["Id"]) : "");
$code = (isset($_REQUEST["Code"]) ? trim(stripslashes($_REQUEST["Code"])) : "");

if ($id > 0 && $code) {
    $user = new CB_Account($id);
    if ($user->Id > 0) {
        if ($user->ActivationCode === $code) {
            $user->ActivationCode = "";
            echo $user->Save() ? "Your account has been activated, you can now login" : "Activation failed or expired";
        } else {
            echo "Activation expired";
        }
    }
}
