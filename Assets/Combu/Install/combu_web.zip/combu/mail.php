<?

include_once 'lib/api.php';

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

define ("MAIL_LIST_RECEIVED", 0);
define ("MAIL_LIST_SENT", 1);
define ("MAIL_LIST_BOTH", 2);

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List user's mail
        case "list":
            wsList();
            break;
        
        // List user's conversations recipients
        case "list_conv":
            wsListConversations();
            break;

        // Send a mail to a user
        case "send":
            wsSend();
            break;

        // Read a mail to a user
        case "read":
            wsRead();
            break;

        // Set Unread a mail to a user
        case "unread":
            wsUnread();
            break;

        // Delete a mail
        case "delete":
            wsDelete();
            break;

        // Count messages
        case "count":
            wsCount();
            break;

    }
}
exit();

function wsList() {
    global $LoggedAccount;
    $count = 0;
    $list = array();
    $pageCount = 0;
    if ($LoggedAccount->IsLogged()) {
        // Set the limit, offset and page for the results
        $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : NULL);
        $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
        $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
        $listType = (isset($_REQUEST["Type"]) ? intval($_REQUEST["Type"]) : MAIL_LIST_RECEIVED);
        $idSender = (isset($_REQUEST["IdSender"]) ? intval($_REQUEST["IdSender"]) : 0);
        $idRecipient = (isset($_REQUEST["IdRecipient"]) ? intval($_REQUEST["IdRecipient"]) : 0);
        $idGroup = (isset($_REQUEST["IdGroup"]) ? intval($_REQUEST["IdGroup"]) : 0);
        // Load the results, request parameter 'sent' decides if sent or received
        switch ($listType) {
            case MAIL_LIST_SENT:
                // Get the messages sent by the logged user to others
                $mails = CB_Mail::Load($idRecipient, $LoggedAccount->Id, $idGroup, $limit, $offset, $count);
                break;
            case MAIL_LIST_BOTH:
                // Get both the messages sent and received by the logged user in the form of a conversation,
                // this method requires either $idRecipient or $idGroup to work (else it will return no records)
                $mails = CB_Mail::LoadConversationMessages($LoggedAccount->Id, $idRecipient, $idGroup, $limit, $offset, $count);
                break;
            default:
                // Get the messages received by the logged user
                $mails = CB_Mail::Load($LoggedAccount->Id, $idSender, $idGroup, $limit, $offset, $count);
                break;
        }
        foreach ($mails as $i) {
            $array = $i->ToArray();
            $list[] = $array;
        }
        // Calculate the pages count
        $pageCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount));
}

function wsListConversations() {
    global $LoggedAccount;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        $list = CB_Mail::LoadConversations($LoggedAccount->Id);
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, count($list)));
}

function wsSend() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Create a group from REQUEST if needed
        $recipients = array();
        $groupId = 0;
        if (isset($_REQUEST["Id"]) || isset($_REQUEST["Username"])) {
            // Send to multiple or single users
            $isId = isset($_REQUEST["Id"]);
            $userRequest = stripslashes($_REQUEST[$isId ? "Id" : "Username"]);
            $userId = explode(",", $userRequest);
            foreach ($userId as $id) {
                if ($isId)
                    $id = intval($id);
                if ($id) {
                    $user = new CB_Account($id);
                    if ($user->Id > 0)
                        $recipients[] = $user;
                }
            }
            // Create the group
            if (count($recipients) > 1) {
                $group = new CB_UserGroup();
                $group->IdOwner = $LoggedAccount->Id;
                if ($group->Save()) {
                    $groupId = $group->Id;
                    // Add myself
                    $recipients[] = $LoggedAccount;
                    // Add the recipients
                    foreach ($recipients as $user) {
                        $userGroup = new CB_UserGroupAccount();
                        $userGroup->IdGroup = $groupId;
                        $userGroup->IdAccount = $user->Id;
                        $userGroup->Save();
                    }
                } else {
                    // Invalidate the request
                    $recipients = array();
                }
            }
        } else if (isset($_REQUEST["IdGroup"])) {
            $groupId = intval($_REQUEST["IdGroup"]);
            $group = new CB_UserGroup($groupId);
            if ($group->Id > 0) {
                // Get the recipients from the group
                $members = $group->GetMembersAccount();
                foreach ($members as $user) {
                    $recipients[] = $user;
                }
            } else {
                $groupId = 0;
            }
        }
        // Get message data from REQUEST
        $subject = (!isset($_REQUEST["Subject"]) ? "" : stripslashes($_REQUEST["Subject"]));
        $body = (!isset($_REQUEST["Message"]) ? "" : stripslashes($_REQUEST["Message"]));
        // Validate the message data
        if (count($recipients) == 0)
            $message = "No recipients";
        else if ($groupId == 0 && $recipients[0]->Id == $LoggedAccount->Id)
            $message = "You cannot send mail to yourself";
        else if (!$body)
            $message = "Missing Message";
        else {
            $canSend = TRUE;
            
            // Verify that I'm not in the recipient's ignore list
            if ($groupId == 0) {
                $recs = CB_Friend::Load($recipients[0]->Id, FRIEND_STATE_IGNORE);
                foreach ($recs as $r) {
                    if ($r->IdFriend == $LoggedAccount->Id) {
                        $canSend = FALSE;
                        break;
                    }
                }
            }
            
            // Send the message to every recipient
            if ($canSend) {
                // Add myself if it's being sent to a group and I'm not in the list
                if ($groupId > 0) {
                    $addMe = TRUE;
                    foreach ($recipients as $user) {
                        if ($user->Id == $LoggedAccount->Id) {
                            $addMe = FALSE;
                            break;
                        }
                    }
                    if ($addMe)
                        $recipients[] = $LoggedAccount;
                }
                $date = date("Y-m-d H:i:s");
                foreach ($recipients as $user) {
                    $rec = new CB_Mail();
                    $rec->SendDate = $date;
                    $rec->Subject = $subject;
                    $rec->Message = $body;
                    $rec->IdAccount = $user->Id;
                    $rec->IdGroup = $groupId;
                    $rec->IdSender = $LoggedAccount->Id;
                    if ($rec->Save())
                        $success = TRUE;
                }
                if (!$success)
                    $message = "An error occurred";
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsRead () {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the message Id from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        if ($id === -1) {
            $idSenders = (isset($_REQUEST["IdSender"]) ? explode(",", $_REQUEST["IdSender"]) : array());
            $idGroups = (isset($_REQUEST["IdGroup"]) ? explode(",", $_REQUEST["IdGroup"]) : array());
            $mails = CB_Mail::LoadUnread($LoggedAccount->Id, $idSenders, $idGroups);
        } else {
            $mails = array( new CB_Mail($id) );
        }
        foreach ($mails as $mail) {
            if ($mail->IdAccount == $LoggedAccount->Id) {
                if (!$mail->ReadDate) {
                    $mail->ReadDate = date("Y-m-d H:i:s");
                    $success = $mail->Save();
                } else {
                    $success = TRUE;
                }
            }
        }
        if (!$success)
            $message = "An error occurred";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsUnread () {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the message Id from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $mails = array( new CB_Mail($id) );
        foreach ($mails as $mail) {
            if ($mail->IdAccount == $LoggedAccount->Id) {
                if ($mail->ReadDate) {
                    $mail->ReadDate = "";
                    $success = $mail->Save();
                } else {
                    $success = TRUE;
                }
            }
        }
        if (!$success)
            $message = "An error occurred";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new CB_Mail(!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        if ($rec->IdAccount == $LoggedAccount->Id) {
            $success = $rec->Delete();
            if (!$success)
                $message = "An error occurred";
        } else {
            $message = "You are not allowed to delete this message";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsCount() {
    global $LoggedAccount;
    $result = array();
    if ($LoggedAccount->IsLogged()) {
        $idSender = (isset($_REQUEST["IdSender"]) ? explode(",", $_REQUEST["IdSender"]) : array());
        $idGroup = (isset($_REQUEST["IdGroup"]) ? explode(",", $_REQUEST["IdGroup"]) : array());
        $where_read = sprintf("(IdAccount = %d AND ReadDate IS NOT NULL)", $LoggedAccount->Id);
        $where_unread = sprintf("(IdAccount = %d AND ReadDate IS NULL)", $LoggedAccount->Id);
        foreach ($idSender as $id) {
            if (intval($id) < 1)
                continue;
            $where = sprintf("(IdSender = %d AND IdGroup = 0)", $id);
            $read = DataClass::CountRecords(CB_Mail::TABLE_NAME, $where_read . " AND " . $where);
            $unread = DataClass::CountRecords(CB_Mail::TABLE_NAME, $where_unread . " AND " . $where);
            $result[] = array(
                "IdSender" => $id,
                "Read" => $read,
                "Unread" => $unread
            );
        }
        foreach ($idGroup as $id) {
            if (intval($id) < 1)
                continue;
            $where = sprintf("(IdGroup = %d)", $id);
            $read = DataClass::CountRecords(CB_Mail::TABLE_NAME, $where_read . " AND " . $where);
            $unread = DataClass::CountRecords(CB_Mail::TABLE_NAME, $where_unread . " AND " . $where);
            $result[] = array(
                "IdGroup" => $id,
                "Read" => $read,
                "Unread" => $unread
            );
        }
    }
    Utils::EchoJson($result, TRUE);
}
