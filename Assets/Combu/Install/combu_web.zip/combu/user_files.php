<?php

include_once 'lib/api.php';

set_time_limit(0);

// Deny access to unsecured/non-signed requests
checkWebserviceSecurity();

if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

        // List user files
        case "list":
            wsList();
            break;

        // Save user file
        case "save":
            wsSave();
            break;

        // Delete user file
        case "delete":
            wsDelete();
            break;

        // Increments Likes count
        case "like":
            wsLikes();
            break;

        // Increments Views count
        case "view":
            wsViews();
            break;

    }
}
exit();

function loggedAccountCanAccessFile ($userFile) {
    global $LoggedAccount;
    if ($userFile->IdAccount == $LoggedAccount->Id && $LoggedAccount->IsLogged())
        return TRUE;
    switch ($userFile->ShareType) {
        case SHARETYPE_EVERYBODY:
            // Shared with everyone, add this file
            return TRUE;
        case SHARETYPE_NOBODY:
            // Not shared, skip this file
            break;
        case SHARETYPE_FRIENDS:
            // Shared only with friends, verify that we are in the list
            if ($LoggedAccount->IsLogged()) {
                $friends = CB_Friend::Load($userFile->IdAccount, FRIEND_STATE_ACCEPTED);
                foreach ($friends as $friend) {
                    if ($friend->IdFriend == $LoggedAccount->Id) {
                        return TRUE;
                    }
                }
            }
            // If not an accepted friend then skip this file
            break;
    }
    return FALSE;
}

function wsList() {
    global $LoggedAccount;
    $files = array();
    $count = 0;
    $pageCount = 0;
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of files from REQUEST
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $includeShared = (!isset($_REQUEST["Shared"]) ? FALSE : $_REQUEST["Shared"] === "1");
        // Set the limit, offset and page for the results
        $limit = (isset($_REQUEST["Limit"]) && intval($_REQUEST["Limit"]) > 0 ? intval($_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
        $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new CB_Account($id);
            // Reset the request if the user doesn't exist
            if ($user->Id < 1)
                $id = 0;
        } else {
            // If no ID was specified, then load my inventory
            $id = $LoggedAccount->Id;
        }
        // Load the files
        if ($LoggedAccount->Id != $id)
            $includeShared = FALSE;
        $userFiles = CB_UserFiles::Load($id, $includeShared, FALSE, $limit, Utils::GetPageOffset($page, $limit), $count);
        // Calculate the pages count
        $pageCount = Utils::GetPagesCount($count, $limit);
        for ($i = 0; $i < count($userFiles); ++$i) {
            // Skip this file if we don't meet the share conditions
            if (!loggedAccountCanAccessFile($userFiles[$i]))
                continue;
            // Build the absolute URL to the file
            $userFiles[$i]->Url = "http://" . $_SERVER["SERVER_NAME"] . URL_ROOT . URL_UPLOAD . $userFiles[$i]->Url;
            // Get the file data of the logged account
            $loggedFileData = CB_UserFilesActivity::Load($userFiles[$i]->Id, $LoggedAccount->Id);
            $file = Utils::ObjectToArray($userFiles[$i]);
            $file["UserLikes"] = (count($loggedFileData) == 0 ? 0 : $loggedFileData[0]->Likes);
            $file["UserViews"] = (count($loggedFileData) == 0 ? 0 : $loggedFileData[0]->Views);
            $file["UserLastActivity"] = (count($loggedFileData) == 0 ? 0 : $loggedFileData[0]->LastActivity);
            $files[] = $file;
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($files, $count, $pageCount) );
}

function wsSave() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the file from REQUEST
        if (isset($_REQUEST["Id"])) {
            $rec = new CB_UserFiles(intval($_REQUEST["Id"]));
            Utils::FillObjectFromRow($rec, $_REQUEST, TRUE);
        } else {
            $rec = new CB_UserFiles($_REQUEST, TRUE);
        }
        // Allow to edit only my files
        if ($rec->Id > 0 && $rec->IdAccount != $LoggedAccount->Id)
            $message = "This file is invalid";
        else {
            $upload = new FileUpload("File");
            $uploaded= $upload->IsUploaded();
            if ($rec->Id <= 0 && !$uploaded)
                $message = "File not uploaded";
            else if ($uploaded && !$upload->Upload())
                $message = "Error moving the file uploaded";
            else {
                $customData = "{}";
                if (isset($_REQUEST["CustomData"]))
                    $customData = (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() ? stripslashes($_REQUEST["CustomData"]) : $_REQUEST["CustomData"]);
                $rec->IdAccount = $LoggedAccount->Id;
                $rec->Name = stripslashes($_REQUEST["Name"]);
                $rec->CustomData = $customData;
                if ($uploaded)
                    $rec->Url = $upload->GetDestinationUrl();
                $success = $rec->Save();
                if ($success) {
                	$rec->Url = "http://" . $_SERVER["SERVER_NAME"] . URL_ROOT . URL_UPLOAD . $rec->Url;
                    $message = $rec->ToJson ();
                } else {
                    $message = "An error occurred";
                }
            }
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsDelete() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $rec = new CB_UserFiles($id);
        // Can delete only from my own files
        if ($rec->IdAccount != $LoggedAccount->Id)
            $message = "This file is invalid";
        else {
            $success = $rec->Delete();
            if ($success)
                @unlink (UPLOAD . $rec->Url);
            else
                $message = "An error occurred";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsLikes() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $rec = new CB_UserFiles($id);
        if ($rec->Id > 0) {
            // Loads the activity of the currently logged user on this file
            $activity = CB_UserFilesActivity::Load($rec->Id, $LoggedAccount->Id);
            if (count($activity) > 0)
                $activity = $activity[0];
            else
                $activity = NULL;
            // Verify data
            if (!loggedAccountCanAccessFile($rec)) {
                // The currently logged user cannot access this file
                $message = "This file is invalid";
            } else if ($activity && $activity->Likes > 0) {
                // The currently logged user has already sent a Like for this file
                $message = "You has already voted this file";
            } else {
                $success = $rec->AddLike();
                if ($success) {
                	$rec->Url = "http://" . $_SERVER["SERVER_NAME"] . URL_ROOT . URL_UPLOAD . $rec->Url;
                    $message = $rec->ToJson ();
                } else {
                    $message = "An error occurred";
                }
            }
        } else {
            $message = "This file is invalid";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}

function wsViews() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($_REQUEST["Id"]) ? 0 : intval($_REQUEST["Id"]));
        $rec = new CB_UserFiles($id);
        if ($rec->Id > 0) {
            // Can delete only from my own files
            if (!loggedAccountCanAccessFile($rec))
                $message = "This file is invalid";
            else {
                $success = $rec->AddView();
                if ($success) {
                	$rec->Url = "http://" . $_SERVER["SERVER_NAME"] . URL_ROOT . URL_UPLOAD . $rec->Url;
                    $message = $rec->ToJson ();
                } else {
                    $message = "An error occurred";
                }
            }
        } else {
            $message = "This file is invalid";
        }
    } else {
        $message = "User is not logged in";
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message) );
}
